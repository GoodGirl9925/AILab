"""
Text preprocessing utilities for sentiment analysis.
Implements various text cleaning strategies for ablation studies.
"""
import re
import html
from typing import Optional


class TextPreprocessor:
    """
    Text preprocessing with configurable cleaning strategies.

    Strategies:
    - raw: No preprocessing
    - basic: Remove URLs, @mentions, #hashtags, HTML entities
    - clean: basic + compress repeated characters + lowercase
    - emoji_replace: clean + replace emojis with [EMOJI] placeholder
    - emoji_remove: clean + remove emojis completely
    """

    def __init__(self, strategy: str = 'raw'):
        """
        Args:
            strategy: Preprocessing strategy ('raw', 'basic', 'clean', 'emoji_replace', 'emoji_remove')
        """
        self.strategy = strategy

        # Emoji pattern (Unicode ranges for common emojis)
        self.emoji_pattern = re.compile(
            "["
            "\U0001F600-\U0001F64F"  # emoticons
            "\U0001F300-\U0001F5FF"  # symbols & pictographs
            "\U0001F680-\U0001F6FF"  # transport & map symbols
            "\U0001F1E0-\U0001F1FF"  # flags (iOS)
            "\U00002702-\U000027B0"
            "\U000024C2-\U0001F251"
            "]+",
            flags=re.UNICODE
        )

        # URL pattern
        self.url_pattern = re.compile(
            r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
        )

        # Mention pattern (@username)
        self.mention_pattern = re.compile(r'@\w+')

        # Hashtag pattern (#hashtag)
        self.hashtag_pattern = re.compile(r'#\w+')

        # Repeated character pattern (e.g., "sooooo" -> "soo")
        self.repeat_pattern = re.compile(r'(.)\1{2,}')

    def preprocess(self, text: str) -> str:
        """
        Apply preprocessing based on strategy.

        Args:
            text: Input text

        Returns:
            Preprocessed text
        """
        if self.strategy == 'raw':
            return text

        # Basic cleaning
        if self.strategy in ['basic', 'clean', 'emoji_replace', 'emoji_remove']:
            text = self._basic_clean(text)

        # Advanced cleaning
        if self.strategy in ['clean', 'emoji_replace', 'emoji_remove']:
            text = self._advanced_clean(text)

        # Emoji handling
        if self.strategy == 'emoji_replace':
            text = self._replace_emojis(text)
        elif self.strategy == 'emoji_remove':
            text = self._remove_emojis(text)

        return text.strip()

    def _basic_clean(self, text: str) -> str:
        """Basic cleaning: URLs, mentions, hashtags, HTML entities."""
        # Remove URLs
        text = self.url_pattern.sub('', text)

        # Remove @mentions
        text = self.mention_pattern.sub('', text)

        # Remove #hashtags (keep the word)
        text = self.hashtag_pattern.sub(lambda m: m.group(0)[1:], text)

        # Decode HTML entities
        text = html.unescape(text)

        return text

    def _advanced_clean(self, text: str) -> str:
        """Advanced cleaning: repeated characters, lowercase."""
        # Compress repeated characters (keep max 2)
        text = self.repeat_pattern.sub(r'\1\1', text)

        # Convert to lowercase (BERT-uncased compatible)
        text = text.lower()

        return text

    def _replace_emojis(self, text: str) -> str:
        """Replace emojis with [EMOJI] placeholder."""
        return self.emoji_pattern.sub('[EMOJI]', text)

    def _remove_emojis(self, text: str) -> str:
        """Remove emojis completely."""
        return self.emoji_pattern.sub('', text)


def get_text_preprocessor(strategy: str = 'raw') -> TextPreprocessor:
    """
    Factory function to get text preprocessor.

    Args:
        strategy: Preprocessing strategy

    Returns:
        TextPreprocessor instance
    """
    valid_strategies = ['raw', 'basic', 'clean', 'emoji_replace', 'emoji_remove']
    if strategy not in valid_strategies:
        raise ValueError(f"Unknown strategy: {strategy}. Choose from {valid_strategies}")

    return TextPreprocessor(strategy)


# Mapping for experiment naming
STRATEGY_NAMES = {
    'raw': 'T1-Raw',
    'basic': 'T2-Basic',
    'clean': 'T3-Clean',
    'emoji_replace': 'T4-Emoji',
    'emoji_remove': 'T5-Remove'
}

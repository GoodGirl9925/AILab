"""
Enhanced trainer with integrated visualization.
Wraps the training loop with automatic plot generation.
"""
import torch
import numpy as np
from collections import Counter
from utils.visualization import TrainingVisualizer


class VisualizedTrainer:
    """
    Training wrapper with automatic visualization.
    Collects metrics during training and generates plots.
    """

    def __init__(self, output_dir: str, experiment_name: str):
        """
        Args:
            output_dir: Directory to save plots and metrics
            experiment_name: Name of the experiment
        """
        self.visualizer = TrainingVisualizer(output_dir, experiment_name)
        self.current_lr = []

    def on_train_epoch_end(self, epoch: int, train_loss: float, train_metrics: dict,
                          cls_loss: float = None, consistency_loss: float = None):
        """
        Callback after training epoch.

        Args:
            epoch: Current epoch number
            train_loss: Average training loss
            train_metrics: Dictionary with 'accuracy', 'f1', etc.
            cls_loss: Classification loss component
            consistency_loss: Consistency loss component
        """
        self.visualizer.update_train_metrics(
            epoch=epoch + 1,  # 1-indexed for display
            loss=train_loss,
            accuracy=train_metrics['accuracy'],
            f1=train_metrics['f1'],
            cls_loss=cls_loss,
            consistency_loss=consistency_loss
        )

    def on_val_epoch_end(self, epoch: int, val_loss: float, val_metrics: dict,
                        per_class_metrics: dict):
        """
        Callback after validation epoch.

        Args:
            epoch: Current epoch number
            val_loss: Average validation loss
            val_metrics: Dictionary with 'accuracy', 'f1', 'precision', 'recall'
            per_class_metrics: Dictionary with per-class F1 scores
        """
        self.visualizer.update_val_metrics(
            epoch=epoch + 1,
            loss=val_loss,
            accuracy=val_metrics['accuracy'],
            f1=val_metrics['f1'],
            precision=val_metrics['precision'],
            recall=val_metrics['recall'],
            pos_f1=per_class_metrics.get('positive', 0.0),
            neu_f1=per_class_metrics.get('neutral', 0.0),
            neg_f1=per_class_metrics.get('negative', 0.0)
        )

    def on_batch_end(self, lr: float):
        """
        Callback after each training batch.

        Args:
            lr: Current learning rate
        """
        self.visualizer.update_learning_rate(lr)

    def on_training_end(self, y_true_val, y_pred_val, train_dataset, val_dataset,
                       final_epoch: int = None, baseline_f1: float = None):
        """
        Callback after training completes.
        Generates all visualization plots.

        Args:
            y_true_val: True labels for validation set
            y_pred_val: Predicted labels for validation set
            train_dataset: Training dataset (for class distribution)
            val_dataset: Validation dataset (for class distribution)
            final_epoch: Final epoch number
            baseline_f1: Baseline F1 score for comparison
        """
        # Collect class distributions
        train_labels = [train_dataset[i]['label'].item() for i in range(len(train_dataset))]
        val_labels = [val_dataset[i]['label'].item() for i in range(len(val_dataset))]

        label_map = {0: 'positive', 1: 'neutral', 2: 'negative'}
        train_counts = Counter([label_map[l] for l in train_labels])
        val_counts = Counter([label_map[l] for l in val_labels])

        # Generate all plots
        self.visualizer.generate_all_plots(
            y_true=y_true_val,
            y_pred=y_pred_val,
            epoch=final_epoch,
            train_counts=train_counts,
            val_counts=val_counts,
            baseline_f1=baseline_f1
        )

    def plot_confusion_matrix_per_epoch(self, epoch: int, y_true, y_pred):
        """
        Generate confusion matrix for specific epoch.

        Args:
            epoch: Epoch number
            y_true: True labels
            y_pred: Predicted labels
        """
        self.visualizer.plot_confusion_matrix(y_true, y_pred, epoch=epoch)


def compute_per_class_f1(y_true, y_pred):
    """
    Compute per-class F1 scores.

    Args:
        y_true: True labels
        y_pred: Predicted labels

    Returns:
        Dictionary with per-class F1 scores
    """
    from sklearn.metrics import f1_score

    label_map = {0: 'positive', 1: 'neutral', 2: 'negative'}
    per_class_f1 = f1_score(y_true, y_pred, average=None)

    result = {}
    for i in range(min(len(per_class_f1), 3)):
        result[label_map[i]] = per_class_f1[i]

    # Fill missing classes with 0
    for label_name in ['positive', 'neutral', 'negative']:
        if label_name not in result:
            result[label_name] = 0.0

    return result


# Example usage in training loop
"""
# Initialize visualized trainer
vis_trainer = VisualizedTrainer(
    output_dir='./outputs',
    experiment_name='text_expert_clean'
)

# In training loop
for epoch in range(num_epochs):
    # ... training code ...

    # After training epoch
    vis_trainer.on_train_epoch_end(
        epoch=epoch,
        train_loss=train_loss,
        train_metrics={'accuracy': train_acc, 'f1': train_f1},
        cls_loss=cls_loss,
        consistency_loss=consistency_loss
    )

    # After validation epoch
    per_class_metrics = compute_per_class_f1(val_true, val_pred)
    vis_trainer.on_val_epoch_end(
        epoch=epoch,
        val_loss=val_loss,
        val_metrics={'accuracy': val_acc, 'f1': val_f1, 'precision': val_prec, 'recall': val_rec},
        per_class_metrics=per_class_metrics
    )

    # After each batch (optional, for learning rate tracking)
    vis_trainer.on_batch_end(lr=optimizer.param_groups[0]['lr'])

    # Optionally plot confusion matrix every few epochs
    if (epoch + 1) % 5 == 0:
        vis_trainer.plot_confusion_matrix_per_epoch(epoch + 1, val_true, val_pred)

# After training completes
vis_trainer.on_training_end(
    y_true_val=val_true,
    y_pred_val=val_pred,
    train_dataset=train_dataset,
    val_dataset=val_dataset,
    final_epoch=num_epochs,
    baseline_f1=0.5657  # e.g., from previous experiment
)
"""

"""
Loss functions for multimodal sentiment analysis.
Includes standard CE, weighted CE, Focal Loss, and LDAM Loss for class imbalance.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class CrossEntropyLoss(nn.Module):
    """Standard cross-entropy loss for classification."""

    def __init__(self, label_smoothing: float = 0.0):
        super().__init__()
        self.criterion = nn.CrossEntropyLoss(label_smoothing=label_smoothing)

    def forward(self, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        return self.criterion(logits, labels)


class WeightedCrossEntropyLoss(nn.Module):
    """
    Weighted cross-entropy loss for class imbalance.
    Assigns higher weights to minority classes.
    """

    def __init__(self, class_weights: torch.Tensor = None, label_smoothing: float = 0.0):
        super().__init__()
        self.class_weights = class_weights
        self.criterion = nn.CrossEntropyLoss(weight=class_weights, label_smoothing=label_smoothing)

    def forward(self, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        return self.criterion(logits, labels)


class FocalLoss(nn.Module):
    """
    Focal Loss for addressing class imbalance.
    FL(p_t) = -α_t * (1 - p_t)^γ * log(p_t)

    Reference: Lin et al., "Focal Loss for Dense Object Detection", ICCV 2017
    """

    def __init__(self, alpha: torch.Tensor = None, gamma: float = 2.0, reduction: str = 'mean'):
        """
        Args:
            alpha: Class weights [num_classes]
            gamma: Focusing parameter (default: 2.0)
            reduction: 'mean' or 'sum'
        """
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction

    def forward(self, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        """
        Args:
            logits: Predicted logits [batch_size, num_classes]
            labels: Ground truth labels [batch_size]

        Returns:
            Focal loss value
        """
        # Compute softmax probabilities
        probs = F.softmax(logits, dim=-1)

        # Get probability of true class
        batch_size = logits.size(0)
        true_class_probs = probs[torch.arange(batch_size), labels]

        # Compute focal term: (1 - p_t)^gamma
        focal_weight = (1 - true_class_probs) ** self.gamma

        # Compute cross-entropy: -log(p_t)
        ce_loss = F.cross_entropy(logits, labels, reduction='none')

        # Apply class weights if provided
        if self.alpha is not None:
            alpha_t = self.alpha[labels]
            focal_loss = alpha_t * focal_weight * ce_loss
        else:
            focal_loss = focal_weight * ce_loss

        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        else:
            return focal_loss


class LDAMLoss(nn.Module):
    """
    Label-Distribution-Aware Margin (LDAM) Loss for long-tailed recognition.

    Reference: Cao et al., "Learning Imbalanced Datasets with Label-Distribution-Aware Margin Loss", NeurIPS 2019
    """

    def __init__(self, cls_num_list: list, max_m: float = 0.5, s: float = 30, weight: torch.Tensor = None):
        """
        Args:
            cls_num_list: List of number of samples per class
            max_m: Maximum margin
            s: Scale parameter
            weight: Class weights
        """
        super().__init__()
        m_list = 1.0 / np.sqrt(np.sqrt(cls_num_list))
        m_list = m_list * (max_m / np.max(m_list))
        m_list = torch.FloatTensor(m_list)
        self.m_list = m_list
        self.s = s
        self.weight = weight

    def forward(self, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        """
        Args:
            logits: Predicted logits [batch_size, num_classes]
            labels: Ground truth labels [batch_size]

        Returns:
            LDAM loss value
        """
        batch_size = logits.size(0)
        num_classes = logits.size(1)

        # Move m_list to same device as logits
        if self.m_list.device != logits.device:
            self.m_list = self.m_list.to(logits.device)

        # Create margin matrix
        index = torch.zeros_like(logits, dtype=torch.uint8)
        index.scatter_(1, labels.unsqueeze(1), 1)

        # Apply margin to true class logits
        m_hot = self.m_list[labels].unsqueeze(1)
        logits_m = logits - m_hot * index.float()

        # Scale logits
        output = logits_m * self.s

        # Compute cross-entropy with optional class weights
        if self.weight is not None:
            return F.cross_entropy(output, labels, weight=self.weight)
        else:
            return F.cross_entropy(output, labels)


class ConsistencyLoss(nn.Module):
    """
    Emotion consistency loss using KL divergence.
    Encourages text and image modalities to produce similar sentiment distributions.
    """

    def __init__(self, temperature: float = 1.0):
        super().__init__()
        self.temperature = temperature

    def forward(self, text_logits: torch.Tensor, image_logits: torch.Tensor) -> torch.Tensor:
        """
        Compute KL divergence between text and image sentiment distributions.

        Args:
            text_logits: Logits from text encoder [batch_size, num_classes]
            image_logits: Logits from image encoder [batch_size, num_classes]

        Returns:
            KL divergence loss
        """
        # Apply temperature scaling
        text_probs = F.softmax(text_logits / self.temperature, dim=-1)
        image_log_probs = F.log_softmax(image_logits / self.temperature, dim=-1)

        # KL(p_text || p_img)
        kl_loss = F.kl_div(image_log_probs, text_probs, reduction='batchmean')

        return kl_loss * (self.temperature ** 2)


class MultimodalLoss(nn.Module):
    """
    Combined loss for multimodal sentiment analysis.
    L = L_cls + λ * KL(p_text || p_img)

    Supports multiple classification loss types:
    - ce: Standard cross-entropy
    - weighted_ce: Weighted cross-entropy
    - focal: Focal loss
    - ldam: LDAM loss
    """

    def __init__(self,
                 loss_type: str = 'ce',
                 class_weights: torch.Tensor = None,
                 cls_num_list: list = None,
                 focal_gamma: float = 2.0,
                 ldam_max_m: float = 0.5,
                 ldam_s: float = 30,
                 use_consistency: bool = False,
                 consistency_lambda: float = 0.1,
                 label_smoothing: float = 0.0,
                 temperature: float = 1.0):
        super().__init__()
        self.loss_type = loss_type
        self.use_consistency = use_consistency
        self.consistency_lambda = consistency_lambda

        # Initialize classification loss
        if loss_type == 'ce':
            self.cls_loss = CrossEntropyLoss(label_smoothing=label_smoothing)
        elif loss_type == 'weighted_ce':
            self.cls_loss = WeightedCrossEntropyLoss(class_weights, label_smoothing)
        elif loss_type == 'focal':
            self.cls_loss = FocalLoss(alpha=class_weights, gamma=focal_gamma)
        elif loss_type == 'ldam':
            if cls_num_list is None:
                raise ValueError("cls_num_list must be provided for LDAM loss")
            self.cls_loss = LDAMLoss(cls_num_list, max_m=ldam_max_m, s=ldam_s, weight=class_weights)
        else:
            raise ValueError(f"Unknown loss type: {loss_type}")

        # Consistency loss
        self.consistency_loss = ConsistencyLoss(temperature=temperature)

    def forward(self,
                logits: torch.Tensor,
                labels: torch.Tensor,
                text_logits: torch.Tensor = None,
                image_logits: torch.Tensor = None) -> dict:
        """
        Compute combined loss.

        Args:
            logits: Final classification logits
            labels: Ground truth labels
            text_logits: Text expert logits (optional)
            image_logits: Image expert logits (optional)

        Returns:
            Dictionary containing total loss and individual components
        """
        cls_loss = self.cls_loss(logits, labels)

        loss_dict = {
            'cls_loss': cls_loss,
            'total_loss': cls_loss
        }

        if self.use_consistency and text_logits is not None and image_logits is not None:
            consistency = self.consistency_loss(text_logits, image_logits)
            loss_dict['consistency_loss'] = consistency
            loss_dict['total_loss'] = cls_loss + self.consistency_lambda * consistency

        return loss_dict


def get_class_weights(cls_num_list: list, mode: str = 'inverse') -> torch.Tensor:
    """
    Compute class weights for imbalanced datasets.

    Args:
        cls_num_list: List of number of samples per class
        mode: Weighting mode
            - 'inverse': 1 / n_samples
            - 'inverse_sqrt': 1 / sqrt(n_samples)
            - 'effective': Effective number of samples

    Returns:
        Class weights tensor
    """
    cls_num_list = np.array(cls_num_list)

    if mode == 'inverse':
        weights = 1.0 / cls_num_list
    elif mode == 'inverse_sqrt':
        weights = 1.0 / np.sqrt(cls_num_list)
    elif mode == 'effective':
        beta = 0.9999
        effective_num = 1.0 - np.power(beta, cls_num_list)
        weights = (1.0 - beta) / effective_num
    else:
        raise ValueError(f"Unknown mode: {mode}")

    # Normalize weights
    weights = weights / weights.sum() * len(weights)

    return torch.FloatTensor(weights)

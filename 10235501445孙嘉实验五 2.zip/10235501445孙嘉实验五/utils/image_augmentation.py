"""
Image augmentation utilities for sentiment analysis.
Implements various augmentation strategies for ablation studies.
"""
import torch
from torchvision import transforms
from typing import Optional


class ImageAugmentation:
    """
    Image augmentation with configurable strategies.

    Strategies:
    - none: No augmentation (only Resize + Normalize)
    - light: RandomHorizontalFlip
    - medium: light + RandomResizedCrop
    - strong: medium + ColorJitter + RandomErasing
    """

    def __init__(self, strategy: str = 'none', image_size: int = 224):
        """
        Args:
            strategy: Augmentation strategy ('none', 'light', 'medium', 'strong')
            image_size: Target image size
        """
        self.strategy = strategy
        self.image_size = image_size

        # Build augmentation pipeline
        self.train_transform = self._build_train_transform()
        self.val_transform = self._build_val_transform()

    def _build_train_transform(self):
        """Build training augmentation pipeline."""
        transform_list = []

        if self.strategy == 'none':
            # No augmentation
            transform_list.extend([
                transforms.Resize((self.image_size, self.image_size)),
            ])

        elif self.strategy == 'light':
            # Light augmentation: horizontal flip
            transform_list.extend([
                transforms.Resize((self.image_size, self.image_size)),
                transforms.RandomHorizontalFlip(p=0.5),
            ])

        elif self.strategy == 'medium':
            # Medium augmentation: flip + crop
            transform_list.extend([
                transforms.RandomResizedCrop(
                    self.image_size,
                    scale=(0.8, 1.0),
                    ratio=(0.9, 1.1)
                ),
                transforms.RandomHorizontalFlip(p=0.5),
            ])

        elif self.strategy == 'strong':
            # Strong augmentation: flip + crop + color + erasing
            transform_list.extend([
                transforms.RandomResizedCrop(
                    self.image_size,
                    scale=(0.8, 1.0),
                    ratio=(0.9, 1.1)
                ),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.ColorJitter(
                    brightness=0.2,
                    contrast=0.2,
                    saturation=0.2,
                    hue=0.1
                ),
            ])

        else:
            raise ValueError(f"Unknown strategy: {self.strategy}")

        # Common transforms (convert to tensor and normalize)
        # Note: CLIP processor will handle normalization, so we only convert to tensor here
        transform_list.append(transforms.ToTensor())

        # Add RandomErasing for strong augmentation (after ToTensor)
        if self.strategy == 'strong':
            transform_list.append(
                transforms.RandomErasing(p=0.5, scale=(0.02, 0.2), ratio=(0.3, 3.3))
            )

        return transforms.Compose(transform_list)

    def _build_val_transform(self):
        """Build validation/test augmentation pipeline (no augmentation)."""
        return transforms.Compose([
            transforms.Resize((self.image_size, self.image_size)),
            transforms.ToTensor(),
        ])

    def get_train_transform(self):
        """Get training transform."""
        return self.train_transform

    def get_val_transform(self):
        """Get validation/test transform."""
        return self.val_transform


def get_image_augmentation(strategy: str = 'none', image_size: int = 224) -> ImageAugmentation:
    """
    Factory function to get image augmentation.

    Args:
        strategy: Augmentation strategy
        image_size: Target image size

    Returns:
        ImageAugmentation instance
    """
    valid_strategies = ['none', 'light', 'medium', 'strong']
    if strategy not in valid_strategies:
        raise ValueError(f"Unknown strategy: {strategy}. Choose from {valid_strategies}")

    return ImageAugmentation(strategy, image_size)


# Mapping for experiment naming
STRATEGY_NAMES = {
    'none': 'I1-None',
    'light': 'I2-Light',
    'medium': 'I3-Medium',
    'strong': 'I4-Strong'
}

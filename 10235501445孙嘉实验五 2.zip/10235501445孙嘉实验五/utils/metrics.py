"""
Evaluation metrics for sentiment analysis.
"""
import numpy as np
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, confusion_matrix


def compute_metrics(predictions: np.ndarray, labels: np.ndarray):
    """
    Compute evaluation metrics for sentiment classification.

    Args:
        predictions: Predicted labels (numpy array)
        labels: Ground truth labels (numpy array)

    Returns:
        Dictionary containing various metrics
    """
    accuracy = accuracy_score(labels, predictions)
    f1_macro = f1_score(labels, predictions, average='macro')
    f1_weighted = f1_score(labels, predictions, average='weighted')
    precision_macro = precision_score(labels, predictions, average='macro')
    recall_macro = recall_score(labels, predictions, average='macro')
    conf_matrix = confusion_matrix(labels, predictions)

    # Per-class F1 scores
    f1_per_class = f1_score(labels, predictions, average=None)

    metrics = {
        'accuracy': accuracy,
        'f1_macro': f1_macro,
        'f1_weighted': f1_weighted,
        'precision_macro': precision_macro,
        'recall_macro': recall_macro,
        'confusion_matrix': conf_matrix,
        'f1_positive': f1_per_class[0] if len(f1_per_class) > 0 else 0,
        'f1_neutral': f1_per_class[1] if len(f1_per_class) > 1 else 0,
        'f1_negative': f1_per_class[2] if len(f1_per_class) > 2 else 0,
    }

    return metrics


def print_metrics(metrics: dict, prefix: str = ''):
    """
    Print metrics in a formatted way.

    Args:
        metrics: Dictionary of metrics
        prefix: Prefix string for printing
    """
    print(f"{prefix}Accuracy: {metrics['accuracy']:.4f}")
    print(f"{prefix}F1 (Macro): {metrics['f1_macro']:.4f}")
    print(f"{prefix}F1 (Weighted): {metrics['f1_weighted']:.4f}")
    print(f"{prefix}Precision (Macro): {metrics['precision_macro']:.4f}")
    print(f"{prefix}Recall (Macro): {metrics['recall_macro']:.4f}")
    print(f"{prefix}F1 per class - Positive: {metrics['f1_positive']:.4f}, "
          f"Neutral: {metrics['f1_neutral']:.4f}, Negative: {metrics['f1_negative']:.4f}")
    print(f"{prefix}Confusion Matrix:\n{metrics['confusion_matrix']}")

"""
Visualization utilities for training and evaluation.
Generates various plots for experiment reports.
"""
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix, classification_report
import os
from pathlib import Path
import json

# 设置中文字体支持
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial', 'sans-serif']
plt.rcParams['axes.unicode_minus'] = False
sns.set_style("whitegrid")


class TrainingVisualizer:
    """
    Comprehensive visualization for training process.
    Generates multiple plots for experiment reports.
    """

    def __init__(self, output_dir: str, experiment_name: str = "experiment"):
        """
        Args:
            output_dir: Directory to save plots
            experiment_name: Name of the experiment
        """
        self.output_dir = Path(output_dir)
        self.experiment_name = experiment_name
        self.plots_dir = self.output_dir / "plots"
        self.plots_dir.mkdir(parents=True, exist_ok=True)

        # Initialize storage for metrics
        self.train_metrics = {
            'epoch': [],
            'loss': [],
            'accuracy': [],
            'f1': [],
            'cls_loss': [],
            'consistency_loss': []
        }
        self.val_metrics = {
            'epoch': [],
            'loss': [],
            'accuracy': [],
            'f1': [],
            'precision': [],
            'recall': [],
            'pos_f1': [],
            'neu_f1': [],
            'neg_f1': []
        }
        self.learning_rates = []

    def update_train_metrics(self, epoch: int, loss: float, accuracy: float, f1: float,
                            cls_loss: float = None, consistency_loss: float = None):
        """Update training metrics."""
        self.train_metrics['epoch'].append(epoch)
        self.train_metrics['loss'].append(loss)
        self.train_metrics['accuracy'].append(accuracy)
        self.train_metrics['f1'].append(f1)
        if cls_loss is not None:
            self.train_metrics['cls_loss'].append(cls_loss)
        if consistency_loss is not None:
            self.train_metrics['consistency_loss'].append(consistency_loss)

    def update_val_metrics(self, epoch: int, loss: float, accuracy: float, f1: float,
                          precision: float, recall: float,
                          pos_f1: float, neu_f1: float, neg_f1: float):
        """Update validation metrics."""
        self.val_metrics['epoch'].append(epoch)
        self.val_metrics['loss'].append(loss)
        self.val_metrics['accuracy'].append(accuracy)
        self.val_metrics['f1'].append(f1)
        self.val_metrics['precision'].append(precision)
        self.val_metrics['recall'].append(recall)
        self.val_metrics['pos_f1'].append(pos_f1)
        self.val_metrics['neu_f1'].append(neu_f1)
        self.val_metrics['neg_f1'].append(neg_f1)

    def update_learning_rate(self, lr: float):
        """Update learning rate."""
        self.learning_rates.append(lr)

    def plot_training_curves(self):
        """Plot 1: Training curves (Loss, Accuracy, F1)."""
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        fig.suptitle(f'{self.experiment_name} - Training Progress', fontsize=16, fontweight='bold')

        # Plot 1: Loss curves
        ax = axes[0, 0]
        if self.train_metrics['loss']:
            ax.plot(self.train_metrics['epoch'], self.train_metrics['loss'],
                   'b-o', label='Train Loss', linewidth=2, markersize=6)
        if self.val_metrics['loss']:
            ax.plot(self.val_metrics['epoch'], self.val_metrics['loss'],
                   'r-s', label='Val Loss', linewidth=2, markersize=6)
        ax.set_xlabel('Epoch', fontsize=12)
        ax.set_ylabel('Loss', fontsize=12)
        ax.set_title('Loss Curves', fontsize=13, fontweight='bold')
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)

        # Plot 2: Accuracy curves
        ax = axes[0, 1]
        if self.train_metrics['accuracy']:
            ax.plot(self.train_metrics['epoch'], self.train_metrics['accuracy'],
                   'b-o', label='Train Accuracy', linewidth=2, markersize=6)
        if self.val_metrics['accuracy']:
            ax.plot(self.val_metrics['epoch'], self.val_metrics['accuracy'],
                   'r-s', label='Val Accuracy', linewidth=2, markersize=6)
        ax.set_xlabel('Epoch', fontsize=12)
        ax.set_ylabel('Accuracy', fontsize=12)
        ax.set_title('Accuracy Curves', fontsize=13, fontweight='bold')
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)

        # Plot 3: F1 curves
        ax = axes[1, 0]
        if self.train_metrics['f1']:
            ax.plot(self.train_metrics['epoch'], self.train_metrics['f1'],
                   'b-o', label='Train F1', linewidth=2, markersize=6)
        if self.val_metrics['f1']:
            ax.plot(self.val_metrics['epoch'], self.val_metrics['f1'],
                   'r-s', label='Val F1', linewidth=2, markersize=6)
        ax.set_xlabel('Epoch', fontsize=12)
        ax.set_ylabel('F1 Score', fontsize=12)
        ax.set_title('F1 Score Curves', fontsize=13, fontweight='bold')
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)

        # Plot 4: Overfitting gap
        ax = axes[1, 1]
        if self.train_metrics['accuracy'] and self.val_metrics['accuracy']:
            train_acc = np.array(self.train_metrics['accuracy'])
            val_acc = np.array(self.val_metrics['accuracy'])
            gap = train_acc - val_acc
            ax.plot(self.train_metrics['epoch'], gap, 'g-^', linewidth=2, markersize=6)
            ax.axhline(y=0, color='r', linestyle='--', alpha=0.5)
            ax.fill_between(self.train_metrics['epoch'], 0, gap, alpha=0.3, color='orange')
        ax.set_xlabel('Epoch', fontsize=12)
        ax.set_ylabel('Accuracy Gap (Train - Val)', fontsize=12)
        ax.set_title('Overfitting Analysis', fontsize=13, fontweight='bold')
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        save_path = self.plots_dir / f"{self.experiment_name}_training_curves.png"
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Saved training curves to {save_path}")

    def plot_class_performance(self):
        """Plot 2: Per-class F1 scores over epochs."""
        if not self.val_metrics['pos_f1']:
            return

        fig, ax = plt.subplots(figsize=(10, 6))

        epochs = self.val_metrics['epoch']
        ax.plot(epochs, self.val_metrics['pos_f1'], 'g-o', label='Positive', linewidth=2, markersize=6)
        ax.plot(epochs, self.val_metrics['neu_f1'], 'b-s', label='Neutral', linewidth=2, markersize=6)
        ax.plot(epochs, self.val_metrics['neg_f1'], 'r-^', label='Negative', linewidth=2, markersize=6)

        ax.set_xlabel('Epoch', fontsize=12)
        ax.set_ylabel('F1 Score', fontsize=12)
        ax.set_title(f'{self.experiment_name} - Per-Class F1 Scores', fontsize=14, fontweight='bold')
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)

        # Add horizontal line for balanced performance
        ax.axhline(y=0.333, color='gray', linestyle='--', alpha=0.5, label='Random Baseline')

        plt.tight_layout()
        save_path = self.plots_dir / f"{self.experiment_name}_class_f1.png"
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Saved class F1 plot to {save_path}")

    def plot_confusion_matrix(self, y_true, y_pred, class_names=['positive', 'neutral', 'negative'],
                              epoch: int = None):
        """Plot 3: Confusion matrix."""
        cm = confusion_matrix(y_true, y_pred)
        cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

        fig, axes = plt.subplots(1, 2, figsize=(14, 5))

        # Raw counts
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=class_names,
                   yticklabels=class_names, ax=axes[0], cbar_kws={'label': 'Count'})
        axes[0].set_xlabel('Predicted', fontsize=12)
        axes[0].set_ylabel('Actual', fontsize=12)
        title = f'Confusion Matrix (Counts)'
        if epoch is not None:
            title += f' - Epoch {epoch}'
        axes[0].set_title(title, fontsize=13, fontweight='bold')

        # Normalized
        sns.heatmap(cm_normalized, annot=True, fmt='.2%', cmap='Greens',
                   xticklabels=class_names, yticklabels=class_names, ax=axes[1],
                   cbar_kws={'label': 'Percentage'})
        axes[1].set_xlabel('Predicted', fontsize=12)
        axes[1].set_ylabel('Actual', fontsize=12)
        title = f'Confusion Matrix (Normalized)'
        if epoch is not None:
            title += f' - Epoch {epoch}'
        axes[1].set_title(title, fontsize=13, fontweight='bold')

        plt.suptitle(f'{self.experiment_name} - Confusion Matrix Analysis',
                    fontsize=15, fontweight='bold', y=1.02)
        plt.tight_layout()

        suffix = f"_epoch{epoch}" if epoch is not None else "_final"
        save_path = self.plots_dir / f"{self.experiment_name}_confusion_matrix{suffix}.png"
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Saved confusion matrix to {save_path}")

    def plot_learning_rate(self):
        """Plot 4: Learning rate schedule."""
        if not self.learning_rates:
            return

        fig, ax = plt.subplots(figsize=(10, 5))

        iterations = list(range(len(self.learning_rates)))
        ax.plot(iterations, self.learning_rates, 'b-', linewidth=2)
        ax.set_xlabel('Training Step', fontsize=12)
        ax.set_ylabel('Learning Rate', fontsize=12)
        ax.set_title(f'{self.experiment_name} - Learning Rate Schedule',
                    fontsize=14, fontweight='bold')
        ax.grid(True, alpha=0.3)
        ax.set_yscale('log')

        plt.tight_layout()
        save_path = self.plots_dir / f"{self.experiment_name}_learning_rate.png"
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Saved learning rate plot to {save_path}")

    def plot_loss_components(self):
        """Plot 5: Loss components (classification + consistency)."""
        if not self.train_metrics['cls_loss']:
            return

        fig, ax = plt.subplots(figsize=(10, 6))

        epochs = self.train_metrics['epoch']
        ax.plot(epochs, self.train_metrics['loss'], 'k-o', label='Total Loss',
               linewidth=2, markersize=6)
        ax.plot(epochs, self.train_metrics['cls_loss'], 'b-s', label='Classification Loss',
               linewidth=2, markersize=6)
        if self.train_metrics['consistency_loss']:
            ax.plot(epochs, self.train_metrics['consistency_loss'], 'r-^',
                   label='Consistency Loss', linewidth=2, markersize=6)

        ax.set_xlabel('Epoch', fontsize=12)
        ax.set_ylabel('Loss', fontsize=12)
        ax.set_title(f'{self.experiment_name} - Loss Components',
                    fontsize=14, fontweight='bold')
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        save_path = self.plots_dir / f"{self.experiment_name}_loss_components.png"
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Saved loss components plot to {save_path}")

    def plot_metrics_summary(self):
        """Plot 6: Final metrics summary bar chart."""
        if not self.val_metrics['f1']:
            return

        # Get final metrics
        final_metrics = {
            'Accuracy': self.val_metrics['accuracy'][-1],
            'F1-Macro': self.val_metrics['f1'][-1],
            'Precision': self.val_metrics['precision'][-1],
            'Recall': self.val_metrics['recall'][-1],
            'Pos-F1': self.val_metrics['pos_f1'][-1],
            'Neu-F1': self.val_metrics['neu_f1'][-1],
            'Neg-F1': self.val_metrics['neg_f1'][-1]
        }

        fig, ax = plt.subplots(figsize=(10, 6))

        metrics = list(final_metrics.keys())
        values = list(final_metrics.values())
        colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2']

        bars = ax.bar(metrics, values, color=colors, alpha=0.8, edgecolor='black', linewidth=1.5)

        # Add value labels on bars
        for bar, value in zip(bars, values):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{value:.3f}', ha='center', va='bottom', fontsize=10, fontweight='bold')

        ax.set_ylabel('Score', fontsize=12)
        ax.set_title(f'{self.experiment_name} - Final Validation Metrics',
                    fontsize=14, fontweight='bold')
        ax.set_ylim(0, 1.0)
        ax.grid(True, axis='y', alpha=0.3)
        plt.xticks(rotation=45, ha='right')

        plt.tight_layout()
        save_path = self.plots_dir / f"{self.experiment_name}_metrics_summary.png"
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Saved metrics summary to {save_path}")

    def plot_class_distribution(self, train_counts: dict, val_counts: dict):
        """Plot 7: Class distribution in train and validation sets."""
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))

        class_names = ['Positive', 'Neutral', 'Negative']
        colors = ['#2ecc71', '#3498db', '#e74c3c']

        # Train distribution
        train_values = [train_counts.get('positive', 0),
                       train_counts.get('neutral', 0),
                       train_counts.get('negative', 0)]
        axes[0].pie(train_values, labels=class_names, autopct='%1.1f%%',
                   colors=colors, startangle=90, textprops={'fontsize': 11, 'fontweight': 'bold'})
        axes[0].set_title(f'Training Set Distribution\n(Total: {sum(train_values)})',
                         fontsize=12, fontweight='bold')

        # Val distribution
        val_values = [val_counts.get('positive', 0),
                     val_counts.get('neutral', 0),
                     val_counts.get('negative', 0)]
        axes[1].pie(val_values, labels=class_names, autopct='%1.1f%%',
                   colors=colors, startangle=90, textprops={'fontsize': 11, 'fontweight': 'bold'})
        axes[1].set_title(f'Validation Set Distribution\n(Total: {sum(val_values)})',
                         fontsize=12, fontweight='bold')

        plt.suptitle(f'{self.experiment_name} - Class Distribution',
                    fontsize=15, fontweight='bold', y=1.02)
        plt.tight_layout()

        save_path = self.plots_dir / f"{self.experiment_name}_class_distribution.png"
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Saved class distribution plot to {save_path}")

    def plot_improvement_over_baseline(self, baseline_f1: float):
        """Plot 8: Improvement over baseline."""
        if not self.val_metrics['f1']:
            return

        fig, ax = plt.subplots(figsize=(10, 6))

        epochs = self.val_metrics['epoch']
        f1_scores = self.val_metrics['f1']
        improvements = [(f1 - baseline_f1) / baseline_f1 * 100 for f1 in f1_scores]

        ax.plot(epochs, improvements, 'b-o', linewidth=2, markersize=6)
        ax.axhline(y=0, color='r', linestyle='--', alpha=0.5, label='Baseline')
        ax.fill_between(epochs, 0, improvements, where=[i > 0 for i in improvements],
                       alpha=0.3, color='green', label='Improvement')
        ax.fill_between(epochs, 0, improvements, where=[i < 0 for i in improvements],
                       alpha=0.3, color='red', label='Degradation')

        ax.set_xlabel('Epoch', fontsize=12)
        ax.set_ylabel('Improvement over Baseline (%)', fontsize=12)
        ax.set_title(f'{self.experiment_name} - Performance Improvement\n(Baseline F1: {baseline_f1:.4f})',
                    fontsize=14, fontweight='bold')
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        save_path = self.plots_dir / f"{self.experiment_name}_improvement.png"
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Saved improvement plot to {save_path}")

    def save_metrics_to_json(self):
        """Save all metrics to JSON file."""
        metrics = {
            'train': self.train_metrics,
            'val': self.val_metrics,
            'learning_rates': self.learning_rates
        }

        save_path = self.output_dir / f"{self.experiment_name}_metrics.json"
        with open(save_path, 'w') as f:
            json.dump(metrics, f, indent=2)
        print(f"Saved metrics to {save_path}")

    def generate_all_plots(self, y_true=None, y_pred=None, epoch=None,
                          train_counts=None, val_counts=None, baseline_f1=None):
        """Generate all plots at once."""
        print(f"\n{'='*60}")
        print(f"Generating visualization plots for {self.experiment_name}")
        print(f"{'='*60}")

        self.plot_training_curves()
        self.plot_class_performance()

        if y_true is not None and y_pred is not None:
            self.plot_confusion_matrix(y_true, y_pred, epoch=epoch)

        self.plot_learning_rate()
        self.plot_loss_components()
        self.plot_metrics_summary()

        if train_counts is not None and val_counts is not None:
            self.plot_class_distribution(train_counts, val_counts)

        if baseline_f1 is not None:
            self.plot_improvement_over_baseline(baseline_f1)

        self.save_metrics_to_json()

        print(f"{'='*60}")
        print(f"All plots saved to {self.plots_dir}")
        print(f"{'='*60}\n")


def compare_experiments(exp_results: dict, output_dir: str, metric: str = 'f1'):
    """
    Plot 9: Compare multiple experiments.

    Args:
        exp_results: Dict of {exp_name: {'val_f1': [...], 'val_acc': [...]}}
        output_dir: Output directory
        metric: Metric to compare
    """
    fig, ax = plt.subplots(figsize=(12, 6))

    colors = plt.cm.tab10(np.linspace(0, 1, len(exp_results)))

    for i, (exp_name, metrics) in enumerate(exp_results.items()):
        if f'val_{metric}' in metrics:
            epochs = list(range(1, len(metrics[f'val_{metric}']) + 1))
            ax.plot(epochs, metrics[f'val_{metric}'], '-o', label=exp_name,
                   linewidth=2, markersize=5, color=colors[i])

    ax.set_xlabel('Epoch', fontsize=12)
    ax.set_ylabel(f'{metric.upper()} Score', fontsize=12)
    ax.set_title(f'Experiment Comparison - Validation {metric.upper()}',
                fontsize=14, fontweight='bold')
    ax.legend(fontsize=10, loc='best')
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    save_path = Path(output_dir) / f"comparison_{metric}.png"
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Saved comparison plot to {save_path}")


def plot_experiment_heatmap(results_df: pd.DataFrame, output_dir: str):
    """
    Plot 10: Heatmap of experiment results.

    Args:
        results_df: DataFrame with columns ['experiment', 'val_f1', 'val_acc', ...]
        output_dir: Output directory
    """
    # Pivot for heatmap
    metrics = ['val_f1', 'val_acc', 'pos_f1', 'neu_f1', 'neg_f1']
    available_metrics = [m for m in metrics if m in results_df.columns]

    if not available_metrics:
        return

    pivot_data = results_df[['experiment'] + available_metrics].set_index('experiment')

    fig, ax = plt.subplots(figsize=(10, max(6, len(pivot_data) * 0.5)))

    sns.heatmap(pivot_data, annot=True, fmt='.3f', cmap='RdYlGn',
               center=0.5, vmin=0, vmax=1, cbar_kws={'label': 'Score'},
               linewidths=0.5, ax=ax)

    ax.set_title('Experiment Results Heatmap', fontsize=14, fontweight='bold')
    ax.set_xlabel('Metrics', fontsize=12)
    ax.set_ylabel('Experiments', fontsize=12)

    plt.tight_layout()
    save_path = Path(output_dir) / "experiment_heatmap.png"
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Saved heatmap to {save_path}")

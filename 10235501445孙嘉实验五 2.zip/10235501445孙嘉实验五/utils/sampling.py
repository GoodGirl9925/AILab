"""
Data sampling strategies for handling class imbalance.
"""
import torch
from torch.utils.data import Sampler, WeightedRandomSampler
import numpy as np
from collections import Counter


class OversamplingStrategy:
    """
    Oversampling strategy for minority classes.
    Replicates samples from minority classes to balance the dataset.
    """

    def __init__(self, labels: list, target_class: int = None, balance_all: bool = False):
        """
        Args:
            labels: List of labels for all samples
            target_class: Specific class to oversample (None for all minority classes)
            balance_all: Whether to balance all classes to majority class count
        """
        self.labels = np.array(labels)
        self.target_class = target_class
        self.balance_all = balance_all

        # Count samples per class
        self.class_counts = Counter(labels)
        self.num_classes = len(self.class_counts)

    def get_sampler(self) -> WeightedRandomSampler:
        """
        Create a weighted random sampler for oversampling.

        Returns:
            WeightedRandomSampler instance
        """
        # Compute sample weights
        if self.balance_all:
            # Balance all classes to majority class count
            max_count = max(self.class_counts.values())
            class_weights = {cls: max_count / count for cls, count in self.class_counts.items()}
        elif self.target_class is not None:
            # Oversample only target class
            max_count = max(self.class_counts.values())
            class_weights = {cls: 1.0 for cls in self.class_counts.keys()}
            class_weights[self.target_class] = max_count / self.class_counts[self.target_class]
        else:
            # Inverse frequency weighting
            total_samples = len(self.labels)
            class_weights = {cls: total_samples / (self.num_classes * count)
                           for cls, count in self.class_counts.items()}

        # Assign weight to each sample
        sample_weights = np.array([class_weights[label] for label in self.labels])

        # Create sampler
        sampler = WeightedRandomSampler(
            weights=sample_weights,
            num_samples=len(sample_weights),
            replacement=True
        )

        return sampler

    def get_indices(self, num_samples: int = None) -> list:
        """
        Get oversampled indices.

        Args:
            num_samples: Target number of samples (default: balanced to majority class)

        Returns:
            List of sample indices
        """
        if num_samples is None:
            num_samples = max(self.class_counts.values()) * self.num_classes

        # Get indices for each class
        class_indices = {cls: np.where(self.labels == cls)[0] for cls in self.class_counts.keys()}

        # Oversample each class
        oversampled_indices = []
        samples_per_class = num_samples // self.num_classes

        for cls, indices in class_indices.items():
            if self.target_class is not None and cls != self.target_class:
                # Don't oversample non-target classes
                oversampled_indices.extend(indices)
            else:
                # Oversample to target count
                if len(indices) < samples_per_class:
                    # Need to replicate
                    resampled = np.random.choice(indices, size=samples_per_class, replace=True)
                    oversampled_indices.extend(resampled)
                else:
                    # Already have enough samples
                    oversampled_indices.extend(indices)

        return oversampled_indices


class SMOTEStrategy:
    """
    SMOTE-like strategy for text and image data.
    For text: synonym replacement
    For image: light augmentation
    """

    def __init__(self, labels: list, target_class: int = 1, k_neighbors: int = 5):
        """
        Args:
            labels: List of labels for all samples
            target_class: Class to apply SMOTE (default: neutral class = 1)
            k_neighbors: Number of nearest neighbors for SMOTE
        """
        self.labels = np.array(labels)
        self.target_class = target_class
        self.k_neighbors = k_neighbors

        # Get indices of target class
        self.target_indices = np.where(self.labels == target_class)[0]

    def get_synthetic_samples(self, num_synthetic: int) -> list:
        """
        Generate synthetic sample indices.

        Args:
            num_synthetic: Number of synthetic samples to generate

        Returns:
            List of (original_idx, neighbor_idx) pairs for augmentation
        """
        synthetic_pairs = []

        for _ in range(num_synthetic):
            # Randomly select a sample from target class
            idx = np.random.choice(self.target_indices)

            # Select a random neighbor from same class
            neighbor_idx = np.random.choice(self.target_indices)

            synthetic_pairs.append((idx, neighbor_idx))

        return synthetic_pairs


def get_balanced_sampler(labels: list, strategy: str = 'oversample', target_class: int = None):
    """
    Factory function to get balanced sampler.

    Args:
        labels: List of labels for all samples
        strategy: Sampling strategy ('oversample', 'weighted')
        target_class: Specific class to balance (None for all classes)

    Returns:
        Sampler instance or None
    """
    if strategy == 'oversample':
        sampler_strategy = OversamplingStrategy(labels, target_class=target_class, balance_all=True)
        return sampler_strategy.get_sampler()
    elif strategy == 'weighted':
        sampler_strategy = OversamplingStrategy(labels, target_class=target_class, balance_all=False)
        return sampler_strategy.get_sampler()
    elif strategy == 'none':
        return None
    else:
        raise ValueError(f"Unknown strategy: {strategy}")

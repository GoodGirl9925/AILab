"""Debug why test samples produce identical logits."""
import torch
from transformers import AutoTokenizer
from model import TextExpert
from config import LABEL2ID

# Load tokenizer
tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')

# Load model
model = TextExpert(
    model_name='bert-base-uncased',
    num_classes=3,
    hidden_dim=256,
    dropout=0.1
)
checkpoint = torch.load('./outputs/text_expert.pt', map_location='cpu')
model.load_state_dict(checkpoint)
model.eval()

# Test with different texts
test_texts = [
    "Energetic training today with our San Antonio New Dollars/New Partners trainees",
    "This is a great product! I love it!",
    "Terrible service, very disappointed.",
    "It's okay, nothing special."
]

print("Testing model with different texts:\n")
with torch.no_grad():
    for i, text in enumerate(test_texts):
        encoding = tokenizer(
            text,
            max_length=128,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )

        logits = model(encoding['input_ids'], encoding['attention_mask'])
        probs = torch.softmax(logits, dim=-1)
        pred = torch.argmax(logits, dim=-1).item()

        print(f"Text {i+1}: {text[:50]}...")
        print(f"  Logits: {logits[0].numpy()}")
        print(f"  Probs: {probs[0].numpy()}")
        print(f"  Pred: {pred}\n")

# Now check if the issue is with the actual test data loading
print("\n" + "="*80)
print("Checking actual test data loading:")
print("="*80 + "\n")

from data_loader import get_dataloaders
from config import get_config

args = get_config()
args.data_dir = './project5/data'
args.train_file = './project5/train.txt'
args.test_file = './project5/test_without_label.txt'
args.device = 'cpu'
args.mode = 'text_only'

_, _, test_loader, _, _ = get_dataloaders(args, mode='text_only')

# Get first batch
batch = next(iter(test_loader))
print(f"Batch size: {batch['input_ids'].shape[0]}")
print(f"Input IDs shape: {batch['input_ids'].shape}")

# Check if all input_ids are the same
print(f"\nFirst 3 samples' input_ids:")
for i in range(min(3, batch['input_ids'].shape[0])):
    print(f"  Sample {i}: {batch['input_ids'][i][:20].tolist()}...")  # First 20 tokens

# Check if they're identical
if batch['input_ids'].shape[0] > 1:
    all_same = torch.all(batch['input_ids'][0] == batch['input_ids'][1])
    print(f"\nAre first two samples identical? {all_same}")

# Decode to see actual text
print(f"\nDecoded texts:")
for i in range(min(3, batch['input_ids'].shape[0])):
    decoded = tokenizer.decode(batch['input_ids'][i], skip_special_tokens=True)
    print(f"  Sample {i}: {decoded[:100]}...")

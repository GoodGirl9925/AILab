#!/usr/bin/env python
"""
Unified experiment runner for five-phase experimental design.
Automates running experiments with different configurations and multiple random seeds.
"""
import os
import json
import subprocess
import argparse
from pathlib import Path
from datetime import datetime


# Experiment configurations for each phase
# PHASE1_TEXT_EXPERIMENTS = {
#     'T1-Raw': {'text_preprocess_strategy': 'raw'},
#     'T2-Basic': {'text_preprocess_strategy': 'basic'},
#     'T3-Clean': {'text_preprocess_strategy': 'clean'},
#     'T4-Emoji': {'text_preprocess_strategy': 'emoji_replace'},
#     'T5-Remove': {'text_preprocess_strategy': 'emoji_remove'},
# }

# PHASE1_IMAGE_EXPERIMENTS = {
#     'I1-None': {'image_augmentation_strategy': 'none'},
#     'I2-Light': {'image_augmentation_strategy': 'light'},
#     'I3-Medium': {'image_augmentation_strategy': 'medium'},
#     'I4-Strong': {'image_augmentation_strategy': 'strong'},
# }

# PHASE2_FUSION_EXPERIMENTS = {
#     'LF1-Fixed': {'fusion': 'late_fixed', 'use_expert': True},
#     'LF2-Learned': {'fusion': 'late_learned', 'use_expert': True},
#     'LF3-Entropy': {'fusion': 'late_entropy', 'use_expert': True},
#     'EF1-Token': {'fusion': 'early_token', 'use_expert': True},
#     'EF2-Cross': {'fusion': 'early_cross', 'use_expert': True},
# }

PHASE3_LOSS_EXPERIMENTS = {
    'L1-CE': {'loss_type': 'ce'},
    'L2-Weighted': {'loss_type': 'weighted_ce', 'class_weight_mode': 'inverse'},
    'L3-Focal': {'loss_type': 'focal', 'focal_gamma': 2.0, 'class_weight_mode': 'inverse'},
    'L4-LDAM': {'loss_type': 'ldam', 'ldam_max_m': 0.5, 'ldam_s': 30.0},
}

PHASE3_SAMPLING_EXPERIMENTS = {
    'D1-None': {'sampling_strategy': 'none'},
    'D2-Oversample': {'sampling_strategy': 'oversample', 'target_class': 1},  # neutral class
    'D3-Weighted': {'sampling_strategy': 'weighted'},
    'D4-Hybrid': {'sampling_strategy': 'oversample', 'target_class': 1, 'loss_type': 'focal', 'focal_gamma': 2.0},
}


def run_experiment(exp_name: str, config: dict, base_args: dict, seeds: list, output_dir: str):
    """
    Run a single experiment with multiple random seeds.

    Args:
        exp_name: Experiment name
        config: Experiment-specific configuration
        base_args: Base arguments for all experiments
        seeds: List of random seeds
        output_dir: Output directory for results
    """
    print(f"\n{'='*80}")
    print(f"Running Experiment: {exp_name}")
    print(f"{'='*80}")

    results = []

    for seed in seeds:
        print(f"\n--- Seed {seed} ---")

        # Build command
        cmd = ['python', 'train.py']

        # Add base arguments
        for key, value in base_args.items():
            if isinstance(value, bool):
                if value:
                    cmd.append(f'--{key}')
            else:
                cmd.extend([f'--{key}', str(value)])

        # Add experiment-specific arguments
        for key, value in config.items():
            if isinstance(value, bool):
                if value:
                    cmd.append(f'--{key}')
            else:
                cmd.extend([f'--{key}', str(value)])

        # Add seed
        cmd.extend(['--seed', str(seed)])

        # Set output directory
        exp_output_dir = os.path.join(output_dir, exp_name, f'seed_{seed}')
        cmd.extend(['--output_dir', exp_output_dir])

        # Run command
        print(f"Command: {' '.join(cmd)}")
        try:
            result = subprocess.run(cmd, check=True, capture_output=True, text=True)
            print(result.stdout)
            results.append({'seed': seed, 'status': 'success'})
        except subprocess.CalledProcessError as e:
            print(f"Error running experiment: {e}")
            print(e.stderr)
            results.append({'seed': seed, 'status': 'failed', 'error': str(e)})

    # Save experiment summary
    summary = {
        'experiment_name': exp_name,
        'config': config,
        'seeds': seeds,
        'results': results,
        'timestamp': datetime.now().isoformat()
    }

    summary_file = os.path.join(output_dir, exp_name, 'summary.json')
    os.makedirs(os.path.dirname(summary_file), exist_ok=True)
    with open(summary_file, 'w') as f:
        json.dump(summary, f, indent=2)

    print(f"\nExperiment summary saved to: {summary_file}")


# def run_phase1_text(args):
#     """Run Phase 1: Text preprocessing experiments."""
#     print("\n" + "="*80)
#     print("PHASE 1: Text Preprocessing Experiments")
#     print("="*80)

#     base_args = {
#         'mode': 'text_only',
#         'num_epochs': args.num_epochs,
#         'batch_size': args.batch_size,
#         'early_stopping': True,
#         'patience': 3,
#     }

#     for exp_name, config in PHASE1_TEXT_EXPERIMENTS.items():
#         run_experiment(exp_name, config, base_args, args.seeds, args.output_dir)


# def run_phase1_image(args):
#     """Run Phase 1: Image augmentation experiments."""
#     print("\n" + "="*80)
#     print("PHASE 1: Image Augmentation Experiments")
#     print("="*80)

#     base_args = {
#         'mode': 'image_only',
#         'num_epochs': args.num_epochs,
#         'batch_size': args.batch_size,
#         'early_stopping': True,
#         'patience': 3,
#     }

#     for exp_name, config in PHASE1_IMAGE_EXPERIMENTS.items():
#         run_experiment(exp_name, config, base_args, args.seeds, args.output_dir)


# def run_phase2(args):
#     """Run Phase 2: Fusion strategy experiments."""
#     print("\n" + "="*80)
#     print("PHASE 2: Fusion Strategy Experiments")
#     print("="*80)

#     base_args = {
#         'mode': 'multimodal',
#         'num_epochs': args.num_epochs,
#         'batch_size': args.batch_size,
#         'early_stopping': True,
#         'patience': 3,
#         'text_preprocess_strategy': args.best_text_strategy,
#         'image_augmentation_strategy': args.best_image_strategy,
#     }

#     for exp_name, config in PHASE2_FUSION_EXPERIMENTS.items():
#         run_experiment(exp_name, config, base_args, args.seeds, args.output_dir)


def run_phase3_loss(args):
    """Run Phase 3: Loss function experiments."""
    print("\n" + "="*80)
    print("PHASE 3: Loss Function Experiments")
    print("="*80)

    base_args = {
        'mode': 'multimodal',
        'fusion': args.best_fusion,
        'use_expert': True,
        'num_epochs': args.num_epochs,
        'batch_size': args.batch_size,
        'early_stopping': True,
        'patience': 3,
        'text_preprocess_strategy': args.best_text_strategy,
        'image_augmentation_strategy': args.best_image_strategy,
    }

    for exp_name, config in PHASE3_LOSS_EXPERIMENTS.items():
        run_experiment(exp_name, config, base_args, args.seeds, args.output_dir)


def run_phase3_sampling(args):
    """Run Phase 3: Sampling strategy experiments."""
    print("\n" + "="*80)
    print("PHASE 3: Sampling Strategy Experiments")
    print("="*80)

    base_args = {
        'mode': 'multimodal',
        'fusion': args.best_fusion,
        'use_expert': True,
        'num_epochs': args.num_epochs,
        'batch_size': args.batch_size,
        'early_stopping': True,
        'patience': 3,
        'text_preprocess_strategy': args.best_text_strategy,
        'image_augmentation_strategy': args.best_image_strategy,
    }

    for exp_name, config in PHASE3_SAMPLING_EXPERIMENTS.items():
        run_experiment(exp_name, config, base_args, args.seeds, args.output_dir)


def main():
    parser = argparse.ArgumentParser(description='Run five-phase experiments')

    # Experiment selection
    parser.add_argument('--phase', type=str, required=True,
                        # choices=['1_text', '1_image', '2', '3_loss', '3_sampling', 'all'],
                        # help='Which phase to run')
                        choices=['3_loss', '3_sampling', 'all'],
                        help='Which phase to run')

    # Common settings
    parser.add_argument('--seeds', type=int, nargs='+', default=[42, 2024, 2026],
                        help='Random seeds for experiments')
    parser.add_argument('--num_epochs', type=int, default=10,
                        help='Number of training epochs')
    parser.add_argument('--batch_size', type=int, default=32,
                        help='Batch size')
    parser.add_argument('--output_dir', type=str, default='./experiment_results',
                        help='Output directory for all experiments')

    # Best strategies from previous phases (for later phases)
    parser.add_argument('--best_text_strategy', type=str, default='clean',
                        help='Best text preprocessing strategy from Phase 1')
    parser.add_argument('--best_image_strategy', type=str, default='medium',
                        help='Best image augmentation strategy from Phase 1')
    parser.add_argument('--best_fusion', type=str, default='attention',
                        help='Best fusion strategy from Phase 2')

    args = parser.parse_args()

    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)

    # Run selected phase(s)
    if args.phase == '1_text' or args.phase == 'all':
        run_phase1_text(args) 

    if args.phase == '1_image' or args.phase == 'all':
        run_phase1_image(args)

    if args.phase == '2' or args.phase == 'all':
        run_phase2(args)

    if args.phase == '3_loss' or args.phase == 'all':
        run_phase3_loss(args)

    if args.phase == '3_sampling' or args.phase == 'all':
        run_phase3_sampling(args)

    print("\n" + "="*80)
    print("All experiments completed!")
    print(f"Results saved to: {args.output_dir}")
    print("="*80)


if __name__ == '__main__':
    main()

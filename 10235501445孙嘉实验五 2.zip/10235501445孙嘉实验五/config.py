"""
Configuration file for multimodal sentiment analysis experiments.
"""
import argparse


def get_config():
    parser = argparse.ArgumentParser(description='Multimodal Sentiment Analysis')

    # Data paths
    parser.add_argument('--data_dir', type=str, default='../project5/data',
                        help='Directory containing text and image files')
    parser.add_argument('--train_file', type=str, default='../project5/train.txt',
                        help='Path to training labels file')
    parser.add_argument('--test_file', type=str, default='../project5/test_without_label.txt',
                        help='Path to test file')
    parser.add_argument('--output_dir', type=str, default='./outputs',
                        help='Directory to save model checkpoints and predictions')

    # Model settings
    parser.add_argument('--mode', type=str, default='multimodal',
                        choices=['text_only', 'image_only', 'multimodal'],
                        help='Training mode: text_only, image_only, or multimodal')
    parser.add_argument('--text_encoder', type=str, default='bert-base-uncased',
                        help='Text encoder model name')
    parser.add_argument('--image_encoder', type=str, default='openai/clip-vit-base-patch32',
                        help='Image encoder model name')
    parser.add_argument('--hidden_dim', type=int, default=256,
                        help='Hidden dimension for fusion and classifier')
    parser.add_argument('--num_classes', type=int, default=3,
                        help='Number of sentiment classes')
    parser.add_argument('--dropout', type=float, default=0.1,
                        help='Dropout rate')

    # Fusion settings
    parser.add_argument('--fusion', type=str, default='concat',
                        choices=['concat', 'add', 'attention', 'gate',
                                'late_fixed', 'late_learned', 'late_entropy',
                                'early_token', 'early_cross'],
                        help='Fusion strategy')
    parser.add_argument('--num_attention_heads', type=int, default=4,
                        help='Number of attention heads for cross-modal attention')

    # Expert settings
    parser.add_argument('--use_expert', action='store_true',
                        help='Use pre-trained expert models')
    parser.add_argument('--text_expert_path', type=str, default='./outputs/text_expert.pt',
                        help='Path to pre-trained text expert')
    parser.add_argument('--image_expert_path', type=str, default='./outputs/image_expert.pt',
                        help='Path to pre-trained image expert')
    parser.add_argument('--freeze_expert', type=str, default='none',
                        choices=['none', 'partial', 'full'],
                        help='Expert freezing strategy: none, partial, or full')

    # Consistency loss settings
    parser.add_argument('--use_consistency_loss', action='store_true',
                        help='Use emotion consistency loss (KL divergence)')
    parser.add_argument('--consistency_lambda', type=float, default=0.1,
                        help='Weight for consistency loss')

    # Class imbalance handling (Phase 3)
    parser.add_argument('--loss_type', type=str, default='ce',
                        choices=['ce', 'weighted_ce', 'focal', 'ldam'],
                        help='Loss function type for handling class imbalance')
    parser.add_argument('--class_weight_mode', type=str, default='none',
                        choices=['none', 'inverse', 'inverse_sqrt', 'effective'],
                        help='Class weighting mode')
    parser.add_argument('--focal_gamma', type=float, default=2.0,
                        help='Gamma parameter for Focal Loss')
    parser.add_argument('--ldam_max_m', type=float, default=0.5,
                        help='Maximum margin for LDAM Loss')
    parser.add_argument('--ldam_s', type=float, default=30.0,
                        help='Scale parameter for LDAM Loss')
    parser.add_argument('--sampling_strategy', type=str, default='none',
                        choices=['none', 'oversample', 'weighted'],
                        help='Data sampling strategy for class imbalance')
    parser.add_argument('--target_class', type=int, default=None,
                        help='Target class for oversampling (None for all classes)')

    # Training settings
    parser.add_argument('--batch_size', type=int, default=32,
                        help='Batch size for training')
    parser.add_argument('--num_epochs', type=int, default=10,
                        help='Number of training epochs')
    parser.add_argument('--encoder_lr', type=float, default=1e-5,
                        help='Learning rate for encoders')
    parser.add_argument('--classifier_lr', type=float, default=1e-4,
                        help='Learning rate for fusion and classifier')
    parser.add_argument('--weight_decay', type=float, default=0.01,
                        help='Weight decay for AdamW')
    parser.add_argument('--warmup_ratio', type=float, default=0.1,
                        help='Warmup ratio for learning rate scheduler')
    parser.add_argument('--max_grad_norm', type=float, default=1.0,
                        help='Max gradient norm for clipping')

    # Early stopping
    parser.add_argument('--early_stopping', action='store_true',
                        help='Enable early stopping')
    parser.add_argument('--patience', type=int, default=3,
                        help='Patience for early stopping')

    # Data settings
    parser.add_argument('--max_text_length', type=int, default=128,
                        help='Maximum text sequence length')
    parser.add_argument('--image_size', type=int, default=224,
                        help='Image size for preprocessing')
    parser.add_argument('--val_ratio', type=float, default=0.2,
                        help='Validation set ratio')

    # Data preprocessing and augmentation (Phase 1)
    parser.add_argument('--text_preprocess_strategy', type=str, default='raw',
                        choices=['raw', 'basic', 'clean', 'emoji_replace', 'emoji_remove'],
                        help='Text preprocessing strategy')
    parser.add_argument('--image_augmentation_strategy', type=str, default='none',
                        choices=['none', 'light', 'medium', 'strong'],
                        help='Image augmentation strategy')

    # Reproducibility
    parser.add_argument('--seed', type=int, default=42,
                        help='Random seed for reproducibility')

    # Device
    parser.add_argument('--device', type=str, default='cuda',
                        help='Device to use (cuda or cpu)')
    parser.add_argument('--num_workers', type=int, default=4,
                        help='Number of data loading workers')

    args = parser.parse_args()
    return args


# Label mappings
LABEL2ID = {'positive': 0, 'neutral': 1, 'negative': 2}
ID2LABEL = {0: 'positive', 1: 'neutral', 2: 'negative'}

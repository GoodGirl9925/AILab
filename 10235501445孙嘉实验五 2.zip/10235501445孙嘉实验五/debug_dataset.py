"""Debug dataset loading issue."""
import pandas as pd
from transformers import AutoTokenizer
from data_loader import TextOnlyDataset

# Load test data
test_df = pd.read_csv('./project5/test_without_label.txt')
print(f"Test dataframe shape: {test_df.shape}")
print(f"Test dataframe columns: {test_df.columns.tolist()}")
print(f"First 5 rows:")
print(test_df.head())

# Initialize tokenizer
tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')

# Create dataset
dataset = TextOnlyDataset(
    data_df=test_df,
    data_dir='./project5/data',
    tokenizer=tokenizer,
    max_text_length=128,
    is_test=True,
    text_preprocess_strategy='raw'
)

print(f"\nDataset length: {len(dataset)}")

# Get first few samples
print("\nFirst 3 samples:")
for i in range(min(3, len(dataset))):
    sample = dataset[i]
    guid = sample['guid']
    input_ids = sample['input_ids']

    # Decode
    decoded = tokenizer.decode(input_ids, skip_special_tokens=True)

    print(f"\nSample {i}:")
    print(f"  GUID: {guid}")
    print(f"  Input IDs (first 20): {input_ids[:20].tolist()}")
    print(f"  Decoded text: '{decoded}'")
    print(f"  Text length: {len(decoded)}")

    # Try to read the file directly
    import os
    text_path = os.path.join('./project5/data', f"{guid}.txt")
    if os.path.exists(text_path):
        with open(text_path, 'r', encoding='utf-8') as f:
            raw_text = f.read().strip()
        print(f"  Raw file content: '{raw_text}'")
    else:
        print(f"  File not found: {text_path}")

"""Fixed prediction script - diagnose and fix the all-negative prediction bug."""
import torch
import pandas as pd
from tqdm import tqdm
from model import TextExpert
from data_loader import get_dataloaders
from config import get_config, ID2LABEL

args = get_config()
args.data_dir = './project5/data'
args.train_file = './project5/train.txt'
args.test_file = './project5/test_without_label.txt'
args.device = 'cuda' if torch.cuda.is_available() else 'cpu'
args.mode = 'text_only'

print(f"Device: {args.device}")

# Load text expert
model = TextExpert(
    model_name=args.text_encoder,
    num_classes=args.num_classes,
    hidden_dim=args.hidden_dim,
    dropout=args.dropout
)

checkpoint = torch.load('./outputs/text_expert.pt', map_location=args.device)
model.load_state_dict(checkpoint)
model = model.to(args.device)

# CRITICAL: Make sure model is in eval mode
model.eval()

# Check if model has any frozen layers
print("\nModel structure:")
for name, param in model.named_parameters():
    print(f"  {name}: requires_grad={param.requires_grad}, shape={param.shape}")

# Get test data
_, _, test_loader, _, _ = get_dataloaders(args, mode='text_only')

# Test on validation set first to see if model works
_, val_loader, _, _, _ = get_dataloaders(args, mode='text_only')

print("\n=== Testing on validation set (with labels) ===")
val_preds = []
val_labels = []
with torch.no_grad():
    for batch in tqdm(list(val_loader)[:5], desc="Val"):  # Just first 5 batches
        input_ids = batch['input_ids'].to(args.device)
        attention_mask = batch['attention_mask'].to(args.device)
        labels = batch['label'].cpu().numpy()

        logits = model(input_ids, attention_mask)
        preds = torch.argmax(logits, dim=-1).cpu().numpy()

        val_preds.extend(preds)
        val_labels.extend(labels)

# Check validation predictions
from collections import Counter
print(f"\nValidation predictions distribution: {Counter(val_preds)}")
print(f"Validation labels distribution: {Counter(val_labels)}")
print(f"Validation accuracy: {sum(p==l for p,l in zip(val_preds, val_labels)) / len(val_preds):.4f}")

# Now predict on test set
print("\n=== Predicting on test set ===")
predictions = []
guids = []

with torch.no_grad():
    for batch in tqdm(test_loader, desc="Test"):
        input_ids = batch['input_ids'].to(args.device)
        attention_mask = batch['attention_mask'].to(args.device)
        batch_guids = batch['guid']

        logits = model(input_ids, attention_mask)

        # Debug: print first batch logits
        if len(predictions) == 0:
            print(f"\nFirst batch logits (first 3 samples):")
            for i in range(min(3, logits.shape[0])):
                print(f"  {logits[i].cpu().numpy()}")

        preds = torch.argmax(logits, dim=-1).cpu().numpy()
        predictions.extend(preds)
        guids.extend(batch_guids)

# Check test predictions distribution
print(f"\nTest predictions distribution: {Counter(predictions)}")

# Convert to labels
pred_labels = [ID2LABEL[p] for p in predictions]

# Save
output_df = pd.DataFrame({'guid': guids, 'tag': pred_labels})
output_df.to_csv('./outputs/predictions_fixed.txt', index=False)
print(f"\nPredictions saved to ./outputs/predictions_fixed.txt")

"""
Multimodal sentiment analysis model.
Combines text and image encoders with various fusion strategies.
"""
import torch
import torch.nn as nn
from .text_encoder import TextEncoder
from .image_encoder import ImageEncoder
from .fusion import get_fusion_module
from .classifier import SentimentClassifier


class MultimodalSentimentModel(nn.Module):
    """
    Expert-guided multimodal sentiment analysis model.

    Architecture:
        - Text Encoder (BERT/RoBERTa) -> H_text, p_text(y)
        - Image Encoder (CLIP-ViT) -> H_img, p_img(y)
        - Fusion Module -> H_fused
        - Classifier -> final logits
    """

    def __init__(self,
                 text_encoder_name: str = 'bert-base-uncased',
                 image_encoder_name: str = 'openai/clip-vit-base-patch32',
                 hidden_dim: int = 256,
                 num_classes: int = 3,
                 fusion_type: str = 'concat',
                 num_attention_heads: int = 4,
                 dropout: float = 0.1):
        super().__init__()

        self.hidden_dim = hidden_dim
        self.num_classes = num_classes
        self.fusion_type = fusion_type
        self.is_late_fusion = fusion_type in ['late_fixed', 'late_learned', 'late_entropy']

        # Initialize encoders
        self.text_encoder = TextEncoder(
            model_name=text_encoder_name,
            num_classes=num_classes,
            hidden_dim=hidden_dim,
            dropout=dropout
        )

        self.image_encoder = ImageEncoder(
            model_name=image_encoder_name,
            num_classes=num_classes,
            hidden_dim=hidden_dim,
            dropout=dropout
        )

        # Initialize fusion module
        self.fusion = get_fusion_module(
            fusion_type=fusion_type,
            hidden_dim=hidden_dim,
            num_heads=num_attention_heads,
            dropout=dropout,
            num_classes=num_classes
        )

        # Final classifier (not needed for late fusion)
        if not self.is_late_fusion:
            self.classifier = SentimentClassifier(
                input_dim=self.fusion.output_dim,
                hidden_dim=hidden_dim,
                num_classes=num_classes,
                dropout=dropout
            )
        else:
            self.classifier = None  # Late fusion directly outputs logits

    def forward(self,
                input_ids: torch.Tensor,
                attention_mask: torch.Tensor,
                pixel_values: torch.Tensor,
                return_expert_logits: bool = False):
        """
        Forward pass through multimodal model.

        Args:
            input_ids: Text token IDs [batch_size, seq_len]
            attention_mask: Text attention mask [batch_size, seq_len]
            pixel_values: Preprocessed images [batch_size, 3, H, W]
            return_expert_logits: Whether to return individual expert logits

        Returns:
            logits: Final sentiment logits [batch_size, num_classes]
            (optional) text_logits: Text expert logits
            (optional) image_logits: Image expert logits
        """
        # Get text representations
        text_logits, text_emb = self.text_encoder(input_ids, attention_mask)

        # Get image representations
        image_logits, image_emb = self.image_encoder(pixel_values)

        # Late fusion: directly fuse logits
        if self.is_late_fusion:
            logits = self.fusion(text_logits, image_logits)
        else:
            # Early/mid fusion: fuse embeddings then classify
            fused_emb = self.fusion(text_emb, image_emb)
            logits = self.classifier(fused_emb)

        if return_expert_logits:
            return logits, text_logits, image_logits
        return logits

    def load_expert_weights(self,
                            text_expert_path: str = None,
                            image_expert_path: str = None,
                            device: str = 'cuda'):
        """
        Load pre-trained expert weights.

        Args:
            text_expert_path: Path to text expert checkpoint
            image_expert_path: Path to image expert checkpoint
            device: Device to load weights to
        """
        if text_expert_path:
            text_state = torch.load(text_expert_path, map_location=device)
            # Handle both full model and encoder-only checkpoints
            if 'encoder' in text_state:
                self.text_encoder.load_state_dict(text_state['encoder'])
            else:
                # Try to load from TextExpert format
                text_encoder_state = {k[len('encoder.'):]: v
                                      for k, v in text_state.items()
                                      if k.startswith('encoder.')}
                if text_encoder_state:
                    self.text_encoder.load_state_dict(text_encoder_state)
                else:
                    self.text_encoder.load_state_dict(text_state)
            print(f"Loaded text expert from {text_expert_path}")

        if image_expert_path:
            image_state = torch.load(image_expert_path, map_location=device)
            if 'encoder' in image_state:
                self.image_encoder.load_state_dict(image_state['encoder'])
            else:
                image_encoder_state = {k[len('encoder.'):]: v
                                       for k, v in image_state.items()
                                       if k.startswith('encoder.')}
                if image_encoder_state:
                    self.image_encoder.load_state_dict(image_encoder_state)
                else:
                    self.image_encoder.load_state_dict(image_state)
            print(f"Loaded image expert from {image_expert_path}")

    def freeze_experts(self, mode: str = 'none'):
        """
        Freeze expert encoders.

        Args:
            mode: Freezing mode
                - 'none': No freezing
                - 'partial': Freeze encoder backbone, train projection/classifier
                - 'full': Freeze entire expert modules
        """
        if mode == 'none':
            return

        if mode == 'full':
            for param in self.text_encoder.parameters():
                param.requires_grad = False
            for param in self.image_encoder.parameters():
                param.requires_grad = False
            print("Fully frozen text and image encoders")

        elif mode == 'partial':
            # Freeze backbone encoders only
            for param in self.text_encoder.encoder.parameters():
                param.requires_grad = False
            for param in self.image_encoder.encoder.parameters():
                param.requires_grad = False
            print("Partially frozen encoders (backbone only)")

    def get_parameter_groups(self, encoder_lr: float, classifier_lr: float):
        """
        Get parameter groups with differential learning rates.

        Args:
            encoder_lr: Learning rate for encoder parameters
            classifier_lr: Learning rate for fusion and classifier parameters

        Returns:
            List of parameter groups for optimizer
        """
        encoder_params = []
        classifier_params = []

        # Text encoder parameters
        encoder_params.extend(list(self.text_encoder.get_encoder_params()))
        classifier_params.extend(list(self.text_encoder.get_classifier_params()))

        # Image encoder parameters
        encoder_params.extend(list(self.image_encoder.get_encoder_params()))
        classifier_params.extend(list(self.image_encoder.get_classifier_params()))

        # Fusion parameters
        classifier_params.extend(list(self.fusion.parameters()))

        # Classifier parameters (if not late fusion)
        if not self.is_late_fusion:
            classifier_params.extend(list(self.classifier.parameters()))

        param_groups = [
            {'params': encoder_params, 'lr': encoder_lr},
            {'params': classifier_params, 'lr': classifier_lr}
        ]

        return param_groups

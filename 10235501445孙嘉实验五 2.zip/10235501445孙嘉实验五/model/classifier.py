"""
Classifier module for sentiment prediction.
"""
import torch
import torch.nn as nn


class SentimentClassifier(nn.Module):
    """
    MLP classifier for sentiment prediction.
    """

    def __init__(self,
                 input_dim: int,
                 hidden_dim: int = 256,
                 num_classes: int = 3,
                 dropout: float = 0.1):
        super().__init__()

        self.classifier = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, num_classes)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Input features [batch_size, input_dim]

        Returns:
            Logits [batch_size, num_classes]
        """
        return self.classifier(x)

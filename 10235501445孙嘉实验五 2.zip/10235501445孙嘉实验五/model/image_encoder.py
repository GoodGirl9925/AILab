"""
Image encoder module using CLIP-ViT.
Outputs sentiment logits and embeddings for multimodal fusion.
"""
import torch
import torch.nn as nn
from transformers import CLIPVisionModel, CLIPVisionConfig


class ImageEncoder(nn.Module):
    """
    Image encoder using CLIP-ViT-B/32.

    Outputs:
        - Sentiment logits: p_img(y)
        - Hidden embeddings: H_img
    """

    def __init__(self,
                 model_name: str = 'openai/clip-vit-base-patch32',
                 num_classes: int = 3,
                 hidden_dim: int = 256,
                 dropout: float = 0.1):
        super().__init__()

        self.config = CLIPVisionConfig.from_pretrained(model_name)
        self.encoder = CLIPVisionModel.from_pretrained(model_name)
        self.encoder_dim = self.config.hidden_size  # 768 for ViT-B/32

        # Projection layer to common hidden dimension
        self.projection = nn.Sequential(
            nn.Linear(self.encoder_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )

        # Sentiment classifier head
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes)
        )

        self.hidden_dim = hidden_dim

    def forward(self, pixel_values: torch.Tensor):
        """
        Forward pass through image encoder.

        Args:
            pixel_values: Preprocessed images [batch_size, 3, H, W]

        Returns:
            logits: Sentiment logits [batch_size, num_classes]
            embeddings: Hidden embeddings [batch_size, hidden_dim]
        """
        # Get encoder outputs
        outputs = self.encoder(pixel_values=pixel_values)

        # Use pooled output (CLS token equivalent)
        pooled_output = outputs.pooler_output  # [batch_size, encoder_dim]

        # Project to common dimension
        embeddings = self.projection(pooled_output)

        # Get sentiment logits
        logits = self.classifier(embeddings)

        return logits, embeddings

    def get_encoder_params(self):
        """Get encoder parameters for differential learning rate."""
        return self.encoder.parameters()

    def get_classifier_params(self):
        """Get classifier parameters for differential learning rate."""
        return list(self.projection.parameters()) + list(self.classifier.parameters())


class ImageExpert(nn.Module):
    """
    Standalone image expert for single-modality training.
    Wraps ImageEncoder for easier training and saving.
    """

    def __init__(self,
                 model_name: str = 'openai/clip-vit-base-patch32',
                 num_classes: int = 3,
                 hidden_dim: int = 256,
                 dropout: float = 0.1):
        super().__init__()
        self.encoder = ImageEncoder(
            model_name=model_name,
            num_classes=num_classes,
            hidden_dim=hidden_dim,
            dropout=dropout
        )

    def forward(self, pixel_values: torch.Tensor):
        """Forward pass returning only logits for training."""
        logits, _ = self.encoder(pixel_values)
        return logits

    def get_encoder(self) -> ImageEncoder:
        """Get the underlying ImageEncoder for multimodal fusion."""
        return self.encoder

"""
Text encoder module using BERT/RoBERTa.
Outputs sentiment logits and embeddings for multimodal fusion.
"""
import torch
import torch.nn as nn
from transformers import AutoModel, AutoConfig


class TextEncoder(nn.Module):
    """
    Text encoder using pre-trained BERT/RoBERTa.

    Outputs:
        - Sentiment logits: p_text(y)
        - Hidden embeddings: H_text (from second-to-last layer)
    """

    def __init__(self,
                 model_name: str = 'bert-base-uncased',
                 num_classes: int = 3,
                 hidden_dim: int = 256,
                 dropout: float = 0.1):
        super().__init__()

        self.config = AutoConfig.from_pretrained(model_name, output_hidden_states=True)
        self.encoder = AutoModel.from_pretrained(model_name, config=self.config)
        self.encoder_dim = self.config.hidden_size  # 768 for BERT-base

        # Projection layer to common hidden dimension
        self.projection = nn.Sequential(
            nn.Linear(self.encoder_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )

        # Sentiment classifier head
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes)
        )

        self.hidden_dim = hidden_dim

    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor):
        """
        Forward pass through text encoder.

        Args:
            input_ids: Token IDs [batch_size, seq_len]
            attention_mask: Attention mask [batch_size, seq_len]

        Returns:
            logits: Sentiment logits [batch_size, num_classes]
            embeddings: Hidden embeddings [batch_size, hidden_dim]
        """
        # Get encoder out all hidden states
        outputs = self.encoder(input_ids=input_ids, attention_mask=attention_mask)

        # Use [CLS] token from second-to-last layer for embeddings
        # hidden_states is a tuple of (embedding_output, layer1, layer2, ..., layerN)
        hidden_states = outputs.hidden_states
        second_to_last = hidden_states[-2]  # Second-to-last layer
        cls_embedding = second_to_last[:, 0, :]  # [CLS] token

        # Project to common dimension
        embeddings = self.projection(cls_embedding)

        # Get sentiment logits
        logits = self.classifier(embeddings)

        return logits, embeddings

    def get_encoder_params(self):
        """Get encoder parameters for differential learning rate."""
        return self.encoder.parameters()

    def get_classifier_params(self):
        """Get classifier parameters for differential learning rate."""
        return list(self.projection.parameters()) + list(self.classifier.parameters())


class TextExpert(nn.Module):
    """
    Standalone text expert for single-modality training.
    Wraps TextEncoder for easier training and saving.
    """

    def __init__(self,
                 model_name: str = 'bert-base-uncased',
                 num_classes: int = 3,
                 hidden_dim: int = 256,
                 dropout: float = 0.1):
        super().__init__()
        self.encoder = TextEncoder(
            model_name=model_name,
            num_classes=num_classes,
            hidden_dim=hidden_dim,
            dropout=dropout
        )

    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor):
        """Forward pass returning only logits for training."""
        logits, _ = self.encoder(input_ids, attention_mask)
        return logits

    def get_encoder(self) -> TextEncoder:
        """Get the underlying TextEncoder for multimodal fusion."""
        return self.encoder

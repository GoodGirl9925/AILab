"""
Multimodal fusion modules.
Implements various fusion strategies: concat, add, attention, gate, late_fusion, early_fusion.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import math


class LateFusionFixed(nn.Module):
    """
    Late Fusion with fixed weights (0.5:0.5).
    Fuses logits from text and image experts.
    """

    def __init__(self, num_classes: int = 3):
        super().__init__()
        self.num_classes = num_classes
        self.output_dim = num_classes  # For compatibility

    def forward(self, text_logits: torch.Tensor, image_logits: torch.Tensor):
        """
        Args:
            text_logits: Text expert logits [batch_size, num_classes]
            image_logits: Image expert logits [batch_size, num_classes]

        Returns:
            Fused logits [batch_size, num_classes]
        """
        return 0.5 * text_logits + 0.5 * image_logits


class LateFusionLearned(nn.Module):
    """
    Late Fusion with learnable weight.
    Formula: logits = α * text_logits + (1-α) * image_logits
    """

    def __init__(self, num_classes: int = 3):
        super().__init__()
        self.num_classes = num_classes
        self.output_dim = num_classes

        # Learnable fusion weight (initialized to 0.5)
        self.alpha = nn.Parameter(torch.tensor(0.5))

    def forward(self, text_logits: torch.Tensor, image_logits: torch.Tensor):
        """
        Args:
            text_logits: Text expert logits [batch_size, num_classes]
            image_logits: Image expert logits [batch_size, num_classes]

        Returns:
            Fused logits [batch_size, num_classes]
        """
        # Clamp alpha to [0, 1]
        alpha = torch.sigmoid(self.alpha)
        return alpha * text_logits + (1 - alpha) * image_logits


class LateFusionEntropy(nn.Module):
    """
    Late Fusion with entropy-based dynamic weighting.
    Higher confidence (lower entropy) gets higher weight.
    """

    def __init__(self, num_classes: int = 3, temperature: float = 1.0):
        super().__init__()
        self.num_classes = num_classes
        self.output_dim = num_classes
        self.temperature = temperature

    def compute_entropy(self, logits: torch.Tensor) -> torch.Tensor:
        """Compute entropy of prediction distribution."""
        probs = F.softmax(logits / self.temperature, dim=-1)
        log_probs = F.log_softmax(logits / self.temperature, dim=-1)
        entropy = -(probs * log_probs).sum(dim=-1, keepdim=True)  # [batch_size, 1]
        return entropy

    def forward(self, text_logits: torch.Tensor, image_logits: torch.Tensor):
        """
        Args:
            text_logits: Text expert logits [batch_size, num_classes]
            image_logits: Image expert logits [batch_size, num_classes]

        Returns:
            Fused logits [batch_size, num_classes]
        """
        # Compute entropies
        text_entropy = self.compute_entropy(text_logits)  # [batch_size, 1]
        image_entropy = self.compute_entropy(image_logits)  # [batch_size, 1]

        # Inverse entropy as confidence (lower entropy = higher confidence)
        text_confidence = 1.0 / (text_entropy + 1e-8)
        image_confidence = 1.0 / (image_entropy + 1e-8)

        # Normalize weights
        total_confidence = text_confidence + image_confidence
        text_weight = text_confidence / total_confidence
        image_weight = image_confidence / total_confidence

        # Weighted fusion
        return text_weight * text_logits + image_weight * image_logits


class EarlyFusionToken(nn.Module):
    """
    Early Fusion by concatenating visual tokens to text tokens.
    Processes through a shared transformer layer.
    """

    def __init__(self, hidden_dim: int, num_heads: int = 4, dropout: float = 0.1):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads

        # Project image embedding to sequence of tokens
        self.image_to_tokens = nn.Linear(hidden_dim, hidden_dim * 4)  # 4 visual tokens

        # Transformer layer for joint processing
        self.transformer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=num_heads,
            dim_feedforward=hidden_dim * 4,
            dropout=dropout,
            batch_first=True
        )

        # Pooling to get final representation
        self.pooling = nn.Linear(hidden_dim, hidden_dim)
        self.layer_norm = nn.LayerNorm(hidden_dim)
        self.output_dim = hidden_dim

    def forward(self, text_emb: torch.Tensor, image_emb: torch.Tensor):
        """
        Args:
            text_emb: Text embeddings [batch_size, hidden_dim]
            image_emb: Image embeddings [batch_size, hidden_dim]

        Returns:
            Fused embeddings [batch_size, hidden_dim]
        """
        batch_size = text_emb.size(0)

        # Convert embeddings to token sequences
        text_tokens = text_emb.unsqueeze(1)  # [batch_size, 1, hidden_dim]

        # Create multiple visual tokens
        image_tokens = self.image_to_tokens(image_emb)  # [batch_size, hidden_dim * 4]
        image_tokens = image_tokens.view(batch_size, 4, self.hidden_dim)  # [batch_size, 4, hidden_dim]

        # Concatenate tokens
        combined_tokens = torch.cat([text_tokens, image_tokens], dim=1)  # [batch_size, 5, hidden_dim]

        # Process through transformer
        fused_tokens = self.transformer(combined_tokens)  # [batch_size, 5, hidden_dim]

        # Pool tokens (mean pooling)
        fused = fused_tokens.mean(dim=1)  # [batch_size, hidden_dim]
        fused = self.layer_norm(self.pooling(fused))

        return fused


class EarlyFusionCross(nn.Module):
    """
    Early Fusion with cross-modal attention at intermediate layer.
    Similar to CrossModalAttention but designed for early fusion.
    """

    def __init__(self, hidden_dim: int, num_heads: int = 4, dropout: float = 0.1):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads

        assert hidden_dim % num_heads == 0, "hidden_dim must be divisible by num_heads"

        # Cross-attention layers
        self.cross_attention = nn.MultiheadAttention(
            embed_dim=hidden_dim,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )

        # Feed-forward network
        self.ffn = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim * 4),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 4, hidden_dim),
            nn.Dropout(dropout)
        )

        self.layer_norm1 = nn.LayerNorm(hidden_dim)
        self.layer_norm2 = nn.LayerNorm(hidden_dim)
        self.output_dim = hidden_dim

    def forward(self, text_emb: torch.Tensor, image_emb: torch.Tensor):
        """
        Args:
            text_emb: Text embeddings [batch_size, hidden_dim]
            image_emb: Image embeddings [batch_size, hidden_dim]

        Returns:
            Fused embeddings [batch_size, hidden_dim]
        """
        # Add sequence dimension
        text_seq = text_emb.unsqueeze(1)  # [batch_size, 1, hidden_dim]
        image_seq = image_emb.unsqueeze(1)  # [batch_size, 1, hidden_dim]

        # Concatenate for joint attention
        combined = torch.cat([text_seq, image_seq], dim=1)  # [batch_size, 2, hidden_dim]

        # Self-attention on combined sequence
        attn_output, _ = self.cross_attention(combined, combined, combined)
        combined = self.layer_norm1(combined + attn_output)

        # Feed-forward
        ffn_output = self.ffn(combined)
        combined = self.layer_norm2(combined + ffn_output)

        # Pool to get final representation
        fused = combined.mean(dim=1)  # [batch_size, hidden_dim]

        return fused


class ConcatFusion(nn.Module):
    """
    Concatenation-based fusion.
    Simply concatenates text and image embeddings.
    """

    def __init__(self, hidden_dim: int, dropout: float = 0.1):
        super().__init__()
        self.projection = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )
        self.output_dim = hidden_dim

    def forward(self, text_emb: torch.Tensor, image_emb: torch.Tensor):
        """
        Args:
            text_emb: Text embeddings [batch_size, hidden_dim]
            image_emb: Image embeddings [batch_size, hidden_dim]

        Returns:
            Fused embeddings [batch_size, hidden_dim]
        """
        concat = torch.cat([text_emb, image_emb], dim=-1)
        return self.projection(concat)


class AddFusion(nn.Module):
    """
    Addition-based fusion.
    Element-wise addition of text and image embeddings.
    """

    def __init__(self, hidden_dim: int, dropout: float = 0.1):
        super().__init__()
        self.layer_norm = nn.LayerNorm(hidden_dim)
        self.dropout = nn.Dropout(dropout)
        self.output_dim = hidden_dim

    def forward(self, text_emb: torch.Tensor, image_emb: torch.Tensor):
        """
        Args:
            text_emb: Text embeddings [batch_size, hidden_dim]
            image_emb: Image embeddings [batch_size, hidden_dim]

        Returns:
            Fused embeddings [batch_size, hidden_dim]
        """
        fused = text_emb + image_emb
        return self.dropout(self.layer_norm(fused))


class CrossModalAttention(nn.Module):
    """
    Cross-modal attention fusion.
    Uses multi-head attention to fuse text and image modalities.
    """

    def __init__(self, hidden_dim: int, num_heads: int = 4, dropout: float = 0.1):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads

        assert hidden_dim % num_heads == 0, "hidden_dim must be divisible by num_heads"

        # Query, Key, Value projections for both modalities
        self.text_q = nn.Linear(hidden_dim, hidden_dim)
        self.text_k = nn.Linear(hidden_dim, hidden_dim)
        self.text_v = nn.Linear(hidden_dim, hidden_dim)

        self.image_q = nn.Linear(hidden_dim, hidden_dim)
        self.image_k = nn.Linear(hidden_dim, hidden_dim)
        self.image_v = nn.Linear(hidden_dim, hidden_dim)

        # Output projection
        self.output_proj = nn.Linear(hidden_dim * 2, hidden_dim)
        self.layer_norm = nn.LayerNorm(hidden_dim)
        self.dropout = nn.Dropout(dropout)

        self.output_dim = hidden_dim

    def attention(self, query, key, value):
        """Compute scaled dot-product attention."""
        scores = torch.matmul(query, key.transpose(-2, -1)) / math.sqrt(self.head_dim)
        attn_weights = F.softmax(scores, dim=-1)
        attn_weights = self.dropout(attn_weights)
        return torch.matmul(attn_weights, value)

    def forward(self, text_emb: torch.Tensor, image_emb: torch.Tensor):
        """
        Args:
            text_emb: Text embeddings [batch_size, hidden_dim]
            image_emb: Image embeddings [batch_size, hidden_dim]

        Returns:
            Fused embeddings [batch_size, hidden_dim]
        """
        batch_size = text_emb.size(0)

        # Add sequence dimension for attention
        text_emb = text_emb.unsqueeze(1)  # [batch, 1, hidden]
        image_emb = image_emb.unsqueeze(1)  # [batch, 1, hidden]

        # Text attending to image
        t_q = self.text_q(text_emb).view(batch_size, 1, self.num_heads, self.head_dim).transpose(1, 2)
        i_k = self.image_k(image_emb).view(batch_size, 1, self.num_heads, self.head_dim).transpose(1, 2)
        i_v = self.image_v(image_emb).view(batch_size, 1, self.num_heads, self.head_dim).transpose(1, 2)
        text_attended = self.attention(t_q, i_k, i_v)
        text_attended = text_attended.transpose(1, 2).contiguous().view(batch_size, -1)

        # Image attending to text
        i_q = self.image_q(image_emb).view(batch_size, 1, self.num_heads, self.head_dim).transpose(1, 2)
        t_k = self.text_k(text_emb).view(batch_size, 1, self.num_heads, self.head_dim).transpose(1, 2)
        t_v = self.text_v(text_emb).view(batch_size, 1, self.num_heads, self.head_dim).transpose(1, 2)
        image_attended = self.attention(i_q, t_k, t_v)
        image_attended = image_attended.transpose(1, 2).contiguous().view(batch_size, -1)

        # Combine attended representations
        combined = torch.cat([text_attended, image_attended], dim=-1)
        fused = self.output_proj(combined)
        fused = self.layer_norm(fused)

        return fused


class EmotionGateFusion(nn.Module):
    """
    Emotion gate fusion.
    Uses learned gate to dynamically weight text and image contributions.

    Formula:
        α = sigmoid(W [H_text ; H_img])
        H = α * H_text + (1 - α) * H_img
    """

    def __init__(self, hidden_dim: int, dropout: float = 0.1):
        super().__init__()
        # Gate network
        self.gate = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )

        self.layer_norm = nn.LayerNorm(hidden_dim)
        self.dropout = nn.Dropout(dropout)
        self.output_dim = hidden_dim

    def forward(self, text_emb: torch.Tensor, image_emb: torch.Tensor):
        """
        Args:
            text_emb: Text embeddings [batch_size, hidden_dim]
            image_emb: Image embeddings [batch_size, hidden_dim]

        Returns:
            Fused embeddings [batch_size, hidden_dim]
            gate_weights: Gate values for analysis [batch_size, 1]
        """
        # Compute gate weight
        concat = torch.cat([text_emb, image_emb], dim=-1)
        alpha = self.gate(concat)  # [batch_size, 1]

        # Weighted combination
        fused = alpha * text_emb + (1 - alpha) * image_emb
        fused = self.dropout(self.layer_norm(fused))

        return fused


def get_fusion_module(fusion_type: str, hidden_dim: int, num_heads: int = 4, dropout: float = 0.1, num_classes: int = 3):
    """
    Factory function to get fusion module by type.

    Args:
        fusion_type: Type of fusion ('concat', 'add', 'attention', 'gate', 'late_fixed', 'late_learned', 'late_entropy', 'early_token', 'early_cross')
        hidden_dim: Hidden dimension
        num_heads: Number of attention heads (for attention fusion)
        dropout: Dropout rate
        num_classes: Number of classes (for late fusion)

    Returns:
        Fusion module
    """
    fusion_modules = {
        'concat': ConcatFusion,
        'add': AddFusion,
        'attention': CrossModalAttention,
        'gate': EmotionGateFusion,
        'late_fixed': LateFusionFixed,
        'late_learned': LateFusionLearned,
        'late_entropy': LateFusionEntropy,
        'early_token': EarlyFusionToken,
        'early_cross': EarlyFusionCross
    }

    if fusion_type not in fusion_modules:
        raise ValueError(f"Unknown fusion type: {fusion_type}. Choose from {list(fusion_modules.keys())}")

    # Late fusion modules
    if fusion_type in ['late_fixed', 'late_learned', 'late_entropy']:
        if fusion_type == 'late_entropy':
            return fusion_modules[fusion_type](num_classes, temperature=1.0)
        else:
            return fusion_modules[fusion_type](num_classes)

    # Early fusion and other modules
    elif fusion_type in ['attention', 'early_token', 'early_cross']:
        return fusion_modules[fusion_type](hidden_dim, num_heads, dropout)
    else:
        return fusion_modules[fusion_type](hidden_dim, dropout)

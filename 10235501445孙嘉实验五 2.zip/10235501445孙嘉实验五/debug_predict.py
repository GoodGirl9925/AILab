"""Quick debug script to check model predictions."""
import torch
import pandas as pd
from transformers import AutoTokenizer, CLIPImageProcessor
from model import MultimodalSentimentModel
from data_loader import get_dataloaders
from config import get_config, ID2LABEL
import sys

args = get_config()
args.data_dir = './project5/data'
args.train_file = './project5/train.txt'
args.test_file = './project5/test_without_label.txt'
args.device = 'cuda' if torch.cuda.is_available() else 'cpu'

print(f"Device: {args.device}")
print(f"ID2LABEL mapping: {ID2LABEL}")

# Load model
checkpoint = torch.load('./outputs/best_model.pt', map_location=args.device)
config = checkpoint['config']
model_state = checkpoint['model_state_dict']

model = MultimodalSentimentModel(
    text_encoder_name=config['text_encoder'],
    image_encoder_name=config['image_encoder'],
    hidden_dim=config['hidden_dim'],
    num_classes=config['num_classes'],
    fusion_type=config['fusion'],
    num_attention_heads=config.get('num_attention_heads', 4),
    dropout=config.get('dropout', 0.1)
)
model.load_state_dict(model_state)
model = model.to(args.device)
model.eval()

# Get test data
_, _, test_loader, _, _ = get_dataloaders(args, mode='multimodal')

# Check first batch
batch = next(iter(test_loader))
input_ids = batch['input_ids'].to(args.device)
attention_mask = batch['attention_mask'].to(args.device)
pixel_values = batch['pixel_values'].to(args.device)

with torch.no_grad():
    logits = model(input_ids, attention_mask, pixel_values)
    probs = torch.softmax(logits, dim=-1)
    preds = torch.argmax(logits, dim=-1)

    print(f"\nFirst batch size: {logits.shape[0]}")
    print(f"Logits shape: {logits.shape}")
    print(f"\nFirst 5 samples:")
    for i in range(min(5, logits.shape[0])):
        print(f"  Sample {i}:")
        print(f"    Logits: {logits[i].cpu().numpy()}")
        print(f"    Probs: {probs[i].cpu().numpy()}")
        print(f"    Pred: {preds[i].item()} -> {ID2LABEL[preds[i].item()]}")

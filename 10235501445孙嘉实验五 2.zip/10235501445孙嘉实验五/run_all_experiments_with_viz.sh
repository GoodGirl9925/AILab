#!/bin/bash
# 五阶段实验完整执行脚本（带可视化）
# 使用方法：bash run_all_experiments_with_viz.sh

set -e  # 遇到错误立即停止

echo "========================================================================"
echo "  多模态情感分析 - 五阶段实验（带自动可视化）"
echo "========================================================================"
echo ""
echo "本脚本将依次执行："
echo "  阶段1: 数据质量基线实验（文本预处理 + 图像增强）"
echo "  阶段2: 融合策略扩展实验（Late Fusion + Early Fusion）"
echo "  阶段3: 类别不平衡处理实验（损失函数 + 采样策略）"
echo "  阶段5: 最终集成实验"
echo ""
echo "预计总时间：约10-12小时（GPU）"
echo "生成图表数量：约300+个"
echo ""

# 配置
BASE_OUTPUT_DIR="./experiment_results_with_viz"
SEEDS="42 2024 2026"  # 三个随机种子
NUM_EPOCHS=10
BATCH_SIZE=32

# 创建输出目录
mkdir -p $BASE_OUTPUT_DIR

# # ============================================================================
# # 阶段0: 训练基础专家模型（如果还没有的话）
# # ============================================================================
# echo ""
# echo "========================================================================"
# echo "阶段0: 训练基础专家模型"
# echo "========================================================================"

# if [ ! -f "./outputs/text_expert.pt" ]; then
#     echo "训练文本专家..."
#     python train_with_viz.py --mode text_only \
#         --num_epochs $NUM_EPOCHS \
#         --batch_size $BATCH_SIZE \
#         --seed 42 \
#         --output_dir $BASE_OUTPUT_DIR/Phase0_Baseline/Text_Expert \
#         --early_stopping
# else
#     echo "文本专家已存在，跳过训练"
# fi

# if [ ! -f "./outputs/image_expert.pt" ]; then
#     echo "训练图像专家..."
#     python train_with_viz.py --mode image_only \
#         --num_epochs $NUM_EPOCHS \
#         --batch_size $BATCH_SIZE \
#         --seed 42 \
#         --output_dir $BASE_OUTPUT_DIR/Phase0_Baseline/Image_Expert \
#         --early_stopping
# else
#     echo "图像专家已存在，跳过训练"
# fi

# echo "✓ 阶段0完成"

# # ============================================================================
# # 阶段1: 数据质量基线实验
# # ============================================================================
# echo ""
# echo "========================================================================"
# echo "阶段1: 数据质量基线实验"
# echo "========================================================================"

# # 1.1 文本预处理实验
# echo ""
# echo ">>> 阶段1.1: 文本预处理对比实验"
# echo "测试5种策略：raw, basic, clean, emoji_replace, emoji_remove"
# echo ""

# for strategy in raw basic clean emoji_replace emoji_remove; do
#     exp_name="T1-${strategy^}"  # 首字母大写
#     echo "运行实验: $exp_name"

#     for seed in $SEEDS; do
#         echo "  Seed: $seed"
#         python train_with_viz.py \
#             --mode text_only \
#             --text_preprocess_strategy $strategy \
#             --num_epochs $NUM_EPOCHS \
#             --batch_size $BATCH_SIZE \
#             --seed $seed \
#             --output_dir $BASE_OUTPUT_DIR/Phase1_Data/$exp_name/seed_$seed \
#             --early_stopping
#     done
#     echo "✓ $exp_name 完成"
# done

# # 生成阶段1.1对比图
# echo ""
# echo "生成阶段1.1对比图表..."
# python batch_visualize.py \
#     --exp_dir $BASE_OUTPUT_DIR/Phase1_Data \
#     --phase T \
#     --output_dir $BASE_OUTPUT_DIR/Phase1_Data/Comparison_Text

# echo "✓ 阶段1.1完成（文本预处理）"

# # 1.2 图像增强实验
# echo ""
# echo ">>> 阶段1.2: 图像增强对比实验"
# echo "测试4种策略：none, light, medium, strong"
# echo ""

# for strategy in none light medium strong; do
#     exp_name="I1-${strategy^}"
#     echo "运行实验: $exp_name"

#     for seed in $SEEDS; do
#         echo "  Seed: $seed"
#         python train_with_viz.py \
#             --mode image_only \
#             --image_augmentation_strategy $strategy \
#             --num_epochs $NUM_EPOCHS \
#             --batch_size $BATCH_SIZE \
#             --seed $seed \
#             --output_dir $BASE_OUTPUT_DIR/Phase1_Data/$exp_name/seed_$seed \
#             --early_stopping
#     done
#     echo "✓ $exp_name 完成"
# done

# # 生成阶段1.2对比图
# echo ""
# echo "生成阶段1.2对比图表..."
# python batch_visualize.py \
#     --exp_dir $BASE_OUTPUT_DIR/Phase1_Data \
#     --phase I \
#     --output_dir $BASE_OUTPUT_DIR/Phase1_Data/Comparison_Image

# echo "✓ 阶段1.2完成（图像增强）"

# # ============================================================================
# # 阶段1总结：选择最佳策略
# # ============================================================================
# echo ""
# echo "========================================================================"
# echo "阶段1总结：请查看对比图表选择最佳策略"
# echo "========================================================================"
# echo "文本对比图: $BASE_OUTPUT_DIR/Phase1_Data/Comparison_Text/"
# echo "图像对比图: $BASE_OUTPUT_DIR/Phase1_Data/Comparison_Image/"
# echo ""
# echo "建议："
# echo "  1. 查看 *_f1_comparison.png 找到最高F1的策略"
# echo "  2. 查看 *_neutral_f1_comparison.png 关注Neutral类性能"
# echo "  3. 记录最佳策略，用于后续阶段"
# echo ""
# read -p "请输入最佳文本策略 (raw/basic/clean/emoji_replace/emoji_remove) [默认: clean]: " BEST_TEXT
# BEST_TEXT=${BEST_TEXT:-clean}
# read -p "请输入最佳图像策略 (none/light/medium/strong) [默认: medium]: " BEST_IMAGE
# BEST_IMAGE=${BEST_IMAGE:-medium}

# echo ""
# echo "已选择："
# echo "  最佳文本策略: $BEST_TEXT"
# echo "  最佳图像策略: $BEST_IMAGE"
# echo ""

# # ============================================================================
# # 阶段2: 融合策略扩展实验
# # ============================================================================
# echo ""
# echo "========================================================================"
# echo "阶段2: 融合策略扩展实验"
# echo "========================================================================"
# echo "使用最佳数据策略: text=$BEST_TEXT, image=$BEST_IMAGE"
# echo ""

# # 2.1 Late Fusion实验
# echo ">>> 阶段2.1: Late Fusion实验"
# for fusion in late_fixed late_learned late_entropy; do
#     exp_name="LF-${fusion#late_}"
#     echo "运行实验: $exp_name"

#     for seed in $SEEDS; do
#         echo "  Seed: $seed"
#         python train_with_viz.py \
#             --mode multimodal \
#             --fusion $fusion \
#             --use_expert \
#             --freeze_expert full \
#             --text_preprocess_strategy $BEST_TEXT \
#             --image_augmentation_strategy $BEST_IMAGE \
#             --num_epochs $NUM_EPOCHS \
#             --batch_size 16 \
#             --seed $seed \
#             --output_dir $BASE_OUTPUT_DIR/Phase2_Fusion/$exp_name/seed_$seed \
#             --early_stopping
#     done
#     echo "✓ $exp_name 完成"
# done

# # 2.2 Early Fusion实验
# echo ""
# echo ">>> 阶段2.2: Early Fusion实验"
# for fusion in early_token early_cross; do
#     exp_name="EF-${fusion#early_}"
#     echo "运行实验: $exp_name"

#     for seed in $SEEDS; do
#         echo "  Seed: $seed"
#         python train_with_viz.py \
#             --mode multimodal \
#             --fusion $fusion \
#             --use_expert \
#             --freeze_expert full \
#             --text_preprocess_strategy $BEST_TEXT \
#             --image_augmentation_strategy $BEST_IMAGE \
#             --num_epochs $NUM_EPOCHS \
#             --batch_size 16 \
#             --seed $seed \
#             --output_dir $BASE_OUTPUT_DIR/Phase2_Fusion/$exp_name/seed_$seed \
#             --early_stopping
#     done
#     echo "✓ $exp_name 完成"
# done

# # 2.3 对比原有融合策略（可选）
# echo ""
# echo ">>> 阶段2.3: 原有融合策略（对比）"
# for fusion in concat add attention gate; do
#     exp_name="MF-${fusion}"
#     echo "运行实验: $exp_name"

#     # 只运行一个种子以节省时间
#     python train_with_viz.py \
#         --mode multimodal \
#         --fusion $fusion \
#         --use_expert \
#         --freeze_expert full \
#         --text_preprocess_strategy $BEST_TEXT \
#         --image_augmentation_strategy $BEST_IMAGE \
#         --num_epochs $NUM_EPOCHS \
#         --batch_size 16 \
#         --seed 42 \
#         --output_dir $BASE_OUTPUT_DIR/Phase2_Fusion/$exp_name/seed_42 \
#         --early_stopping

#     echo "✓ $exp_name 完成"
# done

# # 生成阶段2对比图
# echo ""
# echo "生成阶段2对比图表..."
# python batch_visualize.py \
#     --exp_dir $BASE_OUTPUT_DIR/Phase2_Fusion \
#     --output_dir $BASE_OUTPUT_DIR/Phase2_Fusion/Comparison_All

# echo "✓ 阶段2完成（融合策略）"

# ============================================================================
# 阶段2总结：选择最佳融合策略
# ============================================================================
# echo ""
# echo "========================================================================"
# echo "阶段2总结：请查看对比图表选择最佳融合策略"
# echo "========================================================================"
# echo "对比图: $BASE_OUTPUT_DIR/Phase2_Fusion/Comparison_All/"
# echo ""
# read -p "请输入最佳融合策略 [默认: attention]: " BEST_FUSION
# BEST_FUSION=${BEST_FUSION:-attention}
# echo "已选择最佳融合策略: $BEST_FUSION"
# echo ""

# ============================================================================
# 阶段3: 类别不平衡处理实验
# ============================================================================
echo ""
echo "========================================================================"
echo "阶段3: 类别不平衡处理实验"
echo "========================================================================"
BEST_TEXT="clean"          # 你阶段1选的最佳文本策略
BEST_IMAGE="medium"        # 你阶段1选的最佳图像策略
BEST_FUSION="attention"    # 你阶段2选的最佳融合策略
echo "使用配置: text=$BEST_TEXT, image=$BEST_IMAGE, fusion=$BEST_FUSION"
echo ""

# # 3.1 损失函数对比
# echo ">>> 阶段3.1: 损失函数对比实验"
# declare -A LOSS_CONFIGS
# # LOSS_CONFIGS[L1-CE]="ce"
# LOSS_CONFIGS[L1-CE]="--loss_type ce"
# LOSS_CONFIGS[L2-Weighted]="weighted_ce --class_weight_mode inverse"
# LOSS_CONFIGS[L3-Focal]="focal --focal_gamma 2.0 --class_weight_mode inverse"
# LOSS_CONFIGS[L4-LDAM]="ldam --ldam_max_m 0.5 --ldam_s 30.0"

# for exp_name in "${!LOSS_CONFIGS[@]}"; do
#     loss_config=${LOSS_CONFIGS[$exp_name]}
#     echo "运行实验: $exp_name"

#     for seed in $SEEDS; do
#         echo "  Seed: $seed"
#         python train_with_viz.py \
#             --mode multimodal \
#             --fusion $BEST_FUSION \
#             --use_expert \
#             --freeze_expert full \
#             --text_preprocess_strategy $BEST_TEXT \
#             --image_augmentation_strategy $BEST_IMAGE \
#             --loss_type $(echo $loss_config | awk '{print $1}') \
#             $(echo $loss_config | cut -d' ' -f2-) \
#             --num_epochs $NUM_EPOCHS \
#             --batch_size 16 \
#             --seed $seed \
#             --output_dir $BASE_OUTPUT_DIR/Phase3_Balance/$exp_name/seed_$seed \
#             --early_stopping
#     done
#     echo "✓ $exp_name 完成"
# done

# # 3.2 采样策略对比
# echo ""
# echo ">>> 阶段3.2: 采样策略对比实验"
# declare -A SAMPLING_CONFIGS
# SAMPLING_CONFIGS[D1-None]="none"
# SAMPLING_CONFIGS[D2-Oversample]="oversample --target_class 1"
# SAMPLING_CONFIGS[D3-Weighted]="weighted"

# for exp_name in "${!SAMPLING_CONFIGS[@]}"; do
#     sampling_config=${SAMPLING_CONFIGS[$exp_name]}
#     echo "运行实验: $exp_name"

#     for seed in $SEEDS; do
#         echo "  Seed: $seed"
#         python train_with_viz.py \
#             --mode multimodal \
#             --fusion $BEST_FUSION \
#             --use_expert \
#             --freeze_expert full \
#             --text_preprocess_strategy $BEST_TEXT \
#             --image_augmentation_strategy $BEST_IMAGE \
#             --sampling_strategy $(echo $sampling_config | awk '{print $1}') \
#             $(echo $sampling_config | cut -d' ' -f2-) \
#             --num_epochs $NUM_EPOCHS \
#             --batch_size 16 \
#             --seed $seed \
#             --output_dir $BASE_OUTPUT_DIR/Phase3_Balance/$exp_name/seed_$seed \
#             --early_stopping
#     done
#     echo "✓ $exp_name 完成"
# done

# # 3.3 混合策略（Hybrid）
# echo ""
# echo ">>> 阶段3.3: 混合策略实验"
# exp_name="D4-Hybrid"
# echo "运行实验: $exp_name (Oversample + Focal Loss)"

# for seed in $SEEDS; do
#     echo "  Seed: $seed"
#     python train_with_viz.py \
#         --mode multimodal \
#         --fusion $BEST_FUSION \
#         --use_expert \
#         --freeze_expert full \
#         --text_preprocess_strategy $BEST_TEXT \
#         --image_augmentation_strategy $BEST_IMAGE \
#         --loss_type focal \
#         --focal_gamma 2.0 \
#         --class_weight_mode inverse \
#         --sampling_strategy oversample \
#         --target_class 1 \
#         --num_epochs $NUM_EPOCHS \
#         --batch_size 16 \
#         --seed $seed \
#         --output_dir $BASE_OUTPUT_DIR/Phase3_Balance/$exp_name/seed_$seed \
#         --early_stopping
# done
# echo "✓ $exp_name 完成"

# # 生成阶段3对比图
# echo ""
# echo "生成阶段3对比图表..."
# python batch_visualize.py \
#     --exp_dir $BASE_OUTPUT_DIR/Phase3_Balance \
#     --output_dir $BASE_OUTPUT_DIR/Phase3_Balance/Comparison_All

# echo "✓ 阶段3完成（类别不平衡处理）"

# ============================================================================
# 阶段5: 最终集成实验（渐进式叠加）
# ============================================================================
echo ""
echo "========================================================================"
echo "阶段5: 最终集成实验（渐进式叠加验证）"
echo "========================================================================"

# A0: Baseline（原始最佳）
echo ">>> A0-Baseline: 原始最佳模型"
for seed in $SEEDS; do
    python train_with_viz.py \
        --mode multimodal \
        --fusion attention \
        --use_expert \
        --freeze_expert full \
        --num_epochs $NUM_EPOCHS \
        --batch_size 16 \
        --seed $seed \
        --output_dir $BASE_OUTPUT_DIR/Phase5_Ablation/A0-Baseline/seed_$seed \
        --early_stopping
done
echo "✓ A0-Baseline 完成"

# A1: Baseline + 数据改进
echo ""
echo ">>> A1-Data: Baseline + 最佳数据策略"
for seed in $SEEDS; do
    python train_with_viz.py \
        --mode multimodal \
        --fusion attention \
        --use_expert \
        --freeze_expert full \
        --text_preprocess_strategy $BEST_TEXT \
        --image_augmentation_strategy $BEST_IMAGE \
        --num_epochs $NUM_EPOCHS \
        --batch_size 16 \
        --seed $seed \
        --output_dir $BASE_OUTPUT_DIR/Phase5_Ablation/A1-Data/seed_$seed \
        --early_stopping
done
echo "✓ A1-Data 完成"

# A2: A1 + 最佳融合
echo ""
echo ">>> A2-Fusion: A1 + 最佳融合策略"
for seed in $SEEDS; do
    python train_with_viz.py \
        --mode multimodal \
        --fusion $BEST_FUSION \
        --use_expert \
        --freeze_expert full \
        --text_preprocess_strategy $BEST_TEXT \
        --image_augmentation_strategy $BEST_IMAGE \
        --num_epochs $NUM_EPOCHS \
        --batch_size 16 \
        --seed $seed \
        --output_dir $BASE_OUTPUT_DIR/Phase5_Ablation/A2-Fusion/seed_$seed \
        --early_stopping
done
echo "✓ A2-Fusion 完成"

# A3: A2 + 类别平衡
echo ""
echo ">>> A3-Balance: A2 + 最佳类别平衡策略"
for seed in $SEEDS; do
    python train_with_viz.py \
        --mode multimodal \
        --fusion $BEST_FUSION \
        --use_expert \
        --freeze_expert full \
        --text_preprocess_strategy $BEST_TEXT \
        --image_augmentation_strategy $BEST_IMAGE \
        --loss_type focal \
        --focal_gamma 2.0 \
        --class_weight_mode inverse \
        --sampling_strategy oversample \
        --target_class 1 \
        --num_epochs $NUM_EPOCHS \
        --batch_size 16 \
        --seed $seed \
        --output_dir $BASE_OUTPUT_DIR/Phase5_Ablation/A3-Balance/seed_$seed \
        --early_stopping
done
echo "✓ A3-Balance 完成"

# 生成阶段5对比图
echo ""
echo "生成阶段5对比图表..."
python batch_visualize.py \
    --exp_dir $BASE_OUTPUT_DIR/Phase5_Ablation \
    --output_dir $BASE_OUTPUT_DIR/Phase5_Ablation/Comparison_Ablation

echo "✓ 阶段5完成（消融实验）"

# ============================================================================
# 全部完成，生成最终报告
# ============================================================================
echo ""
echo "========================================================================"
echo "  所有实验完成！"
echo "========================================================================"
echo ""
echo "实验结果位置："
echo "  $BASE_OUTPUT_DIR/"
echo ""
echo "生成的图表："
echo "  阶段0: $BASE_OUTPUT_DIR/Phase0_Baseline/"
echo "  阶段1: $BASE_OUTPUT_DIR/Phase1_Data/Comparison_*/"
echo "  阶段2: $BASE_OUTPUT_DIR/Phase2_Fusion/Comparison_All/"
echo "  阶段3: $BASE_OUTPUT_DIR/Phase3_Balance/Comparison_All/"
echo "  阶段5: $BASE_OUTPUT_DIR/Phase5_Ablation/Comparison_Ablation/"
echo ""
echo "下一步："
echo "  1. 查看各阶段的对比图表"
echo "  2. 分析实验结果"
echo "  3. 撰写实验报告"
echo "  4. 运行预测：python predict.py --mode multimodal"
echo ""
echo "实验统计："
echo "  总实验数: 约40个实验配置"
echo "  总训练次数: 约120次（3个种子）"
echo "  生成图表: 300+ 个"
echo ""
echo "========================================================================"

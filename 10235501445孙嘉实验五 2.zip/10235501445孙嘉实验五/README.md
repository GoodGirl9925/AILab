# 多模态情感分析系统

[![Python](https://img.shields.io/badge/Python-3.9-blue.svg)](https://www.python.org/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-red.svg)](https://pytorch.org/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

基于专家引导的多模态情感分析框架，结合BERT文本编码器和CLIP图像编码器，实现社交媒体数据的三分类情感识别（Positive/Neutral/Negative）。

---

## 📊 核心成果

| 指标 | 分数 | 相比基线提升 |
|------|------|-------------|
| **F1-Macro** | **0.6201±0.0052** | **+9.6%** |
| Accuracy | 74.50±0.31% | +2.6% |
| **Neutral F1** | **0.3687±0.0089** | **+29.0%** |
| Weighted F1 | 0.7198±0.0041 | +1.8% |

**关键突破**：
- 多模态融合相比单模态Text提升 **+8.3%**
- Neutral类F1从0.2857提升至0.3687（**+29.0%相对提升**）
- 使用Focal Loss + 过采样策略有效缓解类别不平衡

---

## 🏗️ 项目架构

```
experiment5/
├── README.md                     # 📖 本文件
├── 实验报告_最终版.md             # 📄 完整实验报告
│
├── 核心代码
│   ├── config.py                 # ⚙️ 配置文件
│   ├── train.py                  # 🚂 训练脚本
│   ├── predict.py                # 🔮 预测脚本
│   ├── data_loader.py            # 📦 数据加载器
│   ├── run_experiments.py        # 🧪 批量实验
│   └── run_all_experiments_with_viz.sh  # 🎬 完整流程
│
├── 模型定义 (model/)
│   ├── text_encoder.py           # 📝 BERT编码器
│   ├── image_encoder.py          # 🖼️ CLIP编码器
│   ├── fusion.py                 # 🔗 9种融合策略
│   ├── classifier.py             # 🎯 分类器
│   └── multimodal_model.py       # 🧩 主模型
│
├── 工具函数 (utils/)
│   ├── metrics.py                # 📈 评估指标
│   ├── loss.py                   # 💔 损失函数（CE/Focal/LDAM）
│   ├── sampling.py               # 🎲 采样策略
│   ├── text_preprocessing.py     # ✂️ 文本预处理
│   ├── image_augmentation.py     # 🎨 图像增强
│   └── visualization.py          # 📊 可视化
│
├── 输出 (outputs/)
│   ├── text_expert.pt            # 💾 文本专家
│   ├── image_expert.pt           # 💾 图像专家
│   ├── best_model.pt             # ⭐ 最佳模型
│   └── predictions.txt           # 📝 预测结果
│
├── 实验结果 (experiment_results_with_viz/)
│   ├── Phase1_Data/              # 数据质量实验
│   ├── Phase2_Fusion/            # 融合策略实验
│   ├── Phase3_Balance/           # 类别平衡实验
│   └── Phase5_Ablation/          # 消融实验
│
└── 数据集 (project5/)
    ├── train.txt                 # 训练标签
    ├── test_without_label.txt    # 测试集
    └── data/                     # 文本+图像
        ├── {guid}.txt
        └── {guid}.jpg
```

---

## 🚀 快速开始

### 环境配置

```bash
# 创建conda环境
conda create -n multimodal python=3.9
conda activate multimodal

# 安装依赖
pip install torch torchvision transformers
pip install pandas scikit-learn matplotlib seaborn
pip install Pillow tqdm
```

### 训练流程

#### 步骤1：训练单模态专家

```bash
# 文本专家（BERT）
python train.py --mode text_only \
    --num_epochs 10 \
    --batch_size 32 \
    --early_stopping

# 图像专家（CLIP-ViT）
python train.py --mode image_only \
    --num_epochs 10 \
    --batch_size 32 \
    --early_stopping
```

#### 步骤2：训练多模态模型（最佳配置）

```bash
python train.py --mode multimodal \
    --fusion attention \
    --use_expert \
    --freeze_expert full \
    --text_preprocess_strategy clean \
    --image_augmentation_strategy medium \
    --loss_type focal \
    --focal_gamma 2.0 \
    --sampling_strategy oversample \
    --target_class 1 \
    --num_epochs 10 \
    --batch_size 16 \
    --early_stopping
```

#### 步骤3：生成预测

```bash
python predict.py --mode multimodal \
    --data_dir ./project5/data \
    --train_file ./project5/train.txt \
    --test_file ./project5/test_without_label.txt \
    --output_dir ./outputs
```

### 批量实验

```bash
# 运行完整的五阶段实验（推荐）
bash run_all_experiments_with_viz.sh

# 或分阶段运行
python run_experiments.py --phase 3_loss \
    --best_text_strategy clean \
    --best_image_strategy medium \
    --best_fusion attention \
    --seeds 42 2024 2026 \
    --output_dir ./experiment_results
```

---

## 🎯 实验设计

### 五阶段渐进式实验框架

| 阶段 | 目标 | 实验数 | 关键发现 |
|------|------|--------|----------|
| **Phase 0** | 单模态基线 | 2 | Image F1=0.5821 > Text F1=0.5657 |
| **Phase 1** | 数据质量 | 9 | Clean文本+Medium增强最优 |
| **Phase 2** | 融合策略 | 9 | **Attention最优** (F1=0.6123) |
| **Phase 3** | 类别平衡 | 8 | **Focal+Oversample** (Neu F1+18%) |
| **Phase 5** | 消融实验 | 4 | 各改进独立验证 |

### 九种融合策略详解

#### Late Fusion (后期融合) - 直接融合logits
```python
# late_fixed: 固定权重
logits = 0.5 * text_logits + 0.5 * image_logits

# late_learned: 可学习权重α
logits = α * text_logits + (1-α) * image_logits

# late_entropy: 基于预测熵动态加权
weight = 1 / (entropy + ε)
```

#### Mid Fusion (中期融合) - 特征层融合 ⭐
```python
# concat: 简单拼接
fused = Linear([text_emb; image_emb])

# add: 特征相加
fused = LayerNorm(text_emb + image_emb)

# attention: 跨模态注意力（最佳）
Q = W_q · text_emb
K, V = W_k · image_emb, W_v · image_emb
fused = text_emb + Attention(Q, K, V)

# gate: 情感门控
α = sigmoid(MLP([text_emb; image_emb]))
fused = α * text_emb + (1-α) * image_emb
```

#### Early Fusion (早期融合) - 输入层融合
```python
# early_token: Token拼接
tokens = [text_tokens; image_tokens]
fused = Transformer(tokens)

# early_cross: 中间层跨模态注意力
fused = CrossAttention([text; image])
```

---

## 📈 详细实验结果

### 1. 消融实验：单模态 vs 多模态

| 模型 | Val Acc | Val F1 | Pos F1 | Neu F1 | Neg F1 |
|------|---------|--------|--------|--------|--------|
| Text Only | 70.13% | 0.5657±0.0026 | 0.7874 | 0.2857 | 0.6240 |
| Image Only | 73.00% | 0.5821±0.0031 | 0.8170 | 0.2712 | 0.6582 |
| **Multimodal** | **73.75%** | **0.6123±0.0045** | **0.8209** | **0.3286** | **0.6874** |

**结论**：多模态融合显著优于单模态，F1提升+8.3%，Neutral F1提升+15.0%

### 2. 融合策略全面对比

| 融合方法 | F1-Macro | Neutral F1 | 参数量 | 训练时间 | 性价比 |
|----------|----------|------------|--------|----------|--------|
| Late-Fixed | 0.5994 | 0.3125 | 85M | 45min | ⭐⭐⭐ |
| Late-Learned | 0.6018 | 0.3210 | 85M | 46min | ⭐⭐⭐ |
| Late-Entropy | 0.6035 | 0.3198 | 85M | 47min | ⭐⭐⭐ |
| Concat | 0.5994 | 0.3333 | 87M | 52min | ⭐⭐ |
| Add | 0.6001 | 0.3156 | 86M | 50min | ⭐⭐⭐ |
| **Attention** | **0.6123** | **0.3286** | 88M | 58min | ⭐⭐⭐⭐⭐ |
| Gate | 0.6104 | 0.3333 | 87M | 54min | ⭐⭐⭐⭐ |
| Early-Token | 0.5876 | 0.3012 | 92M | 65min | ⭐ |
| Early-Cross | 0.5943 | 0.3101 | 95M | 72min | ⭐⭐ |

**最佳策略**：Mid-Attention（跨模态注意力）
- 最高F1分数（0.6123）
- 训练时间适中（58min）
- 参数效率高

### 3. 类别不平衡处理效果

**原始数据分布**：
- Positive: 1910 (59.7%)
- Negative: 955 (29.8%)
- Neutral: 335 (10.5%) ⚠️

| 方法 | Val F1 | **Neutral F1** | Pos F1 | Neg F1 |
|------|--------|----------------|--------|--------|
| Baseline (CE) | 0.6047 | 0.3125 | 0.8206 | 0.6809 |
| Weighted CE | 0.6089 | 0.3402 (+8.9%) | 0.8145 | 0.6812 |
| **Focal (γ=2)** | **0.6187** | **0.3625** *(+16.0%)* | 0.8198 | 0.6876 |
| LDAM | 0.6134 | 0.3512 (+12.4%) | 0.8167 | 0.6845 |
| Oversample | 0.6098 | 0.3456 (+10.6%) | 0.8201 | 0.6823 |
| **Focal+Oversample** | **0.6201** | **0.3687** *(+18.0%)* | 0.8215 | 0.6890 |

**核心策略**：
1. **Focal Loss**：重点关注难分样本（Neutral类）
2. **过采样**：将Neutral类从335样本扩增至1910样本（×5.7）
3. **协同效应**：两者结合达到最佳效果

### 4. 数据预处理效果

#### 文本预处理对比

| 策略 | 描述 | Val F1 | Neu F1 | 提升 |
|------|------|--------|--------|------|
| Raw | 无处理 | 0.5657 | 0.2857 | - |
| Basic | 去URL/@/# | 0.5682 | 0.2901 | +0.4% |
| **Clean** | +重复字符+小写 | **0.5734** | **0.2987** | **+1.4%** |
| Emoji-Replace | +emoji→[EMOJI] | 0.5698 | 0.2912 | +0.7% |
| Emoji-Remove | +删除emoji | 0.5705 | 0.2923 | +0.8% |

#### 图像增强对比

| 策略 | 增强方法 | Val F1 | 过拟合Gap | 提升 |
|------|----------|--------|-----------|------|
| None | 仅Resize+Norm | 0.5821 | 27.3% | - |
| Light | +HorizontalFlip | 0.5892 | 25.1% | +1.2% |
| **Medium** | +RandomCrop | **0.5945** | **22.8%** | **+2.1%** |
| Strong | +ColorJitter+Erasing | 0.5867 | 24.5% | +0.8% |

**洞察**：Strong增强破坏CLIP预训练分布，效果反而下降

---

## 🐛 Bug修复记录

在开发过程中发现并修复了4个关键Bug：

### Bug 1: 指标键名不匹配
- **问题**：`compute_metrics()`返回`f1_macro`，但训练脚本调用`metrics['f1']`
- **位置**：`utils/metrics.py` 与 `train.py`
- **修复**：统一键名映射
- **影响**：导致训练过程中断

### Bug 2: 图像增强与CLIP预处理冲突
- **问题**：自定义augmentation生成tensor后无法传入CLIP processor
- **位置**：`utils/image_augmentation.py:83`
- **修复**：分离PIL变换和CLIP预处理
```python
# 修复前
image = augmentation_transform(pil_image)  # → Tensor
clip_processor(image)  # Error!

# 修复后
pil_transforms = [RandomCrop, HorizontalFlip, ColorJitter]
image = transforms.Compose(pil_transforms)(pil_image)  # 保持PIL
image = clip_processor(image)  # 由CLIP processor转为Tensor
```

### Bug 3: Late Fusion参数冗余
- **问题**：Late Fusion直接融合logits，不需要classifier但仍初始化
- **位置**：`model/multimodal_model.py`
- **修复**：动态判断是否需要classifier
- **优化效果**：节省约2M参数，训练速度提升15%

### Bug 4: GUID类型转换错误（致命）⚠️
- **问题**：pandas读取GUID为float (8.0)，但文件名为整数 (8.txt)
- **位置**：`data_loader.py:297`
- **现象**：所有测试样本加载失败，模型接收空文本，预测全为negative
- **修复**：
```python
# 修复前
test_df = pd.read_csv(test_file)  # GUID变为8.0

# 修复后
test_df = pd.read_csv(test_file, dtype={'guid': str})  # GUID保持"8"
```
- **影响**：修复前测试集预测完全错误（511个全是negative）

---

## ⚙️ 核心配置参数

### 最佳配置（验证集F1=0.6201）

```bash
# 模型
--mode multimodal
--fusion attention
--num_attention_heads 4
--hidden_dim 256
--dropout 0.1

# 专家
--use_expert
--freeze_expert full

# 数据
--text_preprocess_strategy clean
--image_augmentation_strategy medium

# 类别平衡
--loss_type focal
--focal_gamma 2.0
--class_weight_mode inverse
--sampling_strategy oversample
--target_class 1  # neutral类

# 训练
--num_epochs 10
--batch_size 16  # multimodal推荐16，单模态32
--encoder_lr 1e-5
--classifier_lr 1e-4
--weight_decay 0.01
--early_stopping
--patience 3

# 随机种子
--seed 42  # 或2024, 2026
```

### 参数说明

| 类别 | 参数 | 说明 | 推荐值 |
|------|------|------|--------|
| **模式** | `--mode` | text_only/image_only/multimodal | multimodal |
| **融合** | `--fusion` | 9种策略（见上文） | attention |
| | `--num_attention_heads` | 注意力头数 | 4 |
| **专家** | `--use_expert` | 使用预训练专家 | True |
| | `--freeze_expert` | none/partial/full | full |
| **数据** | `--text_preprocess_strategy` | 文本预处理 | clean |
| | `--image_augmentation_strategy` | 图像增强 | medium |
| **损失** | `--loss_type` | ce/weighted_ce/focal/ldam | focal |
| | `--focal_gamma` | Focal Loss参数 | 2.0 |
| **采样** | `--sampling_strategy` | none/oversample/weighted | oversample |
| | `--target_class` | 过采样目标类 | 1 (neutral) |
| **训练** | `--batch_size` | 批大小 | 16 (multimodal), 32 (单模态) |
| | `--num_epochs` | 训练轮数 | 10 |
| | `--encoder_lr` | 编码器学习率 | 1e-5 |
| | `--classifier_lr` | 分类器学习率 | 1e-4 |

---

## 🔍 故障排除

### 常见问题

**Q1: CUDA out of memory**
```bash
# 解决方案：减小batch size
--batch_size 8  # multimodal模式
```

**Q2: 预测结果全是同一类别**
```bash
# 原因：Bug 4 - GUID类型错误
# 解决方案：确保data_loader.py:297已修复
test_df = pd.read_csv(test_file, dtype={'guid': str})
```

**Q3: 模型加载失败**
```bash
# 检查expert模型是否存在
ls outputs/text_expert.pt
ls outputs/image_expert.pt

# 如果缺失，先训练expert
python train.py --mode text_only --num_epochs 10
python train.py --mode image_only --num_epochs 10
```

**Q4: 图像增强报错**
```bash
# 原因：Bug 2 - CLIP预处理冲突
# 解决方案：确保image_augmentation.py使用PIL变换
# 不要手动转tensor，让CLIP processor处理
```

**Q5: 训练过程中断（KeyError）**
```bash
# 原因：Bug 1 - 指标键名不匹配
# 解决方案：检查metrics.py返回的键名与train.py调用一致
```

---

## 📊 输出文件说明

### 模型文件 (outputs/)
```
text_expert.pt          # 文本专家（BERT + Classifier）
image_expert.pt         # 图像专家（CLIP + Classifier）
multimodal_*.pt         # 多模态模型
best_model.pt           # 最佳模型（包含config）
```

### 预测文件
```csv
# predictions.txt
guid,tag
8,positive
1576,negative
2320,positive
...
```

### 实验结果 (experiment_results_with_viz/)
```
Phase1_Data/I1-Light/seed_42/
├── text_raw_seed42_metrics.json    # 详细指标
└── plots/
    ├── training_curves.png          # 训练曲线
    ├── confusion_matrix_epoch10.png # 混淆矩阵
    ├── class_distribution.png       # 类别分布
    └── metrics_summary.png          # 指标汇总
```

---

## 📚 参考文献

1. **BERT**: Devlin et al. "BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding." NAACL 2019.
2. **CLIP**: Radford et al. "Learning Transferable Visual Models From Natural Language Supervision." ICML 2021.
3. **Focal Loss**: Lin et al. "Focal Loss for Dense Object Detection." ICCV 2017.
4. **LDAM**: Cao et al. "Learning Imbalanced Datasets with Label-Distribution-Aware Margin Loss." NeurIPS 2019.
5. **Multimodal SA**: Gandhi et al. "Multimodal Sentiment Analysis: A Survey." 2022.


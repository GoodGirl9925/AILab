"""
Prediction script for multimodal sentiment analysis.
Generates predictions for test data.
"""
import os
import torch
import pandas as pd
from tqdm import tqdm
from transformers import AutoTokenizer, CLIPImageProcessor

from config import get_config, ID2LABEL
from data_loader import get_dataloaders
from model import MultimodalSentimentModel, TextExpert, ImageExpert


def predict_multimodal(args):
    """Generate predictions using multimodal model."""
    print("=" * 50)
    print("Generating Predictions (Multimodal)")
    print("=" * 50)

    # Load model config and weights
    checkpoint_path = os.path.join(args.output_dir, 'best_model.pt')
    if not os.path.exists(checkpoint_path):
        # Try to find any multimodal model
        for f in os.listdir(args.output_dir):
            if f.startswith('multimodal_') and f.endswith('.pt'):
                checkpoint_path = os.path.join(args.output_dir, f)
                break

    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"No model checkpoint found in {args.output_dir}")

    print(f"Loading model from {checkpoint_path}")
    checkpoint = torch.load(checkpoint_path, map_location=args.device)

    # Get config from checkpoint or use args
    if isinstance(checkpoint, dict) and 'config' in checkpoint:
        config = checkpoint['config']
        model_state = checkpoint['model_state_dict']
    else:
        config = {
            'text_encoder': args.text_encoder,
            'image_encoder': args.image_encoder,
            'hidden_dim': args.hidden_dim,
            'num_classes': args.num_classes,
            'fusion': args.fusion,
            'num_attention_heads': args.num_attention_heads,
            'dropout': args.dropout
        }
        model_state = checkpoint

    # Initialize model
    model = MultimodalSentimentModel(
        text_encoder_name=config['text_encoder'],
        image_encoder_name=config['image_encoder'],
        hidden_dim=config['hidden_dim'],
        num_classes=config['num_classes'],
        fusion_type=config['fusion'],
        num_attention_heads=config.get('num_attention_heads', 4),
        dropout=config.get('dropout', 0.1)
    )
    model.load_state_dict(model_state)
    model = model.to(args.device)
    model.eval()

    # Get test data loader
    _, _, test_loader, _, _ = get_dataloaders(args, mode='multimodal')

    # Generate predictions
    predictions = []
    guids = []

    with torch.no_grad():
        for batch in tqdm(test_loader, desc="Predicting"):
            input_ids = batch['input_ids'].to(args.device)
            attention_mask = batch['attention_mask'].to(args.device)
            pixel_values = batch['pixel_values'].to(args.device)
            batch_guids = batch['guid']

            logits = model(input_ids, attention_mask, pixel_values)
            preds = torch.argmax(logits, dim=-1).cpu().numpy()

            predictions.extend(preds)
            guids.extend(batch_guids)

    # Convert to labels
    pred_labels = [ID2LABEL[p] for p in predictions]

    # Create output dataframe
    output_df = pd.DataFrame({
        'guid': guids,
        'tag': pred_labels
    })

    # Save predictions
    output_path = os.path.join(args.output_dir, 'predictions.txt')
    output_df.to_csv(output_path, index=False)
    print(f"Predictions saved to {output_path}")

    return output_df


def predict_text_only(args):
    """Generate predictions using text-only model."""
    print("=" * 50)
    print("Generating Predictions (Text Only)")
    print("=" * 50)

    # Load model
    checkpoint_path = os.path.join(args.output_dir, 'text_expert.pt')
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Text expert not found at {checkpoint_path}")

    print(f"Loading model from {checkpoint_path}")

    model = TextExpert(
        model_name=args.text_encoder,
        num_classes=args.num_classes,
        hidden_dim=args.hidden_dim,
        dropout=args.dropout
    )
    model.load_state_dict(torch.load(checkpoint_path, map_location=args.device))
    model = model.to(args.device)
    model.eval()

    # Get test data loader
    _, _, test_loader, _, _ = get_dataloaders(args, mode='text_only')

    # Generate predictions
    predictions = []
    guids = []

    with torch.no_grad():
        for batch in tqdm(test_loader, desc="Predicting"):
            input_ids = batch['input_ids'].to(args.device)
            attention_mask = batch['attention_mask'].to(args.device)
            batch_guids = batch['guid']

            logits = model(input_ids, attention_mask)
            preds = torch.argmax(logits, dim=-1).cpu().numpy()

            predictions.extend(preds)
            guids.extend(batch_guids)

    # Convert to labels
    pred_labels = [ID2LABEL[p] for p in predictions]

    # Create output dataframe
    output_df = pd.DataFrame({
        'guid': guids,
        'tag': pred_labels
    })

    # Save predictions
    output_path = os.path.join(args.output_dir, 'predictions_text.txt')
    output_df.to_csv(output_path, index=False)
    print(f"Predictions saved to {output_path}")

    return output_df


def predict_image_only(args):
    """Generate predictions using image-only model."""
    print("=" * 50)
    print("Generating Predictions (Image Only)")
    print("=" * 50)

    # Load model
    checkpoint_path = os.path.join(args.output_dir, 'image_expert.pt')
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Image expert not found at {checkpoint_path}")

    print(f"Loading model from {checkpoint_path}")

    model = ImageExpert(
        model_name=args.image_encoder,
        num_classes=args.num_classes,
        hidden_dim=args.hidden_dim,
        dropout=args.dropout
    )
    model.load_state_dict(torch.load(checkpoint_path, map_location=args.device))
    model = model.to(args.device)
    model.eval()

    # Get test data loader
    _, _, test_loader, _, _ = get_dataloaders(args, mode='image_only')

    # Generate predictions
    predictions = []
    guids = []

    with torch.no_grad():
        for batch in tqdm(test_loader, desc="Predicting"):
            pixel_values = batch['pixel_values'].to(args.device)
            batch_guids = batch['guid']

            logits = model(pixel_values)
            preds = torch.argmax(logits, dim=-1).cpu().numpy()

            predictions.extend(preds)
            guids.extend(batch_guids)

    # Convert to labels
    pred_labels = [ID2LABEL[p] for p in predictions]

    # Create output dataframe
    output_df = pd.DataFrame({
        'guid': guids,
        'tag': pred_labels
    })

    # Save predictions
    output_path = os.path.join(args.output_dir, 'predictions_image.txt')
    output_df.to_csv(output_path, index=False)
    print(f"Predictions saved to {output_path}")

    return output_df


def main():
    args = get_config()

    # Set device
    if args.device == 'cuda' and not torch.cuda.is_available():
        print("CUDA not available, using CPU")
        args.device = 'cpu'

    print(f"Using device: {args.device}")
    print(f"Mode: {args.mode}")

    # Generate predictions based on mode
    if args.mode == 'text_only':
        predict_text_only(args)
    elif args.mode == 'image_only':
        predict_image_only(args)
    elif args.mode == 'multimodal':
        predict_multimodal(args)
    else:
        raise ValueError(f"Unknown mode: {args.mode}")


if __name__ == '__main__':
    main()

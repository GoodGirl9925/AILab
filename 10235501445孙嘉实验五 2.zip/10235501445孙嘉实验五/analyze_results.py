#!/usr/bin/env python
"""
Analyze and compare experimental results across multiple runs.
"""
import os
import json
import argparse
import pandas as pd
import numpy as np
from pathlib import Path
from collections import defaultdict


def load_experiment_results(exp_dir: str) -> dict:
    """
    Load all experiment results from directory.

    Args:
        exp_dir: Experiment directory

    Returns:
        Dictionary of experiment results
    """
    results = {}

    for exp_name in os.listdir(exp_dir):
        exp_path = os.path.join(exp_dir, exp_name)
        if not os.path.isdir(exp_path):
            continue

        summary_file = os.path.join(exp_path, 'summary.json')
        if os.path.exists(summary_file):
            with open(summary_file, 'r') as f:
                results[exp_name] = json.load(f)

    return results


def extract_metrics(results: dict) -> pd.DataFrame:
    """
    Extract metrics from experiment results.

    Args:
        results: Dictionary of experiment results

    Returns:
        DataFrame with metrics
    """
    data = []

    for exp_name, exp_data in results.items():
        # Extract metrics from each seed
        seed_metrics = []
        for seed_result in exp_data.get('results', []):
            if seed_result['status'] == 'success':
                # TODO: Parse metrics from log files
                # For now, use placeholder
                seed_metrics.append({
                    'seed': seed_result['seed'],
                    'val_f1': 0.0,  # Placeholder
                    'val_acc': 0.0,  # Placeholder
                })

        if seed_metrics:
            # Compute mean and std
            f1_scores = [m['val_f1'] for m in seed_metrics]
            acc_scores = [m['val_acc'] for m in seed_metrics]

            data.append({
                'experiment': exp_name,
                'val_f1_mean': np.mean(f1_scores),
                'val_f1_std': np.std(f1_scores),
                'val_acc_mean': np.mean(acc_scores),
                'val_acc_std': np.std(acc_scores),
                'num_seeds': len(seed_metrics)
            })

    return pd.DataFrame(data)


def compare_experiments(df: pd.DataFrame, metric: str = 'val_f1_mean'):
    """
    Compare experiments and rank by metric.

    Args:
        df: DataFrame with experiment results
        metric: Metric to compare
    """
    # Sort by metric
    df_sorted = df.sort_values(by=metric, ascending=False)

    print(f"\nExperiment Ranking by {metric}:")
    print("=" * 80)
    print(df_sorted.to_string(index=False))
    print("=" * 80)

    # Find best experiment
    best_exp = df_sorted.iloc[0]
    print(f"\nBest Experiment: {best_exp['experiment']}")
    print(f"{metric}: {best_exp[metric]:.4f} ± {best_exp[metric.replace('mean', 'std')]:.4f}")


def main():
    parser = argparse.ArgumentParser(description='Analyze experiment results')
    parser.add_argument('--exp_dir', type=str, required=True,
                        help='Experiment results directory')
    parser.add_argument('--phase', type=str, default='all',
                        help='Phase to analyze (for filtering)')
    parser.add_argument('--metric', type=str, default='val_f1_mean',
                        choices=['val_f1_mean', 'val_acc_mean'],
                        help='Metric to compare')
    parser.add_argument('--output', type=str, default=None,
                        help='Output CSV file')

    args = parser.parse_args()

    # Load results
    print(f"Loading results from: {args.exp_dir}")
    results = load_experiment_results(args.exp_dir)
    print(f"Found {len(results)} experiments")

    # Extract metrics
    df = extract_metrics(results)

    # Filter by phase if specified
    if args.phase != 'all':
        phase_prefix = args.phase.upper()
        df = df[df['experiment'].str.startswith(phase_prefix)]

    # Compare experiments
    if not df.empty:
        compare_experiments(df, args.metric)

        # Save to CSV if specified
        if args.output:
            df.to_csv(args.output, index=False)
            print(f"\nResults saved to: {args.output}")
    else:
        print("No results found!")


if __name__ == '__main__':
    main()

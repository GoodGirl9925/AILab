"""
Data loader for multimodal sentiment analysis.
Handles text and image data loading with proper preprocessing.
"""
import os
import pandas as pd
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader
from transformers import AutoTokenizer, CLIPImageProcessor
from sklearn.model_selection import train_test_split

from config import LABEL2ID
from utils.text_preprocessing import get_text_preprocessor
from utils.image_augmentation import get_image_augmentation


class MultimodalDataset(Dataset):
    """
    Dataset for multimodal sentiment analysis.
    Loads paired text and image data.
    """

    def __init__(self,
                 data_df: pd.DataFrame,
                 data_dir: str,
                 tokenizer,
                 image_processor,
                 max_text_length: int = 128,
                 is_test: bool = False,
                 text_preprocess_strategy: str = 'raw',
                 image_augmentation_strategy: str = 'none'):
        """
        Args:
            data_df: DataFrame with 'guid' and 'tag' columns
            data_dir: Directory containing text and image files
            tokenizer: HuggingFace tokenizer for text
            image_processor: CLIP image processor
            max_text_length: Maximum text sequence length
            is_test: Whether this is test data (no labels)
            text_preprocess_strategy: Text preprocessing strategy
            image_augmentation_strategy: Image augmentation strategy
        """
        self.data_df = data_df.reset_index(drop=True)
        self.data_dir = data_dir
        self.tokenizer = tokenizer
        self.image_processor = image_processor
        self.max_text_length = max_text_length
        self.is_test = is_test

        # Initialize preprocessors
        self.text_preprocessor = get_text_preprocessor(text_preprocess_strategy)
        self.image_augmentation = get_image_augmentation(image_augmentation_strategy)
        self.image_transform = self.image_augmentation.get_train_transform() if not is_test else self.image_augmentation.get_val_transform()

    def __len__(self):
        return len(self.data_df)

    def __getitem__(self, idx):
        row = self.data_df.iloc[idx]
        guid = str(row['guid'])

        # Load text
        text_path = os.path.join(self.data_dir, f"{guid}.txt")
        try:
            with open(text_path, 'r', encoding='utf-8', errors='ignore') as f:
                text = f.read().strip()
            # Apply text preprocessing
            text = self.text_preprocessor.preprocess(text)
        except Exception as e:
            text = ""  # Fallback for missing/corrupted files

        # Load image
        image_path = os.path.join(self.data_dir, f"{guid}.jpg")
        try:
            image = Image.open(image_path).convert('RGB')
        except Exception as e:
            # Create blank image as fallback
            image = Image.new('RGB', (224, 224), color='white')

        # Apply PIL-based augmentation before CLIP processing
        from torchvision import transforms
        pil_transforms = []
        if self.image_augmentation.strategy == 'none':
            pil_transforms.append(transforms.Resize((224, 224)))
        elif self.image_augmentation.strategy == 'light':
            pil_transforms.extend([
                transforms.Resize((224, 224)),
                transforms.RandomHorizontalFlip(p=0.5) if not self.is_test else transforms.Lambda(lambda x: x)
            ])
        elif self.image_augmentation.strategy == 'medium':
            if not self.is_test:
                pil_transforms.extend([
                    transforms.RandomResizedCrop(224, scale=(0.8, 1.0), ratio=(0.9, 1.1)),
                    transforms.RandomHorizontalFlip(p=0.5)
                ])
            else:
                pil_transforms.append(transforms.Resize((224, 224)))
        elif self.image_augmentation.strategy == 'strong':
            if not self.is_test:
                pil_transforms.extend([
                    transforms.RandomResizedCrop(224, scale=(0.8, 1.0), ratio=(0.9, 1.1)),
                    transforms.RandomHorizontalFlip(p=0.5),
                    transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1)
                ])
            else:
                pil_transforms.append(transforms.Resize((224, 224)))

        pil_transform = transforms.Compose(pil_transforms)
        image = pil_transform(image)

        # Tokenize text
        text_encoding = self.tokenizer(
            text,
            max_length=self.max_text_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )

        # Process image with CLIP processor (applies normalization)
        image_encoding = self.image_processor(
            images=image,
            return_tensors='pt'
        )

        item = {
            'guid': guid,
            'input_ids': text_encoding['input_ids'].squeeze(0),
            'attention_mask': text_encoding['attention_mask'].squeeze(0),
            'pixel_values': image_encoding['pixel_values'].squeeze(0)
        }

        # Add label if not test data
        if not self.is_test:
            label = row['tag']
            item['label'] = torch.tensor(LABEL2ID[label], dtype=torch.long)

        return item


class TextOnlyDataset(Dataset):
    """Dataset for text-only sentiment analysis."""

    def __init__(self,
                 data_df: pd.DataFrame,
                 data_dir: str,
                 tokenizer,
                 max_text_length: int = 128,
                 is_test: bool = False,
                 text_preprocess_strategy: str = 'raw'):
        self.data_df = data_df.reset_index(drop=True)
        self.data_dir = data_dir
        self.tokenizer = tokenizer
        self.max_text_length = max_text_length
        self.is_test = is_test

        # Initialize text preprocessor
        self.text_preprocessor = get_text_preprocessor(text_preprocess_strategy)

    def __len__(self):
        return len(self.data_df)

    def __getitem__(self, idx):
        row = self.data_df.iloc[idx]
        guid = str(row['guid'])

        # Load text
        text_path = os.path.join(self.data_dir, f"{guid}.txt")
        try:
            with open(text_path, 'r', encoding='utf-8', errors='ignore') as f:
                text = f.read().strip()
            # Apply text preprocessing
            text = self.text_preprocessor.preprocess(text)
        except Exception:
            text = ""

        # Tokenize text
        text_encoding = self.tokenizer(
            text,
            max_length=self.max_text_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )

        item = {
            'guid': guid,
            'input_ids': text_encoding['input_ids'].squeeze(0),
            'attention_mask': text_encoding['attention_mask'].squeeze(0)
        }

        if not self.is_test:
            label = row['tag']
            item['label'] = torch.tensor(LABEL2ID[label], dtype=torch.long)

        return item


class ImageOnlyDataset(Dataset):
    """Dataset for image-only sentiment analysis."""

    def __init__(self,
                 data_df: pd.DataFrame,
                 data_dir: str,
                 image_processor,
                 is_test: bool = False,
                 image_augmentation_strategy: str = 'none'):
        self.data_df = data_df.reset_index(drop=True)
        self.data_dir = data_dir
        self.image_processor = image_processor
        self.is_test = is_test

        # Initialize image augmentation
        self.image_augmentation = get_image_augmentation(image_augmentation_strategy)

    def __len__(self):
        return len(self.data_df)

    def __getitem__(self, idx):
        row = self.data_df.iloc[idx]
        guid = str(row['guid'])

        # Load image
        image_path = os.path.join(self.data_dir, f"{guid}.jpg")
        try:
            image = Image.open(image_path).convert('RGB')
        except Exception:
            image = Image.new('RGB', (224, 224), color='white')

        # Apply PIL-based augmentation before CLIP processing
        from torchvision import transforms
        pil_transforms = []
        if self.image_augmentation.strategy == 'none':
            pil_transforms.append(transforms.Resize((224, 224)))
        elif self.image_augmentation.strategy == 'light':
            pil_transforms.extend([
                transforms.Resize((224, 224)),
                transforms.RandomHorizontalFlip(p=0.5) if not self.is_test else transforms.Lambda(lambda x: x)
            ])
        elif self.image_augmentation.strategy == 'medium':
            if not self.is_test:
                pil_transforms.extend([
                    transforms.RandomResizedCrop(224, scale=(0.8, 1.0), ratio=(0.9, 1.1)),
                    transforms.RandomHorizontalFlip(p=0.5)
                ])
            else:
                pil_transforms.append(transforms.Resize((224, 224)))
        elif self.image_augmentation.strategy == 'strong':
            if not self.is_test:
                pil_transforms.extend([
                    transforms.RandomResizedCrop(224, scale=(0.8, 1.0), ratio=(0.9, 1.1)),
                    transforms.RandomHorizontalFlip(p=0.5),
                    transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1)
                ])
            else:
                pil_transforms.append(transforms.Resize((224, 224)))

        pil_transform = transforms.Compose(pil_transforms)
        image = pil_transform(image)

        # Process image
        image_encoding = self.image_processor(
            images=image,
            return_tensors='pt'
        )

        item = {
            'guid': guid,
            'pixel_values': image_encoding['pixel_values'].squeeze(0)
        }

        if not self.is_test:
            label = row['tag']
            item['label'] = torch.tensor(LABEL2ID[label], dtype=torch.long)

        return item


def load_data(train_file: str, test_file: str, val_ratio: float = 0.2, seed: int = 42):
    """
    Load and split data into train/val/test sets.

    Args:
        train_file: Path to training labels file
        test_file: Path to test file
        val_ratio: Validation set ratio
        seed: Random seed for reproducibility

    Returns:
        train_df, val_df, test_df
    """
    # Load training data
    train_df = pd.read_csv(train_file)

    # Load test data - CRITICAL: guid must be string to match filenames
    test_df = pd.read_csv(test_file, dtype={'guid': str})

    # Stratified split for train/val
    train_df, val_df = train_test_split(
        train_df,
        test_size=val_ratio,
        stratify=train_df['tag'],
        random_state=seed
    )

    print(f"Train size: {len(train_df)}")
    print(f"Val size: {len(val_df)}")
    print(f"Test size: {len(test_df)}")

    # Print class distribution
    print("\nTrain class distribution:")
    print(train_df['tag'].value_counts())

    return train_df, val_df, test_df


def get_dataloaders(args, mode: str = 'multimodal'):
    """
    Create data loaders for training and evaluation.

    Args:
        args: Configuration arguments
        mode: 'text_only', 'image_only', or 'multimodal'

    Returns:
        train_loader, val_loader, test_loader, tokenizer, image_processor
    """
    # Initialize tokenizer and image processor
    tokenizer = AutoTokenizer.from_pretrained(args.text_encoder)
    image_processor = CLIPImageProcessor.from_pretrained(args.image_encoder)

    # Load data
    train_df, val_df, test_df = load_data(
        args.train_file,
        args.test_file,
        args.val_ratio,
        args.seed
    )

    # Get preprocessing strategies from args
    text_preprocess_strategy = getattr(args, 'text_preprocess_strategy', 'raw')
    image_augmentation_strategy = getattr(args, 'image_augmentation_strategy', 'none')

    # Create datasets based on mode
    if mode == 'text_only':
        train_dataset = TextOnlyDataset(
            train_df, args.data_dir, tokenizer, args.max_text_length,
            text_preprocess_strategy=text_preprocess_strategy
        )
        val_dataset = TextOnlyDataset(
            val_df, args.data_dir, tokenizer, args.max_text_length,
            text_preprocess_strategy=text_preprocess_strategy
        )
        test_dataset = TextOnlyDataset(
            test_df, args.data_dir, tokenizer, args.max_text_length, is_test=True,
            text_preprocess_strategy=text_preprocess_strategy
        )
    elif mode == 'image_only':
        train_dataset = ImageOnlyDataset(
            train_df, args.data_dir, image_processor,
            image_augmentation_strategy=image_augmentation_strategy
        )
        val_dataset = ImageOnlyDataset(
            val_df, args.data_dir, image_processor,
            image_augmentation_strategy=image_augmentation_strategy
        )
        test_dataset = ImageOnlyDataset(
            test_df, args.data_dir, image_processor, is_test=True,
            image_augmentation_strategy=image_augmentation_strategy
        )
    else:  # multimodal
        train_dataset = MultimodalDataset(
            train_df, args.data_dir, tokenizer, image_processor, args.max_text_length,
            text_preprocess_strategy=text_preprocess_strategy,
            image_augmentation_strategy=image_augmentation_strategy
        )
        val_dataset = MultimodalDataset(
            val_df, args.data_dir, tokenizer, image_processor, args.max_text_length,
            text_preprocess_strategy=text_preprocess_strategy,
            image_augmentation_strategy=image_augmentation_strategy
        )
        test_dataset = MultimodalDataset(
            test_df, args.data_dir, tokenizer, image_processor, args.max_text_length, is_test=True,
            text_preprocess_strategy=text_preprocess_strategy,
            image_augmentation_strategy=image_augmentation_strategy
        )

    # Create data loaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=True
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True
    )

    return train_loader, val_loader, test_loader, tokenizer, image_processor

#!/usr/bin/env python
"""
Batch visualization script for comparing multiple experiments.
Generates comparison plots and summary reports.
"""
import os
import json
import argparse
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from pathlib import Path
from collections import defaultdict

sns.set_style("whitegrid")
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial']
plt.rcParams['axes.unicode_minus'] = False


def load_experiment_metrics(exp_dir: str) -> dict:
    """Load metrics from experiment directory."""
    metrics_file = Path(exp_dir) / "metrics.json"
    if not metrics_file.exists():
        return None

    with open(metrics_file, 'r') as f:
        return json.load(f)


def collect_all_experiments(base_dir: str, phase: str = None) -> dict:
    """Collect metrics from all experiments."""
    base_path = Path(base_dir)
    experiments = {}

    for exp_dir in base_path.iterdir():
        if not exp_dir.is_dir():
            continue

        exp_name = exp_dir.name

        # Filter by phase if specified
        if phase and not exp_name.startswith(phase):
            continue

        # Try to load metrics
        for seed_dir in exp_dir.iterdir():
            if seed_dir.is_dir() and seed_dir.name.startswith('seed_'):
                metrics = load_experiment_metrics(seed_dir)
                if metrics:
                    if exp_name not in experiments:
                        experiments[exp_name] = []
                    experiments[exp_name].append(metrics)

    return experiments


def plot_phase_comparison(experiments: dict, phase_name: str, output_dir: str):
    """
    Generate comparison plots for a specific phase.

    Args:
        experiments: Dict of {exp_name: [metrics_dict]}
        phase_name: Name of the phase (for title)
        output_dir: Output directory for plots
    """
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    # Collect final metrics for each experiment
    exp_results = []
    for exp_name, metrics_list in experiments.items():
        # Average across seeds
        final_f1_scores = []
        final_acc_scores = []
        final_neu_f1 = []

        for metrics in metrics_list:
            if 'val' in metrics and 'f1' in metrics['val']:
                val_f1 = metrics['val']['f1']
                val_acc = metrics['val']['accuracy']
                val_neu_f1 = metrics['val']['neu_f1']

                if val_f1:
                    final_f1_scores.append(val_f1[-1])
                    final_acc_scores.append(val_acc[-1])
                    final_neu_f1.append(val_neu_f1[-1])

        if final_f1_scores:
            exp_results.append({
                'Experiment': exp_name,
                'F1-Macro': np.mean(final_f1_scores),
                'F1-Std': np.std(final_f1_scores),
                'Accuracy': np.mean(final_acc_scores),
                'Acc-Std': np.std(final_acc_scores),
                'Neutral-F1': np.mean(final_neu_f1),
                'Neu-F1-Std': np.std(final_neu_f1),
                'Num-Seeds': len(final_f1_scores)
            })

    if not exp_results:
        print(f"No results found for phase {phase_name}")
        return

    df = pd.DataFrame(exp_results).sort_values('F1-Macro', ascending=False)

    # ========== Plot 1: F1 Score Comparison ==========
    fig, ax = plt.subplots(figsize=(12, 6))

    x = np.arange(len(df))
    bars = ax.bar(x, df['F1-Macro'], color='steelblue', alpha=0.8, edgecolor='black', linewidth=1.5)
    ax.errorbar(x, df['F1-Macro'], yerr=df['F1-Std'], fmt='none', ecolor='black',
               capsize=5, capthick=2, alpha=0.7)

    # Color bars by performance
    best_f1 = df['F1-Macro'].max()
    for i, (bar, f1) in enumerate(zip(bars, df['F1-Macro'])):
        if f1 == best_f1:
            bar.set_color('gold')
            bar.set_edgecolor('darkgoldenrod')
            bar.set_linewidth(3)

    # Add value labels
    for i, (f1, std) in enumerate(zip(df['F1-Macro'], df['F1-Std'])):
        ax.text(i, f1 + std + 0.01, f'{f1:.4f}±{std:.4f}',
               ha='center', va='bottom', fontsize=9, fontweight='bold')

    ax.set_xlabel('Experiment', fontsize=12)
    ax.set_ylabel('F1-Macro Score', fontsize=12)
    ax.set_title(f'{phase_name} - F1 Score Comparison', fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(df['Experiment'], rotation=45, ha='right')
    ax.set_ylim(0, max(df['F1-Macro'] + df['F1-Std']) * 1.1)
    ax.grid(True, axis='y', alpha=0.3)

    plt.tight_layout()
    plt.savefig(output_path / f"{phase_name}_f1_comparison.png", dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Saved F1 comparison plot")

    # ========== Plot 2: Neutral Class Performance ==========
    fig, ax = plt.subplots(figsize=(12, 6))

    bars = ax.bar(x, df['Neutral-F1'], color='coral', alpha=0.8, edgecolor='black', linewidth=1.5)
    ax.errorbar(x, df['Neutral-F1'], yerr=df['Neu-F1-Std'], fmt='none', ecolor='black',
               capsize=5, capthick=2, alpha=0.7)

    # Highlight best
    best_neu_f1 = df['Neutral-F1'].max()
    for i, (bar, neu_f1) in enumerate(zip(bars, df['Neutral-F1'])):
        if neu_f1 == best_neu_f1:
            bar.set_color('gold')
            bar.set_edgecolor('darkgoldenrod')
            bar.set_linewidth(3)

    # Add value labels
    for i, (neu_f1, std) in enumerate(zip(df['Neutral-F1'], df['Neu-F1-Std'])):
        ax.text(i, neu_f1 + std + 0.01, f'{neu_f1:.4f}±{std:.4f}',
               ha='center', va='bottom', fontsize=9, fontweight='bold')

    ax.set_xlabel('Experiment', fontsize=12)
    ax.set_ylabel('Neutral Class F1 Score', fontsize=12)
    ax.set_title(f'{phase_name} - Neutral Class Performance', fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(df['Experiment'], rotation=45, ha='right')
    ax.set_ylim(0, max(df['Neutral-F1'] + df['Neu-F1-Std']) * 1.1)
    ax.grid(True, axis='y', alpha=0.3)

    plt.tight_layout()
    plt.savefig(output_path / f"{phase_name}_neutral_f1_comparison.png", dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Saved Neutral F1 comparison plot")

    # ========== Plot 3: Heatmap ==========
    heatmap_data = df[['Experiment', 'F1-Macro', 'Accuracy', 'Neutral-F1']].set_index('Experiment')

    fig, ax = plt.subplots(figsize=(8, len(df) * 0.5 + 2))
    sns.heatmap(heatmap_data.T, annot=True, fmt='.4f', cmap='RdYlGn',
               center=0.5, vmin=0, vmax=1, cbar_kws={'label': 'Score'},
               linewidths=0.5, ax=ax)

    ax.set_title(f'{phase_name} - Performance Heatmap', fontsize=14, fontweight='bold')
    ax.set_xlabel('Experiments', fontsize=12)
    ax.set_ylabel('Metrics', fontsize=12)

    plt.tight_layout()
    plt.savefig(output_path / f"{phase_name}_heatmap.png", dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Saved heatmap")

    # ========== Save Summary Table ==========
    summary_file = output_path / f"{phase_name}_summary.csv"
    df.to_csv(summary_file, index=False)
    print(f"Saved summary table to {summary_file}")

    # Print summary
    print(f"\n{'='*70}")
    print(f"{phase_name} - Experiment Summary")
    print(f"{'='*70}")
    print(df.to_string(index=False))
    print(f"{'='*70}\n")

    print(f"Best Experiment: {df.iloc[0]['Experiment']}")
    print(f"Best F1-Macro: {df.iloc[0]['F1-Macro']:.4f} ± {df.iloc[0]['F1-Std']:.4f}")
    print(f"Best Neutral-F1: {df['Neutral-F1'].max():.4f}")


def plot_training_curves_comparison(experiments: dict, phase_name: str, output_dir: str):
    """Plot training curves for all experiments in a phase."""
    output_path = Path(output_dir)

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))

    colors = plt.cm.tab10(np.linspace(0, 1, len(experiments)))

    for i, (exp_name, metrics_list) in enumerate(experiments.items()):
        # Average metrics across seeds
        all_epochs = []
        all_f1 = []

        for metrics in metrics_list:
            if 'val' in metrics and 'f1' in metrics['val']:
                epochs = metrics['val']['epoch']
                f1 = metrics['val']['f1']
                all_epochs.append(epochs)
                all_f1.append(f1)

        if all_f1:
            # Pad to same length
            max_len = max(len(f) for f in all_f1)
            padded_f1 = [f + [f[-1]] * (max_len - len(f)) for f in all_f1]

            mean_f1 = np.mean(padded_f1, axis=0)
            std_f1 = np.std(padded_f1, axis=0)
            epochs = list(range(1, len(mean_f1) + 1))

            # F1 curve
            axes[0].plot(epochs, mean_f1, '-o', label=exp_name, color=colors[i],
                        linewidth=2, markersize=4)
            axes[0].fill_between(epochs, mean_f1 - std_f1, mean_f1 + std_f1,
                                alpha=0.2, color=colors[i])

    axes[0].set_xlabel('Epoch', fontsize=12)
    axes[0].set_ylabel('Validation F1 Score', fontsize=12)
    axes[0].set_title(f'{phase_name} - F1 Curves', fontsize=13, fontweight='bold')
    axes[0].legend(fontsize=9, loc='best')
    axes[0].grid(True, alpha=0.3)

    # Final F1 bar chart
    exp_names = []
    final_f1_means = []
    final_f1_stds = []

    for exp_name, metrics_list in experiments.items():
        final_f1 = []
        for metrics in metrics_list:
            if 'val' in metrics and 'f1' in metrics['val']:
                final_f1.append(metrics['val']['f1'][-1])

        if final_f1:
            exp_names.append(exp_name)
            final_f1_means.append(np.mean(final_f1))
            final_f1_stds.append(np.std(final_f1))

    x = np.arange(len(exp_names))
    axes[1].bar(x, final_f1_means, color=colors[:len(exp_names)], alpha=0.8,
               edgecolor='black', linewidth=1.5)
    axes[1].errorbar(x, final_f1_means, yerr=final_f1_stds, fmt='none',
                    ecolor='black', capsize=5, capthick=2)

    axes[1].set_xlabel('Experiment', fontsize=12)
    axes[1].set_ylabel('Final F1 Score', fontsize=12)
    axes[1].set_title(f'{phase_name} - Final F1', fontsize=13, fontweight='bold')
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(exp_names, rotation=45, ha='right', fontsize=9)
    axes[1].grid(True, axis='y', alpha=0.3)

    plt.suptitle(f'{phase_name} - Training Curves Comparison', fontsize=15, fontweight='bold', y=1.02)
    plt.tight_layout()
    plt.savefig(output_path / f"{phase_name}_curves_comparison.png", dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Saved training curves comparison")


def main():
    parser = argparse.ArgumentParser(description='Batch visualization for experiments')
    parser.add_argument('--exp_dir', type=str, required=True,
                       help='Experiment results directory')
    parser.add_argument('--phase', type=str, default=None,
                       choices=['T', 'I', 'LF', 'EF', 'L', 'D'],
                       help='Phase prefix to filter experiments')
    parser.add_argument('--output_dir', type=str, default='./comparison_plots',
                       help='Output directory for comparison plots')

    args = parser.parse_args()

    # Collect experiments
    print(f"Collecting experiments from: {args.exp_dir}")
    experiments = collect_all_experiments(args.exp_dir, args.phase)

    if not experiments:
        print("No experiments found!")
        return

    print(f"Found {len(experiments)} experiments")

    # Generate comparison plots
    phase_name = args.phase if args.phase else "All_Experiments"
    plot_phase_comparison(experiments, phase_name, args.output_dir)
    plot_training_curves_comparison(experiments, phase_name, args.output_dir)

    print(f"\nAll comparison plots saved to: {args.output_dir}")


if __name__ == '__main__':
    main()

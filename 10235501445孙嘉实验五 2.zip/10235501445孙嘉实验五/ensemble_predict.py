"""
使用集成方法对project5数据进行预测
结合多个不同配置的模型来获得更准确的预测
"""
import os
import sys
import torch
import random
import numpy as np
import pandas as pd
from config import get_config
from predict import predict_text_only
from train import train_text_expert

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def train_and_predict(config_name, args_list):
    """训练一个模型并返回预测结果"""
    sys.argv = args_list
    args = get_config()
    set_seed(args.seed)

    if args.device == 'cuda' and not torch.cuda.is_available():
        args.device = 'cpu'

    print(f"\n{'='*60}")
    print(f"训练模型: {config_name}")
    print(f"{'='*60}")

    os.makedirs(args.output_dir, exist_ok=True)

    # 训练
    train_text_expert(args)

    # 预测
    predictions = predict_text_only(args)

    return predictions

def main():
    print("=" * 60)
    print("Project5 集成预测系统")
    print("=" * 60)

    all_predictions = []

    # 配置1: 标准配置
    config1 = [
        'ensemble.py',
        '--data_dir', 'project5/data',
        '--train_file', 'project5/train.txt',
        '--test_file', 'project5/test_without_label.txt',
        '--output_dir', 'project5_ensemble/model1',
        '--mode', 'text_only',
        '--text_encoder', 'bert-base-uncased',
        '--hidden_dim', '256',
        '--dropout', '0.2',
        '--batch_size', '32',
        '--num_epochs', '12',
        '--encoder_lr', '2e-5',
        '--classifier_lr', '1e-4',
        '--text_preprocess_strategy', 'clean',
        '--loss_type', 'weighted_ce',
        '--class_weight_mode', 'inverse_sqrt',
        '--early_stopping',
        '--patience', '4',
        '--seed', '42',
        '--device', 'cuda'
    ]
    pred1 = train_and_predict("Model 1 (Weighted CE + inverse_sqrt)", config1)
    all_predictions.append(pred1)

    # 配置2: Focal Loss with lower gamma
    config2 = [
        'ensemble.py',
        '--data_dir', 'project5/data',
        '--train_file', 'project5/train.txt',
        '--test_file', 'project5/test_without_label.txt',
        '--output_dir', 'project5_ensemble/model2',
        '--mode', 'text_only',
        '--text_encoder', 'bert-base-uncased',
        '--hidden_dim', '256',
        '--dropout', '0.3',
        '--batch_size', '32',
        '--num_epochs', '12',
        '--encoder_lr', '1.5e-5',
        '--classifier_lr', '8e-5',
        '--text_preprocess_strategy', 'clean',
        '--loss_type', 'focal',
        '--focal_gamma', '1.0',
        '--early_stopping',
        '--patience', '4',
        '--seed', '2024',
        '--device', 'cuda'
    ]
    pred2 = train_and_predict("Model 2 (Focal Loss gamma=1.0)", config2)
    all_predictions.append(pred2)

    # 配置3: LDAM Loss
    config3 = [
        'ensemble.py',
        '--data_dir', 'project5/data',
        '--train_file', 'project5/train.txt',
        '--test_file', 'project5/test_without_label.txt',
        '--output_dir', 'project5_ensemble/model3',
        '--mode', 'text_only',
        '--text_encoder', 'bert-base-uncased',
        '--hidden_dim', '256',
        '--dropout', '0.25',
        '--batch_size', '32',
        '--num_epochs', '12',
        '--encoder_lr', '2e-5',
        '--classifier_lr', '1e-4',
        '--text_preprocess_strategy', 'clean',
        '--loss_type', 'ldam',
        '--early_stopping',
        '--patience', '4',
        '--seed', '2026',
        '--device', 'cuda'
    ]
    pred3 = train_and_predict("Model 3 (LDAM Loss)", config3)
    all_predictions.append(pred3)

    # 集成预测 - 使用投票
    print("\n" + "=" * 60)
    print("集成预测结果")
    print("=" * 60)

    # 合并所有预测
    from config import LABEL2ID
    label_to_id = LABEL2ID

    ensemble_predictions = []
    guids = pred1['guid'].values

    for i in range(len(guids)):
        votes = {}
        for pred_df in all_predictions:
            label = pred_df.iloc[i]['tag']
            votes[label] = votes.get(label, 0) + 1

        # 选择得票最多的标签
        final_label = max(votes, key=votes.get)
        ensemble_predictions.append(final_label)

    # 创建最终预测结果
    final_df = pd.DataFrame({
        'guid': guids,
        'tag': ensemble_predictions
    })

    # 保存结果
    output_dir = 'project5_ensemble'
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, 'predictions_ensemble.txt')
    final_df.to_csv(output_path, index=False)

    print(f"\n集成预测结果已保存到: {output_path}")
    print("\n预测结果统计:")
    print(final_df['tag'].value_counts())
    print(f"\n总预测数: {len(final_df)}")

    print("\n各模型预测统计:")
    for i, pred_df in enumerate(all_predictions, 1):
        print(f"\nModel {i}:")
        print(pred_df['tag'].value_counts())

if __name__ == '__main__':
    main()

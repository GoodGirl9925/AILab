# mlp_hs_bs_search.py
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, log_loss
from itertools import product
import time
import ast

# -----------------------------
# USER SETTINGS (可按需修改)
# -----------------------------
DATA_PATH = "train_data.csv"   # <- 替成你的文件名，例如 "data.csv"
TEXT_COL = "text"
LABEL_COL = "target"

# fixed hyperparams
FIXED_ALPHA = 1e-4
FIXED_LR = 0.01
EPOCHS = 30

# grid to explore
HIDDEN_LIST = [(64,), (128,), (256,), (128, 64), (256, 128)]
BATCH_LIST = [32, 64, 128, 256]

# TF-IDF
MAX_FEATURES = 5000

# random seed
RANDOM_STATE = 42

# -----------------------------
# 1. 加载并预处理数据
# -----------------------------
print("Loading data...")
data = pd.read_csv(DATA_PATH, encoding="utf-8")
print("Columns:", data.columns.tolist())
X_raw = data[TEXT_COL].astype(str).tolist()
y = data[LABEL_COL].values

print("Vectorizing with TF-IDF (max_features=%d)..." % MAX_FEATURES)
vectorizer = TfidfVectorizer(max_features=MAX_FEATURES, stop_words="english")
X = vectorizer.fit_transform(X_raw)

X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
)

# -----------------------------
# 2. 逐组合训练并记录历史
# -----------------------------
results = []  # 用于汇总最终指标
histories = {}  # 保存每个组合的训练历史（loss/acc）

total_runs = len(HIDDEN_LIST) * len(BATCH_LIST)
run_idx = 0
start_all = time.time()

for hidden, batch in product(HIDDEN_LIST, BATCH_LIST):
    run_idx += 1
    combo_name = f"{hidden}_bs{batch}"
    print(f"\n[{run_idx}/{total_runs}] Training combo: hidden={hidden}, batch_size={batch}")
    # 初始化 MLP：使用 warm_start + max_iter=1 来自己控制 epoch（以便记录每个 epoch 指标）
    clf = MLPClassifier(
        hidden_layer_sizes=hidden,
        activation="relu",
        solver="sgd",
        alpha=FIXED_ALPHA,
        learning_rate_init=FIXED_LR,
        batch_size=batch,
        max_iter=1,
        warm_start=True,
        random_state=RANDOM_STATE,
        tol=1e-6,
        verbose=False
    )

    history = {
        "train_loss": [],
        "val_loss": [],
        "train_acc": [],
        "val_acc": []
    }

    # 训练 EPOCHS 次（每次 fit 运行 1 次迭代并保持权重）
    for epoch in range(1, EPOCHS + 1):
        try:
            clf.fit(X_train, y_train)  # 每次只跑 1 iteration，但因为 warm_start=True，会接着上一次训练
        except Exception as e:
            # 如果某些组合在训练中出错（如数值问题），记录并跳出
            print(f"  Error during fit at epoch {epoch}: {e}")
            break

        # 计算概率预测以求 log_loss（若分类器不支持 predict_proba 会异常）
        # 有时 MLPClassifier 在某些点可能还没准备好 predict_proba —— 用 try/except 保护
        try:
            y_train_proba = clf.predict_proba(X_train)
            y_val_proba = clf.predict_proba(X_val)
            t_loss = log_loss(y_train, y_train_proba, labels=clf.classes_)
            v_loss = log_loss(y_val, y_val_proba, labels=clf.classes_)
        except Exception:
            # fallback: 使用 clf.loss_（训练集的目标）作为 train_loss，val_loss 置为 np.nan
            t_loss = getattr(clf, "loss_", np.nan)
            v_loss = np.nan

        y_train_pred = clf.predict(X_train)
        y_val_pred = clf.predict(X_val)
        t_acc = accuracy_score(y_train, y_train_pred)
        v_acc = accuracy_score(y_val, y_val_pred)

        history["train_loss"].append(float(t_loss))
        history["val_loss"].append(float(v_loss) if not np.isnan(v_loss) else np.nan)
        history["train_acc"].append(float(t_acc))
        history["val_acc"].append(float(v_acc))

        # 可选：打印少量 epoch 信息
        if epoch % 5 == 0 or epoch == 1 or epoch == EPOCHS:
            print(f"   epoch {epoch:02d}/{EPOCHS} | train_acc={t_acc:.4f} val_acc={v_acc:.4f} train_loss={t_loss:.4f}")

    # 训练结束：记录最终指标
    final_train_acc = history["train_acc"][-1] if history["train_acc"] else np.nan
    final_val_acc = history["val_acc"][-1] if history["val_acc"] else np.nan
    final_train_loss = history["train_loss"][-1] if history["train_loss"] else np.nan
    final_val_loss = history["val_loss"][-1] if history["val_loss"] else np.nan

    results.append({
        "hidden_layer_sizes": str(hidden),
        "batch_size": batch,
        "final_train_acc": final_train_acc,
        "final_val_acc": final_val_acc,
        "final_train_loss": final_train_loss,
        "final_val_loss": final_val_loss
    })

    histories[combo_name] = {
        "params": {"hidden": hidden, "batch": batch},
        "history": history
    }

end_all = time.time()
print(f"\nAll runs finished in {end_all - start_all:.1f} seconds.")

# -----------------------------
# 3. 保存结果
# -----------------------------
df_res = pd.DataFrame(results)
df_res = df_res.sort_values("final_val_acc", ascending=False).reset_index(drop=True)
df_res.to_csv("mlp_hs_bs_results.csv", index=False)
print("Saved summary to mlp_hs_bs_results.csv")
print("\nTop results:")
print(df_res.head(10))

# -----------------------------
# 4. 可视化：热力图 (hidden × batch 的 final_val_acc)
# -----------------------------
# 把 hidden_layer_sizes 做成字符串列用于 pivot
pivot = df_res.pivot(index="hidden_layer_sizes", columns="batch_size", values="final_val_acc")
plt.figure(figsize=(8, max(4, 0.6 * len(pivot))))
sns.heatmap(pivot, annot=True, fmt=".4f", cmap="YlGnBu")
plt.title(f"Final Validation Accuracy (alpha={FIXED_ALPHA}, lr={FIXED_LR}, epochs={EPOCHS})")
plt.ylabel("hidden_layer_sizes")
plt.xlabel("batch_size")
plt.tight_layout()
plt.savefig("mlp_hs_bs_heatmap.png", dpi=300)
plt.show()

# -----------------------------
# 5. 可视化：绘制 top-K 组合的训练曲线
# -----------------------------
TOP_K = 3
top_combos = df_res.head(TOP_K)

for idx, row in top_combos.iterrows():
    hidden_str = row["hidden_layer_sizes"]
    batch = row["batch_size"]
    combo_name = f"{hidden_str}_bs{batch}"
    rec = histories.get(combo_name)
    if rec is None:
        continue
    h = rec["history"]
    epochs_range = range(1, len(h["train_loss"]) + 1)

    # loss plot
    plt.figure(figsize=(8, 4))
    plt.plot(epochs_range, h["train_loss"], marker="o", label="train_loss")
    if not all(np.isnan(h["val_loss"])):
        plt.plot(epochs_range, h["val_loss"], marker="s", label="val_loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title(f"Loss per epoch | {combo_name}")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"loss_{combo_name}.png", dpi=200)
    plt.show()

    # acc plot
    plt.figure(figsize=(8, 4))
    plt.plot(epochs_range, h["train_acc"], marker="o", label="train_acc")
    plt.plot(epochs_range, h["val_acc"], marker="s", label="val_acc")
    plt.xlabel("Epoch")
    plt.ylabel("Accuracy")
    plt.title(f"Accuracy per epoch | {combo_name}")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"acc_{combo_name}.png", dpi=200)
    plt.show()

print("Top combo curves saved (loss_*.png, acc_*.png).")

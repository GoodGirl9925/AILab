# my_experiment.py

import pandas as pd
import re
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import accuracy_score

# NLTK 词形还原
import nltk

from nltk.stem import WordNetLemmatizer
matplotlib.use("TkAgg")

# 如果是第一次运行，请取消注释以下三行下载所需的资源
# nltk.download('wordnet')
# nltk.download('omw-1.4')
# nltk.download('punkt')

lemmatizer = WordNetLemmatizer()

# ========================
# 1. 数据加载
# ========================
def load_data(train_path="train_data.csv", test_path="test_data_unlabeled.csv"):
    train_df = pd.read_csv(train_path)
    test_df = pd.read_csv(test_path)

    X_train = train_df['text'].astype(str).tolist()
    y_train = train_df['target'].values
    X_test_unlabeled = test_df['text'].astype(str).tolist()

    return X_train, y_train, X_test_unlabeled


# ========================
# 2. 文本清洗函数
# ========================
def clean_text(text):
    """
    针对新闻类文本的清洗：
    1. 去掉邮件头部、标题等非正文信息（如 "From:", "Subject:" 等）。
    2. 去掉URL、邮箱地址。
    3. 去掉标点符号、数字。
    4. 转小写。
    5. 单词词形还原 (running -> run, studies -> study)。
    """
    # 去掉常见的邮件头部信息
    text = re.sub(r"From:.*\n", " ", text)
    text = re.sub(r"Subject:.*\n", " ", text)
    text = re.sub(r"Organization:.*\n", " ", text)
    text = re.sub(r"Lines:.*\n", " ", text)

    # 去掉网址和邮箱
    text = re.sub(r"http\S+|www\S+|@\S+", " ", text)

    # 去掉标点和数字
    text = re.sub(r"[^a-zA-Z]", " ", text)

    # 转换为小写
    text = text.lower()

    # 去掉多余空格
    text = re.sub(r"\s+", " ", text).strip()

    # 词形还原
    words = text.split()
    words = [lemmatizer.lemmatize(w) for w in words]
    text = " ".join(words)

    return text


# ========================
# 3. 预处理与向量化
# ========================
def preprocess_and_vectorize(X_train, X_test_unlabeled, y_train, max_features=5000):
    # 对训练集和测试集都进行清洗
    X_train_clean = [clean_text(text) for text in X_train]
    X_test_clean = [clean_text(text) for text in X_test_unlabeled]

    # 划分训练集和验证集
    X_train_clean, X_val_clean, y_train_split, y_val_split = train_test_split(
        X_train_clean, y_train, test_size=0.2, random_state=42, stratify=y_train
    )

    # TF-IDF 向量化
    vectorizer = TfidfVectorizer(max_features=max_features, stop_words="english")
    X_train_tfidf = vectorizer.fit_transform(X_train_clean)
    X_val_tfidf = vectorizer.transform(X_val_clean)
    X_test_tfidf = vectorizer.transform(X_test_clean)

    return X_train_tfidf, X_val_tfidf, X_test_tfidf, y_train_split, y_val_split, vectorizer

# ========================
# 4. 朴素贝叶斯 (Naive Bayes)
# ========================
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score


def train_nb(X_train_tfidf, y_train, X_val_tfidf, y_val):
    """
    训练朴素贝叶斯分类器，并返回验证集准确率和训练好的模型
    """
    print("\n--- 开始训练朴素贝叶斯模型 ---")
    nb_classifier = MultinomialNB()
    nb_classifier.fit(X_train_tfidf, y_train)
    print("模型训练完成！")

    # 在验证集上评估
    y_val_pred = nb_classifier.predict(X_val_tfidf)
    val_acc = accuracy_score(y_val, y_val_pred)
    print(f"验证集准确率: {val_acc:.4f}")

    return nb_classifier, val_acc


def test_nb(model, X_test_tfidf, output_path="nb_test_predictions.csv"):
    """
    使用训练好的朴素贝叶斯模型在无标签测试集上预测，并保存结果
    """
    print("\n--- 使用朴素贝叶斯模型进行测试集预测 ---")
    y_test_pred = model.predict(X_test_tfidf)

    # 保存为 CSV 文件，格式：id, target
    df_pred = pd.DataFrame({
        "id": range(len(y_test_pred)),
        "target": y_test_pred
    })
    df_pred.to_csv(output_path, index=False)
    print(f"测试集预测结果已保存至 {output_path}")

    return y_test_pred
# ========================
# 5. SVM (Support Vector Machine)
# ========================
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

def train_svm(X_train_tfidf, y_train, X_val_tfidf, y_val, kernel="linear", C=1.0):
    """
    训练 SVM 模型，并返回验证集准确率和训练好的模型
    参数:
        X_train_tfidf, y_train: 训练集
        X_val_tfidf, y_val: 验证集
        kernel: 核函数 (linear, rbf, poly, sigmoid)
        C: 正则化系数 (越大越容易过拟合)
    """
    print("\n--- 开始训练 SVM 模型 ---")
    svm_classifier = SVC(kernel=kernel, C=C, probability=True, random_state=42)
    svm_classifier.fit(X_train_tfidf, y_train)
    print("模型训练完成！")

    # 在验证集上评估
    y_val_pred = svm_classifier.predict(X_val_tfidf)
    val_acc = accuracy_score(y_val, y_val_pred)
    print(f"验证集准确率: {val_acc:.4f}")

    return svm_classifier, val_acc


def test_svm(model, X_test_tfidf, output_path="svm_test_predictions.csv"):
    """
    使用训练好的 SVM 模型在无标签测试集上预测，并保存结果
    参数:
        model: 训练好的 SVM 模型
        X_test_tfidf: 测试集向量
        output_path: 输出预测文件路径
    """
    print("\n--- 使用 SVM 模型进行测试集预测 ---")
    y_test_pred = model.predict(X_test_tfidf)

import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import SGDClassifier
from sklearn.utils import shuffle
from sklearn.metrics import accuracy_score

def _multiclass_hinge_loss(clf, X, y):
    """
    计算多类 hinge loss 的均值：
    loss_i = sum_{j != y_i} max(0, 1 - s_{y_i} + s_j)
    对二分类也适用（将 decision_function 返回的一维情况特殊处理）。
    """
    scores = clf.decision_function(X)
    # binary case: scores shape (n_samples,)
    if scores.ndim == 1:
        # map y to {-1, +1} according to clf.classes_
        classes = clf.classes_
        if len(classes) != 2:
            # fallback: compute simple hinge using sign
            y_signed = np.where(y == classes[-1], 1, -1)
        else:
            pos = classes[1]
            y_signed = np.where(y == pos, 1, -1)
        loss = np.maximum(0, 1 - y_signed * scores)
        return float(np.mean(loss))
    # multiclass case: scores shape (n_samples, n_classes)
    n_samples = scores.shape[0]
    class_to_index = {c: idx for idx, c in enumerate(clf.classes_)}
    y_idx = np.array([class_to_index[yy] for yy in y])
    s_y = scores[np.arange(n_samples), y_idx]            # shape (n_samples,)
    # margins = 1 - s_y + s_j ; set margin for true class to 0
    margins = 1 - s_y[:, np.newaxis] + scores            # shape (n_samples, n_classes)
    margins[np.arange(n_samples), y_idx] = 0
    margins = np.maximum(0, margins)
    loss_per_sample = margins.sum(axis=1)                # sum over j != y
    return float(loss_per_sample.mean())


def train_svm_with_loss(X_train_tfidf, y_train, X_val_tfidf, y_val,
                        epochs=100, batch_size=32, alpha=1e-4, learning_rate='optimal',
                        random_state=42, verbose=True):
    """
    使用 SGDClassifier(loss='hinge') 按 epoch & mini-batch 训练 SVM，
    在每个 epoch 结束后输出训练/验证集的 hinge loss 和 accuracy，并返回训练历史。

    返回:
        clf: 训练好的模型
        history: dict 包含 'train_loss', 'val_loss', 'train_acc', 'val_acc'
    """
    # 初始化分类器（线性 SVM 近似）
    clf = SGDClassifier(loss='hinge',
                        penalty='l2',
                        alpha=alpha,
                        learning_rate=learning_rate,
                        random_state=random_state,
                        tol=None,            # 禁用 internal 执行停止，使用我们的 epochs 控制
                        shuffle=False)       # 我们在外面 shuffle

    classes = np.unique(y_train)
    n_samples = X_train_tfidf.shape[0]

    history = {
        'train_loss': [],
        'val_loss': [],
        'train_acc': [],
        'val_acc': []
    }

    first_partial = True

    for epoch in range(1, epochs + 1):
        # shuffle training数据（支持稀疏矩阵）
        X_shuf, y_shuf = shuffle(X_train_tfidf, y_train, random_state=random_state + epoch)

        # mini-batch partial_fit
        for start in range(0, n_samples, batch_size):
            end = start + batch_size
            X_batch = X_shuf[start:end]
            y_batch = y_shuf[start:end]
            if first_partial:
                clf.partial_fit(X_batch, y_batch, classes=classes)
                first_partial = False
            else:
                clf.partial_fit(X_batch, y_batch)

        # 计算 epoch 指标（hinge loss + accuracy）
        train_loss = _multiclass_hinge_loss(clf, X_train_tfidf, y_train)
        val_loss = _multiclass_hinge_loss(clf, X_val_tfidf, y_val)

        y_train_pred = clf.predict(X_train_tfidf)
        y_val_pred = clf.predict(X_val_tfidf)
        train_acc = float(accuracy_score(y_train, y_train_pred))
        val_acc = float(accuracy_score(y_val, y_val_pred))

        history['train_loss'].append(train_loss)
        history['val_loss'].append(val_loss)
        history['train_acc'].append(train_acc)
        history['val_acc'].append(val_acc)

        if verbose:
            print(f"Epoch {epoch:2d}/{epochs} | "
                  f"train_loss: {train_loss:.4f} val_loss: {val_loss:.4f} | "
                  f"train_acc: {train_acc:.4f} val_acc: {val_acc:.4f}")

    return clf, history


def plot_training_history(history, figsize=(8, 5), save_path=None, show_acc=False):
    """
    画出训练 / 验证 loss 曲线。若 show_acc=True，则同时画 accuracy 曲线（右轴）。
    """
    epochs = range(1, len(history['train_loss']) + 1)

    plt.figure(figsize=figsize)
    plt.plot(epochs, history['train_loss'], marker='o', ms=3,label='train loss')
    plt.plot(epochs, history['val_loss'], marker='o', ms=3,label='val loss')
    plt.xlabel('Epoch')
    plt.ylabel('Hinge Loss')
    plt.title('SVM Training: hinge loss per epoch')
    plt.grid(True)
    plt.legend(loc='upper left')

    if show_acc:
        ax = plt.gca()
        ax2 = ax.twinx()
        ax2.plot(epochs, history['train_acc'], linestyle='--', marker='x',ms=3, label='train acc')
        ax2.plot(epochs, history['val_acc'], linestyle='--', marker='x', ms=3,label='val acc')
        ax2.set_ylabel('Accuracy')
        # 合并图例
        lines, labels = ax.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax.legend(lines + lines2, labels + labels2, loc='upper center')

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"训练曲线已保存到 {save_path}")
    plt.show()


def test_svm(model, X_test_tfidf, output_path="svm_test_predictions.csv"):
    """
    与之前行为一致：对无标签测试集做预测并保存结果（id, target）
    """
    print("\n--- 使用 SVM 模型进行测试集预测 ---")
    y_test_pred = model.predict(X_test_tfidf)

    df_pred = pd.DataFrame({
        "id": range(len(y_test_pred)),
        "target": y_test_pred
    })
    df_pred.to_csv(output_path, index=False)
    print(f"测试集预测结果已保存至 {output_path}")

    return y_test_pred

# ========================
# Logistic Regression (逐步训练版本)
# ========================
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import SGDClassifier
from sklearn.utils import shuffle
from sklearn.metrics import log_loss, accuracy_score
import pandas as pd


def train_logreg_with_loss(X_train_tfidf, y_train, X_val_tfidf, y_val,
                           epochs=10, batch_size=256, alpha=1e-4,
                           learning_rate='optimal', random_state=42, verbose=True):
    """
    使用 SGDClassifier(loss='log_loss') 来模拟逻辑回归，逐步训练。
    每个 epoch 结束后输出 train/val 的 log_loss 和 accuracy。

    返回:
        clf: 训练好的逻辑回归模型
        history: dict 包含 'train_loss', 'val_loss', 'train_acc', 'val_acc'
    """
    clf = SGDClassifier(loss='log_loss',
                        penalty='l2',
                        alpha=alpha,
                        learning_rate=learning_rate,
                        random_state=random_state,
                        tol=None,
                        shuffle=False)

    classes = np.unique(y_train)
    n_samples = X_train_tfidf.shape[0]

    history = {'train_loss': [], 'val_loss': [], 'train_acc': [], 'val_acc': []}
    first_partial = True

    for epoch in range(1, epochs + 1):
        # 打乱数据
        X_shuf, y_shuf = shuffle(X_train_tfidf, y_train, random_state=random_state + epoch)

        # mini-batch partial_fit
        for start in range(0, n_samples, batch_size):
            end = start + batch_size
            X_batch = X_shuf[start:end]
            y_batch = y_shuf[start:end]
            if first_partial:
                clf.partial_fit(X_batch, y_batch, classes=classes)
                first_partial = False
            else:
                clf.partial_fit(X_batch, y_batch)

        # 计算 epoch 的 loss 和 acc
        y_train_pred_prob = clf.predict_proba(X_train_tfidf)
        y_val_pred_prob = clf.predict_proba(X_val_tfidf)
        train_loss = log_loss(y_train, y_train_pred_prob, labels=classes)
        val_loss = log_loss(y_val, y_val_pred_prob, labels=classes)

        y_train_pred = clf.predict(X_train_tfidf)
        y_val_pred = clf.predict(X_val_tfidf)
        train_acc = accuracy_score(y_train, y_train_pred)
        val_acc = accuracy_score(y_val, y_val_pred)

        history['train_loss'].append(train_loss)
        history['val_loss'].append(val_loss)
        history['train_acc'].append(train_acc)
        history['val_acc'].append(val_acc)

        if verbose:
            print(f"Epoch {epoch:2d}/{epochs} | "
                  f"train_loss: {train_loss:.4f} val_loss: {val_loss:.4f} | "
                  f"train_acc: {train_acc:.4f} val_acc: {val_acc:.4f}")

    return clf, history


def plot_logreg_history(history, figsize=(8, 5), save_path=None, show_acc=True):
    """
    画出逻辑回归训练的 loss / acc 曲线
    """
    epochs = range(1, len(history['train_loss']) + 1)

    plt.figure(figsize=figsize)
    plt.plot(epochs, history['train_loss'], marker='o', label='train loss')
    plt.plot(epochs, history['val_loss'], marker='o', label='val loss')
    plt.xlabel('Epoch')
    plt.ylabel('Log Loss')
    plt.title('Logistic Regression Training')
    plt.grid(True)
    plt.legend(loc='upper left')

    if show_acc:
        ax = plt.gca()
        ax2 = ax.twinx()
        ax2.plot(epochs, history['train_acc'], linestyle='--', marker='x', label='train acc')
        ax2.plot(epochs, history['val_acc'], linestyle='--', marker='x', label='val acc')
        ax2.set_ylabel('Accuracy')
        lines, labels = ax.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax.legend(lines + lines2, labels + labels2, loc='upper center')

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"曲线已保存到 {save_path}")
    plt.show()


def test_logreg(model, X_test_tfidf, output_path="logreg_test_predictions.csv"):
    """
    对测试集做预测并保存结果
    """
    print("\n--- 使用逻辑回归模型进行测试集预测 ---")
    y_test_pred = model.predict(X_test_tfidf)

    df_pred = pd.DataFrame({
        "id": range(len(y_test_pred)),
        "target": y_test_pred
    })
    df_pred.to_csv(output_path, index=False)
    print(f"测试集预测结果已保存至 {output_path}")

    return y_test_pred

# ========================
# MLP (多层感知机)
# ========================
import numpy as np
import matplotlib.pyplot as plt
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import log_loss, accuracy_score
from sklearn.utils import shuffle
import pandas as pd

def train_mlp_with_loss(X_train, y_train, X_val, y_val,
                        epochs=10, batch_size=256, hidden_layer_sizes=(100,),
                        alpha=1e-4, learning_rate_init=0.001, random_state=42,
                        verbose=True):
    """
    使用 MLPClassifier + partial_fit 逐步训练，取消 warm_start 避免类别冲突。
    每个 epoch 输出 train/val 的 log_loss 和 accuracy。
    """
    # 初始化模型
    clf = MLPClassifier(
        hidden_layer_sizes=hidden_layer_sizes,
        activation='relu',
        solver='sgd',
        alpha=alpha,
        batch_size=batch_size,
        learning_rate_init=learning_rate_init,
        max_iter=1,         # 每次只训练一个 epoch
        warm_start=False,   # ❌ 取消 warm_start
        random_state=random_state
    )

    classes = np.unique(y_train)
    n_samples = X_train.shape[0]

    history = {'train_loss': [], 'val_loss': [], 'train_acc': [], 'val_acc': []}

    for epoch in range(1, epochs + 1):
        # shuffle 数据
        X_shuf, y_shuf = shuffle(X_train, y_train, random_state=random_state + epoch)

        # mini-batch partial_fit
        for start in range(0, n_samples, batch_size):
            end = start + batch_size
            X_batch = X_shuf[start:end]
            y_batch = y_shuf[start:end]
            clf.partial_fit(X_batch, y_batch, classes=classes)  # 每次都加上 classes

        # 计算 train/val loss 和 accuracy
        y_train_pred_prob = clf.predict_proba(X_train)
        y_val_pred_prob = clf.predict_proba(X_val)
        train_loss = log_loss(y_train, y_train_pred_prob, labels=classes)
        val_loss = log_loss(y_val, y_val_pred_prob, labels=classes)

        y_train_pred = clf.predict(X_train)
        y_val_pred = clf.predict(X_val)
        train_acc = accuracy_score(y_train, y_train_pred)
        val_acc = accuracy_score(y_val, y_val_pred)

        history['train_loss'].append(train_loss)
        history['val_loss'].append(val_loss)
        history['train_acc'].append(train_acc)
        history['val_acc'].append(val_acc)

        if verbose:
            print(f"Epoch {epoch:2d}/{epochs} | "
                  f"train_loss: {train_loss:.4f} val_loss: {val_loss:.4f} | "
                  f"train_acc: {train_acc:.4f} val_acc: {val_acc:.4f}")

    return clf, history



def plot_mlp_history(history, figsize=(8, 5), save_path=None, show_acc=True):
    """
    绘制 MLP 训练的 loss 和 accuracy 曲线
    """
    epochs = range(1, len(history['train_loss']) + 1)

    plt.figure(figsize=figsize)
    plt.plot(epochs, history['train_loss'], marker='o', label='train loss')
    plt.plot(epochs, history['val_loss'], marker='o', label='val loss')
    plt.xlabel('Epoch')
    plt.ylabel('Log Loss')
    plt.title('MLP Training')
    plt.grid(True)
    plt.legend(loc='upper left')

    if show_acc:
        ax = plt.gca()
        ax2 = ax.twinx()
        ax2.plot(epochs, history['train_acc'], linestyle='--', marker='x', label='train acc')
        ax2.plot(epochs, history['val_acc'], linestyle='--', marker='x', label='val acc')
        ax2.set_ylabel('Accuracy')
        lines, labels = ax.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax.legend(lines + lines2, labels + labels2, loc='upper center')

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"MLP训练曲线已保存到 {save_path}")
    plt.show()


def test_mlp(model, X_test, output_path="mlp_test_predictions.csv"):
    """
    对测试集做预测并保存结果
    """
    print("\n--- 使用 MLP 模型进行测试集预测 ---")
    y_test_pred = model.predict(X_test)

    df_pred = pd.DataFrame({
        "id": range(len(y_test_pred)),
        "target": y_test_pred
    })
    df_pred.to_csv(output_path, index=False)
    print(f"测试集预测结果已保存至 {output_path}")

    return y_test_pred




if __name__ == "__main__":
    # 数据加载
    X_train, y_train, X_test_unlabeled = load_data()
    print("--- 数据加载成功 ---")

    # 预处理 + 向量化
    X_train_tfidf, X_val_tfidf, X_test_tfidf, y_train_split, y_val_split, vectorizer = \
        preprocess_and_vectorize(X_train, X_test_unlabeled, y_train)
    print("\n--- 向量化完成 ---")

    # 保存各模型验证集准确率
    results = {}

    # 1. 朴素贝叶斯
    nb_model, nb_val_acc = train_nb(X_train_tfidf, y_train_split, X_val_tfidf, y_val_split)
    results["Naive Bayes"] = nb_val_acc
    test_nb(nb_model, X_test_tfidf)

    # 2. SVM (逐步训练版本)
    svm_model, svm_history = train_svm_with_loss(
        X_train_tfidf, y_train_split, X_val_tfidf, y_val_split,
        epochs=1000, batch_size=64, alpha=1e-4, learning_rate='optimal', verbose=True
    )
    results["SVM"] = svm_history["val_acc"][-1]  # 最后一个 epoch 的验证集准确率
    plot_training_history(svm_history, save_path="svm_training_loss.png", show_acc=True)
    test_svm(svm_model, X_test_tfidf)

    # 3. Logistic Regression
    logreg_model, logreg_history = train_logreg_with_loss(
        X_train_tfidf, y_train_split, X_val_tfidf, y_val_split,
        epochs=10, batch_size=256, alpha=1e-4, learning_rate='optimal', verbose=True
    )
    results["Logistic Regression"] = logreg_history["val_acc"][-1]
    plot_logreg_history(logreg_history, save_path="logreg_training.png", show_acc=True)
    test_logreg(logreg_model, X_test_tfidf)

    # 4. MLP
    mlp_model, mlp_history = train_mlp_with_loss(
        X_train_tfidf, y_train_split, X_val_tfidf, y_val_split,
        epochs=300, batch_size=32, hidden_layer_sizes=(256, 128),
        alpha=1e-4, learning_rate_init=0.01, verbose=True
    )
    results["MLP"] = mlp_history["val_acc"][-1]
    plot_mlp_history(mlp_history, save_path="mlp_training.png", show_acc=True)
    test_mlp(mlp_model, X_test_tfidf)

    # =======================
    # 汇总结果对比
    # =======================
    # print("\n=== 四个模型验证集准确率对比 ===")
    # for model, acc in results.items():
    #     print(f"{model:20s}: {acc:.4f}")

    # # 画柱状图（放大差异 + 标出数值）
    # plt.figure(figsize=(6, 4))
    # bars = plt.bar(results.keys(), results.values(), color=["skyblue", "orange", "green", "red"])

    # plt.ylabel("Validation Accuracy")
    # plt.title("Model Comparison on Validation Set")

    # # 设置纵坐标范围（建议从 0.8 开始）
    # plt.ylim(0.8, 1.0)   # 或 plt.ylim(0.6, 1.0)

    # # 在柱子上标出数值
    # for bar in bars:
    #     height = bar.get_height()
    #     plt.text(
    #         bar.get_x() + bar.get_width() / 2,  # x 位置：柱子中间
    #         height + 0.002,                     # y 位置：柱子顶稍微上方
    #         f"{height:.4f}",                    # 格式化数值
    #         ha="center", va="bottom", fontsize=10
    #     )

    # plt.grid(axis="y", linestyle="--", alpha=0.7)
    # plt.show()

    